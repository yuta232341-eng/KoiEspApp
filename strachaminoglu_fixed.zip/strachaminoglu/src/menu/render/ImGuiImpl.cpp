#include "ImGuiImpl.h"
#include "ShaderManager.h"
#include "TextureLoader.h"
#include "menu/common_screen.h"
#include "menu/touch/android_touch/Touch.h"
#include <android/log.h>
#include <cstring>

#define LOGI(...) do { __android_log_print(ANDROID_LOG_INFO, "ESP-ImGui", __VA_ARGS__); printf("[I] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, "ESP-ImGui", __VA_ARGS__); printf("[E] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)

namespace ImGuiImpl {

    static ShaderManager s_shader;
    static GLuint s_fontTexture = 0;
    static GLuint s_vbo = 0;
    static GLuint s_ibo = 0;
    static GLuint s_vao = 0;
    static int    s_displayW = 1080;
    static int    s_displayH = 2400;
    static bool   s_initialized = false;
    static ImGuiContext* s_ctx = nullptr;

    static void createFontTexture() {
        ImGuiIO& io = ImGui::GetIO();
        unsigned char* pixels = nullptr;
        int w = 0, h = 0;
        io.Fonts->GetTexDataAsRGBA32(&pixels, &w, &h);
        s_fontTexture = TextureLoader::createTexture(pixels, w, h);
        io.Fonts->SetTexID((ImTextureID)(intptr_t)s_fontTexture);
    }

    bool init(ANativeWindow* window) {
        if (s_initialized) return true;

        LOGI("ImGuiImpl::init start (window=%p)", (void*)window);

        if (window) {
            int w = ANativeWindow_getWidth(window);
            int h = ANativeWindow_getHeight(window);
            if (w > 0) s_displayW = w;
            if (h > 0) s_displayH = h;
        } else {
            if (g_screenWidth  > 0) s_displayW = g_screenWidth;
            if (g_screenHeight > 0) s_displayH = g_screenHeight;
        }

        if (s_displayW <= 0) s_displayW = 1080;
        if (s_displayH <= 0) s_displayH = 2400;

        LOGI("Display size: %dx%d", s_displayW, s_displayH);

        // Проверяем что EGL контекст активен
        EGLDisplay disp = eglGetCurrentDisplay();
        EGLContext ctx = eglGetCurrentContext();
        EGLSurface surf = eglGetCurrentSurface(EGL_DRAW);
        LOGI("EGL state: display=%p context=%p surface=%p", (void*)disp, (void*)ctx, (void*)surf);
        if (ctx == EGL_NO_CONTEXT) {
            LOGE("No EGL context current! SurfaceFlingerOverlay::activateContext() not called.");
            LOGE("This means overlay (PBuffer) was not initialized properly.");
            return false;
        }

        IMGUI_CHECKVERSION();
        s_ctx = ImGui::CreateContext();
        if (!s_ctx) {
            LOGE("ImGui::CreateContext failed");
            return false;
        }
        ImGui::SetCurrentContext(s_ctx);
        LOGI("ImGui context created");

        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        io.DisplaySize = ImVec2((float)s_displayW, (float)s_displayH);
        io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
        io.BackendPlatformName = "Android";
        io.BackendRendererName = "GLES3";
        io.MouseDrawCursor = false;
        io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;

        ImGui::StyleColorsDark();
        ImGui::GetStyle().ScaleAllSizes(2.5f);  // v77m: scale UI for phone DPI — called once at init, never again
        LOGI("ImGui style set");

        // v77m: load system Roboto at 22px — readable on phone, no atlas rebuild.
        // Falls back to ImGui default if font file not found.
        static const char* kFonts[] = {
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/DroidSans.ttf",
            "/system/fonts/sanfrancisco.ttf",
        };
        bool fontLoaded = false;
        for (const char* path : kFonts) {
            FILE* f = fopen(path, "rb");
            if (!f) continue;
            fclose(f);
            ImFontConfig cfg;
            cfg.OversampleH = 1; cfg.OversampleV = 1;
            ImFont* fnt = io.Fonts->AddFontFromFileTTF(path, 22.0f, &cfg);
            if (fnt) { fontLoaded = true; break; }
        }
        if (!fontLoaded) {
            io.Fonts->AddFontDefault();
            LOGI("System font not found, using ImGui default");
        } else {
            LOGI("Loaded system font at 22px");
        }

        LOGI("Initializing ShaderManager...");
        if (!s_shader.initialize()) {
            LOGE("ShaderManager init failed");
            return false;
        }
        LOGI("ShaderManager OK");

        LOGI("Creating font texture...");
        createFontTexture();
        if (s_fontTexture == 0) {
            LOGE("Failed to create font texture");
            return false;
        }
        LOGI("Font texture created: %u", s_fontTexture);

        glGenBuffers(1, &s_vbo);
        glGenBuffers(1, &s_ibo);
        glGenVertexArrays(1, &s_vao);
        LOGI("VBO=%u IBO=%u VAO=%u", s_vbo, s_ibo, s_vao);

        s_initialized = true;
        LOGI("ImGuiImpl initialized: %dx%d", s_displayW, s_displayH);
        return true;
    }

    void shutdown() {
        if (!s_initialized) return;
        if (s_vbo) glDeleteBuffers(1, &s_vbo);
        if (s_ibo) glDeleteBuffers(1, &s_ibo);
        if (s_vao) glDeleteVertexArrays(1, &s_vao);
        s_vbo = s_ibo = s_vao = 0;
        if (s_fontTexture) TextureLoader::destroyTexture(s_fontTexture);
        s_fontTexture = 0;

        // FontManager not used (v77l)
        s_shader.shutdown();

        if (s_ctx) {
            ImGui::DestroyContext(s_ctx);
            s_ctx = nullptr;
        }
        s_initialized = false;
    }

    void newFrame(float dt) {
        if (!s_initialized) return;
        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)s_displayW, (float)s_displayH);
        io.DeltaTime   = dt > 0.0f ? dt : 1.0f / 60.0f;
        // v14: тач-события выкачиваются ЗДЕСЬ (render-поток, до NewFrame) —
        // единственный поток, трогающий ImGuiIO. Убирает гонки с тач-потоком
        // (пропуски кликов, дёрганье драга).
        touch::pumpImGui();
        ImGui::NewFrame();
    }

    void render() {
        if (!s_initialized) return;
        ImGui::Render();
        ImDrawData* draw = ImGui::GetDrawData();
        if (!draw || draw->CmdListsCount == 0) return;

        int fbW = (int)(draw->DisplaySize.x * draw->FramebufferScale.x);
        int fbH = (int)(draw->DisplaySize.y * draw->FramebufferScale.y);
        if (fbW <= 0 || fbH <= 0) return;

        GLint  lastProgram, lastTexture, lastVao;
        glGetIntegerv(GL_CURRENT_PROGRAM, &lastProgram);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &lastTexture);
        glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &lastVao);

        glEnable(GL_BLEND);
        glBlendEquation(GL_FUNC_ADD);
        glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_CULL_FACE);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_SCISSOR_TEST);
        glViewport(0, 0, fbW, fbH);

        float L = draw->DisplayPos.x;
        float R = draw->DisplayPos.x + draw->DisplaySize.x;
        float T = draw->DisplayPos.y;
        float B = draw->DisplayPos.y + draw->DisplaySize.y;
        const float ortho[4][4] = {
            { 2.0f/(R-L),    0.0f,           0.0f, 0.0f },
            { 0.0f,          2.0f/(T-B),     0.0f, 0.0f },
            { 0.0f,          0.0f,          -1.0f, 0.0f },
            { (R+L)/(L-R),  (T+B)/(B-T),     0.0f, 1.0f }
        };

        auto& sh = s_shader.getImGuiShaders();
        glUseProgram(sh.program);
        glUniform1i(sh.textureLoc, 0);
        glUniformMatrix4fv(sh.projMtxLoc, 1, GL_FALSE, &ortho[0][0]);

        glBindVertexArray(s_vao);

        ImVec2 clipOff   = draw->DisplayPos;
        ImVec2 clipScale = draw->FramebufferScale;

        for (int n = 0; n < draw->CmdListsCount; ++n) {
            const ImDrawList* cmdList = draw->CmdLists[n];

            glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
            glBufferData(GL_ARRAY_BUFFER,
                          (GLsizeiptr)(cmdList->VtxBuffer.Size * (int)sizeof(ImDrawVert)),
                          (const GLvoid*)cmdList->VtxBuffer.Data, GL_STREAM_DRAW);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s_ibo);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                          (GLsizeiptr)(cmdList->IdxBuffer.Size * (int)sizeof(ImDrawIdx)),
                          (const GLvoid*)cmdList->IdxBuffer.Data, GL_STREAM_DRAW);

            glEnableVertexAttribArray(sh.positionLoc);
            glEnableVertexAttribArray(sh.uvLoc);
            glEnableVertexAttribArray(sh.colorLoc);
            glVertexAttribPointer(sh.positionLoc, 2, GL_FLOAT,         GL_FALSE,
                                    sizeof(ImDrawVert), (const GLvoid*)offsetof(ImDrawVert, pos));
            glVertexAttribPointer(sh.uvLoc,       2, GL_FLOAT,         GL_FALSE,
                                    sizeof(ImDrawVert), (const GLvoid*)offsetof(ImDrawVert, uv));
            glVertexAttribPointer(sh.colorLoc,    4, GL_UNSIGNED_BYTE, GL_TRUE,
                                    sizeof(ImDrawVert), (const GLvoid*)offsetof(ImDrawVert, col));

            for (int i = 0; i < cmdList->CmdBuffer.Size; ++i) {
                const ImDrawCmd* cmd = &cmdList->CmdBuffer[i];
                if (cmd->UserCallback) {
                    cmd->UserCallback(cmdList, cmd);
                    continue;
                }
                ImVec2 clipMin((cmd->ClipRect.x - clipOff.x) * clipScale.x,
                                (cmd->ClipRect.y - clipOff.y) * clipScale.y);
                ImVec2 clipMax((cmd->ClipRect.z - clipOff.x) * clipScale.x,
                                (cmd->ClipRect.w - clipOff.y) * clipScale.y);
                if (clipMax.x <= clipMin.x || clipMax.y <= clipMin.y) continue;

                glScissor((int)clipMin.x, (int)(fbH - clipMax.y),
                           (int)(clipMax.x - clipMin.x), (int)(clipMax.y - clipMin.y));
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, (GLuint)(intptr_t)cmd->GetTexID());

                glDrawElements(GL_TRIANGLES, (GLsizei)cmd->ElemCount,
                                sizeof(ImDrawIdx) == 2 ? GL_UNSIGNED_SHORT : GL_UNSIGNED_INT,
                                (void*)(intptr_t)(cmd->IdxOffset * sizeof(ImDrawIdx)));
            }
        }

        glDisable(GL_SCISSOR_TEST);
        glUseProgram(lastProgram);
        glBindTexture(GL_TEXTURE_2D, lastTexture);
        glBindVertexArray(lastVao);
    }

    bool handleTouchEvent(int action, float x, float y, int ) {
        if (!s_initialized) return false;
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        bool down = (action == 0 ) || (action == 2 );
        bool up   = (action == 1 )   || (action == 3 );
        if (down) io.AddMouseButtonEvent(0, true);
        if (up)   io.AddMouseButtonEvent(0, false);
        return io.WantCaptureMouse;
    }

    bool handleKeyEvent(int , int ) {
        return false;
    }

    void setDisplaySize(int w, int h) {
        if (w > 0) s_displayW = w;
        if (h > 0) s_displayH = h;
    }
    void getDisplaySize(int& w, int& h) {
        w = s_displayW;
        h = s_displayH;
    }

    void setMousePos(float x, float y) {
        if (!s_initialized) return;
        ImGui::GetIO().AddMousePosEvent(x, y);
    }
    void setMouseDown(bool down) {
        if (!s_initialized) return;
        ImGui::GetIO().AddMouseButtonEvent(0, down);
    }
    void setMouseScroll(float wheel) {
        if (!s_initialized) return;
        ImGui::GetIO().AddMouseWheelEvent(0.0f, wheel);
    }

    GLuint getFontTexture()  { return s_fontTexture; }
    GLuint getShaderProgram(){ return s_shader.getImGuiShaders().program; }
}

