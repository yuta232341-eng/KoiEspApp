package com.koi.esp

import android.content.Context
import android.graphics.*
import android.view.*

class EspMenuView(context: Context) : View(context) {

    interface MenuListener {
        fun onToggleEsp(v: Boolean)
        fun onToggleBox(v: Boolean)
        fun onToggleLine(v: Boolean)
        fun onToggleSkel(v: Boolean)
        fun onToggleName(v: Boolean)
        fun onToggleRadar(v: Boolean)
    }

    var listener: MenuListener? = null

    // State
    private var menuOpen = false
    private var btnEsp   = true
    private var btnBox   = true
    private var btnLine  = true
    private var btnSkel  = false
    private var btnName  = true
    private var btnRadar = true

    // Hamburger button bounds
    private val hamRect = RectF(16f, 60f, 96f, 110f)

    // Panel
    private val panelW = 260f
    private val panelH = 340f
    private val panelX = 110f
    private val panelY = 60f

    // Paints
    private val paintBg = Paint().apply {
        color = Color.parseColor("#CC000000"); style = Paint.Style.FILL
    }
    private val paintBorder = Paint().apply {
        color = Color.parseColor("#FF00FFFF"); style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val paintBtn = Paint().apply {
        color = Color.parseColor("#CC001122"); style = Paint.Style.FILL
    }
    private val paintBtnOn = Paint().apply {
        color = Color.parseColor("#CC003344"); style = Paint.Style.FILL
    }
    private val paintText = Paint().apply {
        color = Color.WHITE; textSize = 30f; isAntiAlias = true
        typeface = Typeface.DEFAULT_BOLD
    }
    private val paintTitle = Paint().apply {
        color = Color.CYAN; textSize = 34f; isAntiAlias = true
        typeface = Typeface.DEFAULT_BOLD
    }
    private val paintHam = Paint().apply {
        color = Color.CYAN; strokeWidth = 4f; isAntiAlias = true
    }
    private val paintOnOff = Paint().apply {
        textSize = 26f; isAntiAlias = true
    }

    // Row data
    data class Row(val label: String, var on: Boolean, val rect: RectF = RectF())
    private val rows = mutableListOf<Row>()

    private fun buildRows() {
        rows.clear()
        rows.add(Row("ESP ON/OFF", btnEsp))
        rows.add(Row("BOX ESP",    btnBox))
        rows.add(Row("LINE ESP",   btnLine))
        rows.add(Row("SKELETON",   btnSkel))
        rows.add(Row("NAME/DIST",  btnName))
        rows.add(Row("RADAR 360",  btnRadar))
    }

    init { buildRows() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Hamburger button
        val rx = hamRect.left + 8f
        val ry = hamRect.top + 12f
        canvas.drawRoundRect(hamRect, 8f, 8f, paintBg)
        canvas.drawRoundRect(hamRect, 8f, 8f, paintBorder)
        for (k in 0..2) {
            val ly = ry + k * 14f
            canvas.drawLine(rx, ly, rx + 56f, ly, paintHam)
        }

        if (!menuOpen) return

        // Panel background
        val panelRect = RectF(panelX, panelY, panelX + panelW, panelY + panelH)
        canvas.drawRoundRect(panelRect, 12f, 12f, paintBg)
        canvas.drawRoundRect(panelRect, 12f, 12f, paintBorder)

        // Title
        canvas.drawText("KOI ESP", panelX + 12f, panelY + 38f, paintTitle)

        // Rows
        val rowH = 44f
        val rowStartY = panelY + 50f
        buildRows()
        for ((i, row) in rows.withIndex()) {
            val top  = rowStartY + i * rowH + 4f
            val bot  = top + rowH - 6f
            val left = panelX + 8f
            val right = panelX + panelW - 8f
            row.rect.set(left, top, right, bot)

            val bg = if (row.on) paintBtnOn else paintBtn
            canvas.drawRoundRect(row.rect, 6f, 6f, bg)

            paintText.color = if (row.on) Color.CYAN else Color.parseColor("#88FFFFFF")
            canvas.drawText(row.label, left + 10f, bot - 10f, paintText)

            paintOnOff.color = if (row.on) Color.GREEN else Color.RED
            val onStr = if (row.on) "ON" else "OFF"
            canvas.drawText(onStr, right - 60f, bot - 10f, paintOnOff)
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action != MotionEvent.ACTION_DOWN) return false
        val tx = ev.x; val ty = ev.y

        // Hamburger hit?
        if (hamRect.contains(tx, ty)) {
            menuOpen = !menuOpen
            postInvalidate()
            return true
        }

        if (!menuOpen) return false

        // Row hit?
        for ((i, row) in rows.withIndex()) {
            if (row.rect.contains(tx, ty)) {
                row.on = !row.on
                when (i) {
                    0 -> { btnEsp   = row.on; listener?.onToggleEsp(row.on) }
                    1 -> { btnBox   = row.on; listener?.onToggleBox(row.on) }
                    2 -> { btnLine  = row.on; listener?.onToggleLine(row.on) }
                    3 -> { btnSkel  = row.on; listener?.onToggleSkel(row.on) }
                    4 -> { btnName  = row.on; listener?.onToggleName(row.on) }
                    5 -> { btnRadar = row.on; listener?.onToggleRadar(row.on) }
                }
                postInvalidate()
                return true
            }
        }
        return false
    }
}
