// main.cpp — temizsetup + EnemyESP
// Orijinal temizsetup render loop'una EnemyESP.draw() eklendi.
// Başka hiçbir şey değişmedi.

#include <thread>
#include <chrono>
#include <atomic>
#include <android/log.h>

#include "menu/overlay/SurfaceFlingerOverlay.h"
#include "menu/overlay/native_surface/ANativeWindowCreator.h"
#include "menu/render/ImGuiImpl.h"
#include "menu/touch/android_touch/Touch.h"
#include "imgui/imgui.h"
#include "esp.h"

#define LOG_TAG "ImGuiHello"
#define LOGI(fmt, ...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, fmt, ##__VA_ARGS__)
#define LOGE(fmt, ...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, fmt, ##__VA_ARGS__)

int g_screenWidth  = 1080;
int g_screenHeight = 2400;

static std::atomic<bool> g_running{true};

static void renderLoop() {
    using namespace std::chrono;

    auto& overlay = SurfaceFlingerOverlay::instance();
    overlay.activateContext();

    ImGuiImpl::setDisplaySize(overlay.getWidth(), overlay.getHeight());
    if (!ImGuiImpl::init(nullptr)) {
        LOGE("ImGui init failed");
        g_running.store(false);
        return;
    }

    auto displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
    touch::setImGuiIO(&ImGui::GetIO());
    touch::init(overlay.getWidth(), overlay.getHeight(), (uint8_t)displayInfo.orientation);

    uint8_t g_orient      = (uint8_t)displayInfo.orientation;
    int     g_touchW      = overlay.getWidth();
    int     g_touchH      = overlay.getHeight();
    int     g_orientFrame = 0;
    int     g_flushFrames = 0;

    while (g_running.load()) {
        auto frameStart = steady_clock::now();

        // Orientation poll her 4 frame
        if (++g_orientFrame >= 4) {
            g_orientFrame = 0;
            auto di = android::ANativeWindowCreator::GetDisplayInfo();
            uint8_t newOrient = (uint8_t)di.orientation;
            int newW = (int)di.width;
            int newH = (int)di.height;
            if (newW > 0 && newH > 0 &&
                (newOrient != g_orient || newW != g_touchW || newH != g_touchH)) {
                overlay.setSize(newW, newH);
                std::this_thread::sleep_for(milliseconds(32));
                overlay.recoverSurface();
                ImGuiImpl::setDisplaySize(newW, newH);
                touch::update(newW, newH, newOrient);
                g_orient  = newOrient;
                g_touchW  = newW;
                g_touchH  = newH;
                g_flushFrames = 8;
            }
        }

        if (g_flushFrames > 0) {
            --g_flushFrames;
            overlay.activateContext();
            glClearColor(0, 0, 0, 0);
            glClear(GL_COLOR_BUFFER_BIT);
            overlay.endFrame();
            continue;
        }

        overlay.beginFrame();
        float dt = duration<float>(steady_clock::now() - frameStart).count();
        ImGuiImpl::newFrame(dt);

        float W = float(overlay.getWidth());
        float H = float(overlay.getHeight());

        // ── Enemy ESP (BackgroundDrawList'e çizer, UI'dan önce) ──────────
        EnemyESP::draw(W, H);

        // ── ImGui UI ──────────────────────────────────────────────────────
        ImGui::SetNextWindowPos(ImVec2(10, 10), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(500, 700), ImGuiCond_FirstUseEver);
        ImGui::Begin("ESP", nullptr,
            ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse);

        ImGui::Checkbox("Enemy ESP",   &EnemyESP::g_options.enabled);
        ImGui::Checkbox("Boxes",       &EnemyESP::g_options.boxes);
        ImGui::Checkbox("Names",       &EnemyESP::g_options.names);
        ImGui::Checkbox("Distance",    &EnemyESP::g_options.distance);
        ImGui::Checkbox("Skeleton",    &EnemyESP::g_options.skeleton);
        ImGui::Checkbox("Bots",        &EnemyESP::g_options.bots);
        ImGui::SliderFloat("Range",    &EnemyESP::g_options.range, 50.f, 600.f);

        ImGui::Separator();
        ImGui::TextUnformatted(EnemyESP::g_status.c_str());

        ImGui::End();
        // ──────────────────────────────────────────────────────────────────

        ImGuiImpl::render();
        overlay.endFrame();

        auto frameEnd = steady_clock::now();
        float dtMs = duration<float, std::milli>(frameEnd - frameStart).count();
        if (dtMs < 16.0f)
            std::this_thread::sleep_for(
                microseconds(static_cast<long>((16.0f - dtMs) * 1000)));
    }

    touch::shutdown();
    ImGuiImpl::shutdown();
    overlay.shutdown();
}

int main() {
    auto& overlay = SurfaceFlingerOverlay::instance();
    if (!overlay.initialize()) {
        LOGE("Overlay init failed");
        return 1;
    }
    LOGI("Overlay ready: %dx%d", overlay.getWidth(), overlay.getHeight());
    renderLoop();
    return 0;
}
