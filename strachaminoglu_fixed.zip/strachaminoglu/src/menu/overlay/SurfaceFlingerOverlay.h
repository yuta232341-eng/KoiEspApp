#pragma once

#include <EGL/egl.h>
#if __has_include(<EGL/eglext.h>)
    #include <EGL/eglext.h>
#endif
#include <android/native_window.h>
#include "menu/overlay/native_surface/ANativeWindowCreator.h"
#include <atomic>
#include <cstdlib>

// Fallback для старых NDK (AIDE NDK r21) которые не имеют EGL 1.5 констант
#ifndef EGL_OPENGL_ES3_BIT
    #define EGL_OPENGL_ES3_BIT 0x40
#endif
#ifndef EGL_OPENGL_ES2_BIT
    #define EGL_OPENGL_ES2_BIT 0x04
#endif
#ifndef EGL_CONTEXT_MAJOR_VERSION
    #define EGL_CONTEXT_MAJOR_VERSION 0x3098
#endif
#ifndef EGL_CONTEXT_MINOR_VERSION
    #define EGL_CONTEXT_MINOR_VERSION 0x30FB
#endif
#ifndef EGL_NATIVE_VISUAL_ID
    #define EGL_NATIVE_VISUAL_ID 0x3030
#endif
#ifndef EGL_SAMPLE_BUFFERS
    #define EGL_SAMPLE_BUFFERS 0x3033
#endif
#ifndef EGL_SAMPLES
    #define EGL_SAMPLES 0x3031
#endif
#ifndef EGL_BUFFER_SIZE
    #define EGL_BUFFER_SIZE 0x3020
#endif
#ifndef EGL_RED_SIZE
    #define EGL_RED_SIZE 0x3024
#endif
#ifndef EGL_GREEN_SIZE
    #define EGL_GREEN_SIZE 0x3023
#endif
#ifndef EGL_BLUE_SIZE
    #define EGL_BLUE_SIZE 0x3022
#endif
#ifndef EGL_ALPHA_SIZE
    #define EGL_ALPHA_SIZE 0x3021
#endif
#ifndef EGL_DEPTH_SIZE
    #define EGL_DEPTH_SIZE 0x3025
#endif
#ifndef EGL_STENCIL_SIZE
    #define EGL_STENCIL_SIZE 0x3026
#endif
#ifndef EGL_SURFACE_TYPE
    #define EGL_SURFACE_TYPE 0x3033
#endif
#ifndef EGL_WINDOW_BIT
    #define EGL_WINDOW_BIT 0x04
#endif
#ifndef EGL_PBUFFER_BIT
    #define EGL_PBUFFER_BIT 0x01
#endif
#ifndef EGL_RENDERABLE_TYPE
    #define EGL_RENDERABLE_TYPE 0x3040
#endif
#ifndef EGL_NONE
    #define EGL_NONE 0x3038
#endif
#ifndef EGL_WIDTH
    #define EGL_WIDTH 0x3057
#endif
#ifndef EGL_HEIGHT
    #define EGL_HEIGHT 0x3056
#endif

#if __has_include(<GLES3/gl3.h>)
    // Use the NDK's real GLES3 declarations when available. The local
    // compatibility header is only for environments without GLES3 headers.
    #include <GLES3/gl3.h>
    #if __has_include(<GLES3/gl3ext.h>)
        #include <GLES3/gl3ext.h>
    #elif __has_include(<GLES2/gl2ext.h>)
        #include <GLES2/gl2ext.h>
    #endif
#elif __has_include(<GLES2/gl2.h>)
    #include <GLES2/gl2.h>
#elif __has_include(<gl3.h>)
    #include <menu/render/gles_compat/gl3.h>  // наш gles_compat
#else
    #ifndef GL_API
    typedef unsigned int GLenum;
    typedef unsigned int GLuint;
    typedef int GLint;
    typedef int GLsizei;
    typedef unsigned char GLboolean;
    typedef float GLfloat;
    #endif
#endif

class SurfaceFlingerOverlay {
public:
    static SurfaceFlingerOverlay& instance();

    bool initialize(int width = 0, int height = 0);
    void shutdown();

    void activateContext();
    void beginFrame();
    void endFrame();

    void setSize(int w, int h);

    bool isReady() const { return m_ready.load(); }
    int   getWidth()  const { return m_width; }
    int   getHeight() const { return m_height; }

    // v18: восстановление ОВЕРЛЕЯ. Симптом: через ~минуту SF перестаёт
    // композитить слой (ESP «замирает»), producer блокируется в
    // dequeueBuffer навечно. Лечение: setDequeueTimeout (swap не висит,
    // а возвращает ошибку) + полная реконструкция окна/surface на 3 провалах.
    bool recoverSurface();
    void applyDequeueTimeout();

    // Принудительно инициализировать PBuffer (если стандартный initialize упал).
    // Резервная инициализация EGL PBuffer, если обычная инициализация не удалась.
    bool forcePBufferInit();

    EGLDisplay getDisplay() const { return m_display; }
    EGLSurface getSurface() const { return m_surface; }
    EGLContext getContext() const { return m_context; }
    EGLConfig  getConfig()  const { return m_config; }

private:
    SurfaceFlingerOverlay() = default;
    ~SurfaceFlingerOverlay() = default;

    bool loadLibGui();
    bool createSurfaceFlingerLayer();
    bool initEGL();

    void destroyEGL();
    void destroySfLayer();

    void* m_libGui    = nullptr;
    void* m_libBinder = nullptr;

    void* m_sfClient  = nullptr;
    void* m_sfControl = nullptr;
    void* m_sfSurface = nullptr;

    // ANativeWindow из ANativeWindowCreator (новый подход для Android 7-14+)
    ANativeWindow* m_nativeWindow = nullptr;

    EGLDisplay m_display = EGL_NO_DISPLAY;
    EGLSurface m_surface = EGL_NO_SURFACE;
    EGLContext m_context = EGL_NO_CONTEXT;
    EGLConfig  m_config  = nullptr;

    int   m_width   = 0;
    int   m_height  = 0;
    int   m_layerZ  = 0x7FFFFFFF;

    // v18: счётчик подряд неудачных eglSwapBuffers для recovery
    int   m_swapFails = 0;

    // PBuffer fallback для Android 10+ где libgui.so приватный API не работает
    bool  m_usePBuffer = false;

    bool initPBuffer();
    bool initEGLPBuffer();

    std::atomic<bool> m_ready{false};
};