#include "ShaderManager.h"
#include <android/log.h>
#include <vector>

#define LOGI(...) do { __android_log_print(ANDROID_LOG_INFO, "ESP-Shader", __VA_ARGS__); printf("[I] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, "ESP-Shader", __VA_ARGS__); printf("[E] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)

const char* ShaderManager::VERT_SRC = R"(#version 300 es
precision mediump float;
layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 UV;
layout(location = 2) in vec4 Color;
uniform mat4 ProjMtx;
out vec2 Frag_UV;
out vec4 Frag_Color;
void main() {
    Frag_UV    = UV;
    Frag_Color = Color;
    gl_Position = ProjMtx * vec4(Position.xy, 0.0, 1.0);
}
)";

const char* ShaderManager::FRAG_SRC = R"(#version 300 es
precision mediump float;
uniform sampler2D Texture;
in vec2 Frag_UV;
in vec4 Frag_Color;
layout(location = 0) out vec4 Out_Color;
void main() {
    Out_Color = Frag_Color * texture(Texture, Frag_UV);
}
)";

GLuint ShaderManager::compileShader(GLenum type, const char* src, std::string* err) {
    GLuint sh = glCreateShader(type);
    if (!sh) return 0;
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        GLint len = 0;
        glGetShaderiv(sh, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> buf(len + 1, 0);
        glGetShaderInfoLog(sh, len, nullptr, buf.data());
        LOGE("Shader compile error: %s", buf.data());
        if (err) *err = buf.data();
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

GLuint ShaderManager::linkProgram(GLuint vs, GLuint fs, std::string* err) {
    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        GLint len = 0;
        glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> buf(len + 1, 0);
        glGetProgramInfoLog(prog, len, nullptr, buf.data());
        LOGE("Program link error: %s", buf.data());
        if (err) *err = buf.data();
        glDeleteProgram(prog);
        return 0;
    }
    return prog;
}

bool ShaderManager::initialize() {
    GLuint vs = compileShader(GL_VERTEX_SHADER,   VERT_SRC);
    if (!vs) return false;
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, FRAG_SRC);
    if (!fs) { glDeleteShader(vs); return false; }

    m_imgui.program = linkProgram(vs, fs);
    glDeleteShader(vs);
    glDeleteShader(fs);
    if (!m_imgui.program) return false;

    m_imgui.projMtxLoc  = glGetUniformLocation(m_imgui.program, "ProjMtx");
    m_imgui.textureLoc  = glGetUniformLocation(m_imgui.program, "Texture");
    m_imgui.positionLoc = 0;
    m_imgui.uvLoc       = 1;
    m_imgui.colorLoc    = 2;

    m_ready = true;
    LOGI("ShaderManager initialized");
    return true;
}

void ShaderManager::shutdown() {
    if (m_imgui.program) {
        glDeleteProgram(m_imgui.program);
        m_imgui.program = 0;
    }
    m_ready = false;
}

