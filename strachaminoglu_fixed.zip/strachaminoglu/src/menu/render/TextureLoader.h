#pragma once

// ═══════════════════════════════════════════════════════════════════════════
//  TextureLoader.h
//
//  ВАЖНО: этот хедер должен работать в 2 окружениях:
//    1. NDK на ПК (есть GLES3/gl3.h)
//    2. Termux на Android (часто НЕТ GLES3/gl3.h — только EGL/egl.h)
//
//  Поэтому мы используем EGL/egl.h который есть везде + делаем fallback
//  typedefs для GLuint/GLint если они ещё не определены.
// ═══════════════════════════════════════════════════════════════════════════

// Сначала пробуем EGL (есть и в NDK и в Termux)
#include <EGL/egl.h>

// Пробуем GLES3 (есть в NDK, может не быть в Termux)
// Если нет — используем наш gles_compat/gl3.h
#if __has_include(<GLES3/gl3.h>)
    #include <menu/render/gles_compat/gl3.h>
#elif __has_include(<GLES2/gl2.h>)
    #include <GLES2/gl2.h>
#elif __has_include(<gl3.h>)
    #include <menu/render/gles_compat/gl3.h>  // наш gles_compat
#else
    // Last resort — определяем типы вручную
    #ifndef GL_API
    typedef unsigned int GLenum;
    typedef unsigned int GLuint;
    typedef int GLint;
    typedef int GLsizei;
    typedef unsigned char GLboolean;
    typedef float GLfloat;
    typedef unsigned int GLbitfield;
    typedef ptrdiff_t GLsizeiptr;
    typedef ptrdiff_t GLintptr;
    #endif
#endif

// Гарантируем что GL_RGBA определён
#ifndef GL_RGBA
    #define GL_RGBA 0x1908
#endif
#ifndef GL_RGB
    #define GL_RGB 0x1907
#endif
#ifndef GL_TEXTURE_2D
    #define GL_TEXTURE_2D 0x0DE1
#endif
#ifndef GL_TEXTURE0
    #define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_UNPACK_ALIGNMENT
    #define GL_UNPACK_ALIGNMENT 0x0CF5
#endif
#ifndef GL_NEAREST
    #define GL_NEAREST 0x2600
#endif
#ifndef GL_LINEAR
    #define GL_LINEAR 0x2601
#endif
#ifndef GL_TEXTURE_MAG_FILTER
    #define GL_TEXTURE_MAG_FILTER 0x2800
#endif
#ifndef GL_TEXTURE_MIN_FILTER
    #define GL_TEXTURE_MIN_FILTER 0x2801
#endif
#ifndef GL_TEXTURE_WRAP_S
    #define GL_TEXTURE_WRAP_S 0x2802
#endif
#ifndef GL_TEXTURE_WRAP_T
    #define GL_TEXTURE_WRAP_T 0x2803
#endif
#ifndef GL_CLAMP_TO_EDGE
    #define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_UNSIGNED_BYTE
    #define GL_UNSIGNED_BYTE 0x1401
#endif
#ifndef GL_TEXTURE_BASE_LEVEL
    #define GL_TEXTURE_BASE_LEVEL 0x813C
#endif
#ifndef GL_TEXTURE_MAX_LEVEL
    #define GL_TEXTURE_MAX_LEVEL 0x813D
#endif

#include <cstdint>
#include <cstddef>

class TextureLoader {
public:

    static GLuint createTexture(const uint8_t* rgbaPixels, int w, int h,
                                 GLint internalFormat = GL_RGBA);
    static GLuint createTextureOptimal(const uint8_t* rgbaPixels, int w, int h,
                                        bool mipmaps = true);

    static GLuint loadFromMemory(const unsigned char* data, size_t size,
                                  int* outW = nullptr, int* outH = nullptr);

    static GLuint loadFromFile(const char* path, int* outW = nullptr, int* outH = nullptr);

    static void updateTexture(GLuint id, const uint8_t* pixels, int x, int y,
                               int w, int h, GLint format = GL_RGBA);

    static void bindTexture(GLuint id, int unit = 0);

    static void destroyTexture(GLuint id);

    static GLuint createSolidColor(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);
    static GLuint createSolidPixel(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255) {
        return createSolidColor(r, g, b, a);
    }
    static GLuint createCheckerboard(int size, int checkSize,
                                       uint32_t color1, uint32_t color2);
    static GLuint createGradient(int w, int h,
                                  uint32_t topLeft, uint32_t topRight,
                                  uint32_t bottomLeft, uint32_t bottomRight);

    static bool saveScreenshot(const char* path, int w, int h);
};
