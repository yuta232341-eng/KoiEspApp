// ============================================================
// KOI ESP — JNI Native Layer
// Root memory reader for RevolutionOxide (IL2CPP ARM64)
// ============================================================
#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <string>
#include <unistd.h>
#include <sys/uio.h>   // process_vm_readv
#include <dirent.h>
#include <cerrno>

#define TAG "KOI_ESP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── IL2CPP Offsets ──────────────────────────────────────────
static constexpr uintptr_t OFF_PlayerManager_TypeInfo = 0x848A910;
static constexpr uintptr_t OFF_PM_eventHandler        = 0x80;
static constexpr uintptr_t OFF_XE_Health_Xq           = 0x98;
static constexpr uintptr_t OFF_XQ_value               = 0x10;

// PlayerManager static_fields
static constexpr uintptr_t OFF_PM_staticFields        = 0xB8;
// activePlayerList inside static_fields (UT<T> generic list)
static constexpr uintptr_t OFF_PM_activeList          = 0x00;
// UT<T> list internals
static constexpr uintptr_t OFF_UTdm                   = 0x18;  // inner array ptr
static constexpr uintptr_t OFF_UTcount                = 0x18;  // count at array+0x18
static constexpr uintptr_t OFF_UTdata                 = 0x20;  // element data at array+0x20

// Transform position (Vector3) stored at 0x90 in Transform
static constexpr uintptr_t OFF_Transform_pos          = 0x90;

// ── Process helpers ─────────────────────────────────────────
static pid_t g_target_pid = -1;
static uintptr_t g_il2cpp_base = 0;

static pid_t find_pid(const char* pkg) {
    DIR* d = opendir("/proc");
    if (!d) return -1;
    struct dirent* e;
    while ((e = readdir(d))) {
        if (e->d_type != DT_DIR) continue;
        char* end;
        long pid = strtol(e->d_name, &end, 10);
        if (*end) continue;
        char path[64], comm[256] = {};
        snprintf(path, sizeof(path), "/proc/%ld/cmdline", pid);
        FILE* f = fopen(path, "r");
        if (!f) continue;
        fread(comm, 1, sizeof(comm)-1, f);
        fclose(f);
        if (strstr(comm, pkg)) {
            closedir(d);
            return (pid_t)pid;
        }
    }
    closedir(d);
    return -1;
}

static uintptr_t find_module_base(pid_t pid, const char* mod) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* f = fopen(path, "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, mod)) {
            base = (uintptr_t)strtoull(line, nullptr, 16);
            break;
        }
    }
    fclose(f);
    return base;
}

// Read memory from target process
static bool rpm(pid_t pid, uintptr_t addr, void* buf, size_t sz) {
    struct iovec local  = { buf, sz };
    struct iovec remote = { (void*)addr, sz };
    ssize_t r = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    return r == (ssize_t)sz;
}

template<typename T>
static T read_val(uintptr_t addr, bool* ok = nullptr) {
    T v{};
    bool r = rpm(g_target_pid, addr, &v, sizeof(T));
    if (ok) *ok = r;
    return v;
}

// ── Player data struct (passed to Java) ─────────────────────
struct PlayerInfo {
    float x, y, z;   // world position
    float hp;
    float maxhp;
    bool  valid;
};

static std::vector<PlayerInfo> g_players;
static bool g_running = false;

// ── Init: find process + base ────────────────────────────────
extern "C" JNIEXPORT jboolean JNICALL
Java_com_koi_esp_EspService_nativeInit(JNIEnv*, jobject) {
    g_target_pid = find_pid("com.RevolutionOxide.com");
    if (g_target_pid < 0) {
        LOGE("Target process not found");
        return JNI_FALSE;
    }
    LOGI("Target PID: %d", g_target_pid);

    g_il2cpp_base = find_module_base(g_target_pid, "libil2cpp.so");
    if (!g_il2cpp_base) {
        LOGE("libil2cpp.so base not found");
        return JNI_FALSE;
    }
    LOGI("libil2cpp base: 0x%lx", (unsigned long)g_il2cpp_base);
    return JNI_TRUE;
}

// ── Update: read all players ─────────────────────────────────
extern "C" JNIEXPORT jint JNICALL
Java_com_koi_esp_EspService_nativeUpdate(JNIEnv* env, jobject,
                                          jfloatArray outArr, jint maxPlayers) {
    if (g_target_pid < 0 || !g_il2cpp_base) return 0;

    // PlayerManager TypeInfo
    uintptr_t pm_ti = read_val<uintptr_t>(g_il2cpp_base + OFF_PlayerManager_TypeInfo);
    if (!pm_ti) return 0;

    uintptr_t pm_sf = read_val<uintptr_t>(pm_ti + OFF_PM_staticFields);
    if (!pm_sf) return 0;

    // activePlayerList (UT<T>)
    uintptr_t list_ptr = read_val<uintptr_t>(pm_sf + OFF_PM_activeList);
    if (!list_ptr) return 0;

    uintptr_t inner = read_val<uintptr_t>(list_ptr + OFF_UTdm);
    if (!inner) return 0;

    int count = read_val<int>(inner + OFF_UTcount);
    if (count <= 0 || count > 200) return 0;

    int found = 0;
    // outArr layout: [x, y, z, hp, maxhp] * maxPlayers
    jfloat* buf = env->GetFloatArrayElements(outArr, nullptr);
    int cap = env->GetArrayLength(outArr) / 5;
    if (cap > maxPlayers) cap = maxPlayers;

    for (int i = 0; i < count && found < cap; i++) {
        uintptr_t player = read_val<uintptr_t>(inner + OFF_UTdata + i * 8);
        if (!player) continue;

        // Position via Transform (offset 0x38 → Transform → 0x90)
        uintptr_t tf = read_val<uintptr_t>(player + 0x38);
        if (!tf) continue;

        float px = read_val<float>(tf + OFF_Transform_pos + 0);
        float py = read_val<float>(tf + OFF_Transform_pos + 4);
        float pz = read_val<float>(tf + OFF_Transform_pos + 8);

        // Health via eventHandler chain
        uintptr_t evh = read_val<uintptr_t>(player + OFF_PM_eventHandler);
        float hp = 100.f, maxhp = 100.f;
        if (evh) {
            uintptr_t xhq = read_val<uintptr_t>(evh + OFF_XE_Health_Xq);
            if (xhq) {
                hp    = read_val<float>(xhq + OFF_XQ_value);
                maxhp = read_val<float>(xhq + OFF_XQ_value + 4);
                if (maxhp < 1.f) maxhp = 100.f;
            }
        }

        int off = found * 5;
        buf[off + 0] = px;
        buf[off + 1] = py;
        buf[off + 2] = pz;
        buf[off + 3] = hp;
        buf[off + 4] = maxhp;
        found++;
    }

    env->ReleaseFloatArrayElements(outArr, buf, 0);
    return found;
}

// ── Local player position ────────────────────────────────────
extern "C" JNIEXPORT void JNICALL
Java_com_koi_esp_EspService_nativeGetLocalPos(JNIEnv* env, jobject,
                                               jfloatArray out) {
    // returns [x, y, z, yaw]
    jfloat* buf = env->GetFloatArrayElements(out, nullptr);
    buf[0] = buf[1] = buf[2] = buf[3] = 0.f;

    if (g_target_pid > 0 && g_il2cpp_base) {
        // TODO: resolve local player from PlayerManager.localPlayer offset
        // For now leave zeros — overlay still shows enemy positions
    }
    env->ReleaseFloatArrayElements(out, buf, 0);
}
