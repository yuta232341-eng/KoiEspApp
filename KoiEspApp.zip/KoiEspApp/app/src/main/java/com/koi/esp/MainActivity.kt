package com.koi.esp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    private val REQUEST_OVERLAY = 1001

    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 120, 60, 60)
            setBackgroundColor(0xFF0A0A0F.toInt())
        }

        val title = TextView(this).apply {
            text = "KOI ESP v2.0"
            textSize = 36f
            setTextColor(0xFF00FFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val sub = TextView(this).apply {
            text = "RevolutionOxide Hile"
            textSize = 18f
            setTextColor(0xFF888888.toInt())
            setPadding(0, 8, 0, 60)
        }

        val statusTv = TextView(this).apply {
            text = "Hazir — root gerekli"
            textSize = 16f
            setTextColor(0xFF00FF88.toInt())
            setPadding(0, 0, 0, 40)
        }

        val startBtn = Button(this).apply {
            text = "BAŞLAT"
            textSize = 22f
            setTextColor(0xFF000000.toInt())
            setBackgroundColor(0xFF00FFFF.toInt())
        }

        val stopBtn = Button(this).apply {
            text = "DURDUR"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFCC0000.toInt())
            setPadding(0, 24, 0, 24)
        }

        val infoTv = TextView(this).apply {
            text = "\n• Sol üst [=] butonuna dokun → menü açılır\n" +
                   "• Menüden özellikleri aç/kapat\n" +
                   "• Oyunu aç, overlay üstünde görünür\n" +
                   "• Root şart"
            textSize = 14f
            setTextColor(0xFF999999.toInt())
        }

        layout.addView(title)
        layout.addView(sub)
        layout.addView(statusTv)
        layout.addView(startBtn)
        layout.addView(LinearLayout(this).apply { setPadding(0,16,0,0) })
        layout.addView(stopBtn)
        layout.addView(infoTv)
        setContentView(layout)

        startBtn.setOnClickListener {
            if (!hasOverlayPerm()) {
                statusTv.text = "İzin isteniyor..."
                requestOverlayPerm()
            } else {
                startEsp()
                statusTv.text = "ESP aktif — oyuna geç ✓"
            }
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, EspService::class.java))
            statusTv.text = "Durduruldu."
        }
    }

    private fun hasOverlayPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(this)
        else true

    private fun requestOverlayPerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (hasOverlayPerm()) {
                startEsp()
                findViewById<TextView?>(android.R.id.text1)
                    ?.text = "ESP aktif ✓"
            }
        }
    }

    private fun startEsp() {
        val svc = Intent(this, EspService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(svc)
        else
            startService(svc)
    }
}
