#include "TextureLoader.h"
#include <android/log.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
// GLES3/gl3.h уже подключён через TextureLoader.h (с fallback для Termux)

#define LOGI(...) do { __android_log_print(ANDROID_LOG_INFO, "ESP-Tex", __VA_ARGS__); printf("[I] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, "ESP-Tex", __VA_ARGS__); printf("[E] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#define STBI_NO_FAILURE_STRINGS
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#include "menu/assets/stb/stb_image.h"

namespace {

struct MemBuf {
    const unsigned char* data;
    size_t size;
    size_t pos = 0;
};

int memRead(void* user, char* out, int count) {
    auto* mb = static_cast<MemBuf*>(user);
    int available = static_cast<int>(mb->size - mb->pos);
    if (available <= 0) return 0;
    int toRead = count < available ? count : available;
    memcpy(out, mb->data + mb->pos, toRead);
    mb->pos += toRead;
    return toRead;
}

void memSkip(void* user, int n) {
    auto* mb = static_cast<MemBuf*>(user);
    mb->pos += n;
    if (mb->pos > mb->size) mb->pos = mb->size;
}

int memEof(void* user) {
    auto* mb = static_cast<MemBuf*>(user);
    return mb->pos >= mb->size ? 1 : 0;
}

stbi_io_callbacks g_memCallbacks = { memRead, memSkip, memEof };

}

GLuint TextureLoader::createTexture(const uint8_t* pixels, int w, int h, GLint internalFormat) {
    if (!pixels || w <= 0 || h <= 0) return 0;

    GLuint id = 0;
    glGenTextures(1, &id);
    if (id == 0) return 0;

    glBindTexture(GL_TEXTURE_2D, id);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, w, h, 0,
                  GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    glGenerateMipmap(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, 0);
    return id;
}

GLuint TextureLoader::createTextureOptimal(const uint8_t* pixels, int w, int h, bool mipmaps) {
    if (!pixels || w <= 0 || h <= 0) return 0;

    GLuint id = 0;
    glGenTextures(1, &id);
    if (id == 0) return 0;

    glBindTexture(GL_TEXTURE_2D, id);

    if (mipmaps) {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    } else {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    }
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // Анизотропная фильтрация - пропускаем, т.к. в Termux GLES3 её может не быть
    // (закомментировано, чтобы избежать ошибок компиляции)
    /*
    float maxAniso = 0.0f;
    glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &maxAniso);
    if (maxAniso > 1.0f) {
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT,
                         maxAniso > 4.0f ? 4.0f : maxAniso);
    }
    */

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);

    if (mipmaps) {
        glGenerateMipmap(GL_TEXTURE_2D);
    }

    glBindTexture(GL_TEXTURE_2D, 0);
    return id;
}

GLuint TextureLoader::loadFromMemory(const unsigned char* data, size_t size,
                                       int* outW, int* outH) {
    if (!data || size == 0) {
        if (outW) *outW = 0;
        if (outH) *outH = 0;
        return 0;
    }

    MemBuf mb{ data, size, 0 };

    int w = 0, h = 0, channels = 0;
    unsigned char* pixels = stbi_load_from_callbacks(
        &g_memCallbacks, &mb, &w, &h, &channels, 4);

    if (!pixels) {
        LOGE("stb_image failed to decode from memory (%zu bytes)", size);
        if (outW) *outW = 0;
        if (outH) *outH = 0;
        return 0;
    }

    GLuint tex = createTextureOptimal(pixels, w, h, true);
    stbi_image_free(pixels);

    if (outW) *outW = w;
    if (outH) *outH = h;

    LOGI("Texture loaded from memory: %dx%d, GL id %u", w, h, tex);
    return tex;
}

GLuint TextureLoader::loadFromFile(const char* path, int* outW, int* outH) {
    if (!path || !*path) {
        if (outW) *outW = 0;
        if (outH) *outH = 0;
        return 0;
    }

    FILE* f = fopen(path, "rb");
    if (!f) {
        LOGE("Cannot open texture file: %s", path);
        if (outW) *outW = 0;
        if (outH) *outH = 0;
        return 0;
    }

    fseek(f, 0, SEEK_END);
    long fileSize = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (fileSize <= 0 || fileSize > 50 * 1024 * 1024) {
        LOGE("Bad texture file size: %ld", fileSize);
        fclose(f);
        if (outW) *outW = 0;
        if (outH) *outH = 0;
        return 0;
    }

    std::vector<unsigned char> fileData(static_cast<size_t>(fileSize));
    size_t read = fread(fileData.data(), 1, static_cast<size_t>(fileSize), f);
    fclose(f);

    if (read != static_cast<size_t>(fileSize)) {
        LOGE("Failed to read full texture file");
        if (outW) *outW = 0;
        if (outH) *outH = 0;
        return 0;
    }

    return loadFromMemory(fileData.data(), fileData.size(), outW, outH);
}

void TextureLoader::destroyTexture(GLuint id) {
    if (id > 0) {
        glDeleteTextures(1, &id);
    }
}

void TextureLoader::updateTexture(GLuint id, const uint8_t* pixels, int x, int y,
                                    int w, int h, GLint format) {
    if (id == 0 || !pixels || w <= 0 || h <= 0) return;
    glBindTexture(GL_TEXTURE_2D, id);
    glTexSubImage2D(GL_TEXTURE_2D, 0, x, y, w, h, format, GL_UNSIGNED_BYTE, pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
}

void TextureLoader::bindTexture(GLuint id, int unit) {
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, id);
}

GLuint TextureLoader::createSolidColor(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    uint8_t px[4] = { r, g, b, a };
    return createTexture(px, 1, 1, GL_RGBA);
}

GLuint TextureLoader::createCheckerboard(int size, int checkSize,
                                            uint32_t c1, uint32_t c2) {
    if (size <= 0 || checkSize <= 0) return 0;

    std::vector<uint32_t> pixels(static_cast<size_t>(size * size));
    for (int y = 0; y < size; ++y) {
        bool row = ((y / checkSize) & 1) != 0;
        for (int x = 0; x < size; ++x) {
            bool col = ((x / checkSize) & 1) != 0;
            pixels[static_cast<size_t>(y * size + x)] = (row ^ col) ? c1 : c2;
        }
    }
    return createTexture(reinterpret_cast<const uint8_t*>(pixels.data()),
                         size, size, GL_RGBA);
}

GLuint TextureLoader::createGradient(int w, int h,
                                        uint32_t topLeft, uint32_t topRight,
                                        uint32_t bottomLeft, uint32_t bottomRight) {
    if (w <= 0 || h <= 0) return 0;

    std::vector<uint32_t> pixels(static_cast<size_t>(w * h));
    for (int y = 0; y < h; ++y) {
        float ty = static_cast<float>(y) / static_cast<float>(h > 1 ? h - 1 : 1);
        for (int x = 0; x < w; ++x) {
            float tx = static_cast<float>(x) / static_cast<float>(w > 1 ? w - 1 : 1);

            auto lerpByte = [](uint8_t a, uint8_t b, float t) -> uint8_t {
                return static_cast<uint8_t>(a + (b - a) * t);
            };
            auto lerpColor = [&](uint32_t c0, uint32_t c1, float t) -> uint32_t {
                return (lerpByte((c0 >> 24) & 0xFF, (c1 >> 24) & 0xFF, t) << 24) |
                       (lerpByte((c0 >> 16) & 0xFF, (c1 >> 16) & 0xFF, t) << 16) |
                       (lerpByte((c0 >>  8) & 0xFF, (c1 >>  8) & 0xFF, t) <<  8) |
                       (lerpByte( c0        & 0xFF,  c1        & 0xFF, t));
            };

            uint32_t top = lerpColor(topLeft, topRight, tx);
            uint32_t bot = lerpColor(bottomLeft, bottomRight, tx);
            pixels[static_cast<size_t>(y * w + x)] = lerpColor(top, bot, ty);
        }
    }
    return createTexture(reinterpret_cast<const uint8_t*>(pixels.data()),
                         w, h, GL_RGBA);
}

bool TextureLoader::saveScreenshot(const char* path, int w, int h) {
    if (!path || !*path || w <= 0 || h <= 0) return false;

    // glReadPixels возвращает пиксели в порядке bottom-to-top (OpenGL origin = bottom-left).
    // BMP тоже хранит bottom-to-top (по умолчанию), поэтому мы НЕ переворачиваем.
    // Однако мы используем ImGui который считает origin top-left.
    // Поэтому: читаем как есть, и говорим BMP что это top-down (negative height).

    std::vector<uint8_t> pixels(static_cast<size_t>(w * h * 4));
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());

    // GL_RGBA -> BMP хочет BGRA. Меняем местами R и B.
    for (size_t i = 0; i < pixels.size(); i += 4) {
        std::swap(pixels[i], pixels[i + 2]);  // R <-> B
    }

    FILE* f = fopen(path, "wb");
    if (!f) return false;

    // BMP header (BITMAPINFOHEADER = 40 bytes, file header = 14 bytes, total 54)
    // Negative height = top-down image (origin top-left)
    uint8_t bmpHeader[54] = {};
    int rowSize = w * 4;
    int imageSize = rowSize * h;
    int fileSize = 54 + imageSize;
    bmpHeader[0] = 'B'; bmpHeader[1] = 'M';
    bmpHeader[2] = fileSize & 0xFF;
    bmpHeader[3] = (fileSize >> 8)  & 0xFF;
    bmpHeader[4] = (fileSize >> 16) & 0xFF;
    bmpHeader[5] = (fileSize >> 24) & 0xFF;
    bmpHeader[10] = 54;  // pixel data offset
    bmpHeader[14] = 40;  // BITMAPINFOHEADER size
    bmpHeader[18] = w & 0xFF;
    bmpHeader[19] = (w >> 8) & 0xFF;
    bmpHeader[20] = (w >> 16) & 0xFF;
    bmpHeader[21] = (w >> 24) & 0xFF;
    // Negative height = top-down
    int32_t negH = -h;
    bmpHeader[22] = negH & 0xFF;
    bmpHeader[23] = (negH >> 8) & 0xFF;
    bmpHeader[24] = (negH >> 16) & 0xFF;
    bmpHeader[25] = (negH >> 24) & 0xFF;
    bmpHeader[26] = 1;   // planes
    bmpHeader[28] = 32;  // bits per pixel

    fwrite(bmpHeader, 1, 54, f);
    fwrite(pixels.data(), 1, pixels.size(), f);
    fclose(f);

    LOGI("Screenshot saved to %s (%dx%d BMP, top-down)", path, w, h);
    return true;
}