#include "SurfaceFlingerOverlay.h"
#include <dlfcn.h>
#include <unistd.h>
#include <chrono>
#include <sys/system_properties.h>
#include <android/native_window.h>
#include <android/log.h>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <algorithm>  // std::max

#define LOG_TAG "ESP-SF"
#define LOGD(...) do { __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__); printf("[D] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGI(...) do { __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__); printf("[I] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGW(...) do { __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__); printf("[W] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__); printf("[E] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)

#include "menu/common_screen.h"

namespace SFSym {

constexpr const char* SFC_CTOR[] = {
    "_ZN7android21SurfaceComposerClientC1Ev",
    "_ZN7android21SurfaceComposerClientC2Ev",
    nullptr
};

constexpr const char* SFC_DTOR[] = {
    "_ZN7android21SurfaceComposerClientD1Ev",
    "_ZN7android21SurfaceComposerClientD2Ev",
    nullptr
};

constexpr const char* SFC_INIT_CHECK[] = {
    "_ZNK7android21SurfaceComposerClient9initCheckEv",
    nullptr
};

// ─── FIXED: Added SDK 36 createSurface symbol ─────────────────────────────
// New: createSurface(const String8&, uint32_t, uint32_t, int32_t, int32_t,
//                    const sp<IBinder>&, gui::LayerMetadata, uint32_t*)
// Old: createSurface(const String8&, uint32_t, uint32_t, int, uint32_t, uint32_t)
constexpr const char* SFC_CREATE_SURFACE_OLD[] = {
    "_ZN7android21SurfaceComposerClient13createSurfaceERKNS_7String8Ejjijj",
    "_ZN7android21SurfaceComposerClient13createSurfaceERKNS_7String8EjjijRKNS_2spINS_14SurfaceControlEEEjj",
    "_ZN7android21SurfaceComposerClient20createSurfaceCheckedERKNS_7String8EjjijPNS_2spINS_14SurfaceControlEEEjPNS_7IBinderEjj",
    nullptr
};

[[maybe_unused]] constexpr const char* SFC_CREATE_SURFACE_NEW[] = {
    "_ZN7android21SurfaceComposerClient13createSurfaceERKNS_7String8EjjiiRKNS_2spINS_7IBinderEEENS_3gui13LayerMetadataEPj",
    nullptr
};

constexpr const char* SC_GET_SURFACE[] = {
    "_ZN7android14SurfaceControl10getSurfaceEv",
    "_ZNK7android14SurfaceControl10getSurfaceEv",
    nullptr
};

constexpr const char* TX_CTOR[] = {
    "_ZN7android21SurfaceComposerClient11TransactionC1Ev",
    "_ZN7android21SurfaceComposerClient11TransactionC2Ev",
    nullptr
};

constexpr const char* TX_SET_LAYER[] = {
    "_ZN7android21SurfaceComposerClient11Transaction8setLayerERKNS_2spINS_14SurfaceControlEEEi",
    nullptr
};

constexpr const char* TX_SHOW[] = {
    "_ZN7android21SurfaceComposerClient11Transaction4showERKNS_2spINS_14SurfaceControlEEE",
    nullptr
};

constexpr const char* TX_SET_POSITION[] = {
    "_ZN7android21SurfaceComposerClient11Transaction11setPositionERKNS_2spINS_14SurfaceControlEEEff",
    nullptr
};

// ─── FIXED: setSize fallback to setCrop ───────────────────────────────────
// setSize is removed in SDK 36. setCrop(Rect{0,0,w,h}) achieves the same.
constexpr const char* TX_SET_SIZE[] = {
    "_ZN7android21SurfaceComposerClient11Transaction7setSizeERKNS_2spINS_14SurfaceControlEEEjj",
    nullptr
};

constexpr const char* TX_SET_CROP[] = {
    "_ZN7android21SurfaceComposerClient11Transaction7setCropERKNS_2spINS_14SurfaceControlEEERKNS_4RectE",
    nullptr
};

constexpr const char* TX_APPLY[] = {
    "_ZN7android21SurfaceComposerClient11Transaction5applyEbb",
    "_ZN7android21SurfaceComposerClient11Transaction5applyEb",
    nullptr
};

// ─── FIXED: Transaction dtor fallback to clear() ──────────────────────────
// D1/D2 destructors are inlined/not exported in SDK 36.
// Transaction::clear() is exported and cleans up internal state.
constexpr const char* TX_DTOR[] = {
    "_ZN7android21SurfaceComposerClient11TransactionD1Ev",
    "_ZN7android21SurfaceComposerClient11TransactionD2Ev",
    nullptr
};

constexpr const char* TX_CLEAR[] = {
    "_ZN7android21SurfaceComposerClient11Transaction5clearEv",
    nullptr
};

}

static void* loadFirst(void* lib, const char* const* candidates) {
    if (!lib || !candidates) return nullptr;
    for (int i = 0; candidates[i] != nullptr; ++i) {
        void* sym = dlsym(lib, candidates[i]);
        if (sym) {
            LOGD("Resolved: %s -> %p", candidates[i], sym);
            return sym;
        }
    }
    LOGW("None of the candidates found (first was: %s)", candidates[0]);
    return nullptr;
}

// ─── NEW: Construct empty LayerMetadata for SDK 36 ────────────────────────
// LayerMetadata wraps std::map<int, std::vector<uint8_t>>
// On libc++ ARM64, an empty std::map is 32 bytes:
//   offset 0:  __begin_node_ (pointer to end_node)
//   offset 8:  __end_node_.__left_ (pointer, self-referencing for empty)
//   offset 16: __end_node_.__right_ (nullptr)
//   offset 24: size (0)
static void constructEmptyLayerMetadata(void* buf) {
    // Try real constructor first
    void* libgui = dlopen("/system/lib64/libgui.so", RTLD_NOW | RTLD_LOCAL);
    if (!libgui) libgui = dlopen("libgui.so", RTLD_NOW | RTLD_LOCAL);

    if (libgui) {
        typedef void (*ctor_t)(void*);
        ctor_t ctor = (ctor_t)dlsym(libgui, "_ZN7android3gui13LayerMetadataC1Ev");
        if (!ctor) ctor = (ctor_t)dlsym(libgui, "_ZN7android3gui13LayerMetadataC2Ev");
        if (ctor) {
            ctor(buf);
            LOGD("LayerMetadata: real constructor called");
            return;
        }
    }

    // Manual construction of empty std::map (libc++ ARM64)
    uint8_t* base = static_cast<uint8_t*>(buf);
    memset(base, 0, 64);  // Zero everything first (be safe with padding)

    void* endNode = base + 8;  // __end_node_ is at offset 8
    *(void**)(base + 0)  = endNode;   // __begin_node_ -> __end_node_
    *(void**)(base + 8)  = endNode;   // __end_node_.__left_ -> self (empty tree)
    *(void**)(base + 16) = nullptr;   // __end_node_.__right_ -> null
    *(size_t*)(base + 24) = 0;        // size = 0

    LOGD("LayerMetadata: manually constructed empty map");
}

static void detectScreenSize(int& width, int& height) {
    char buf[PROP_VALUE_MAX] = {0};

    FILE* f = fopen("/sys/class/graphics/fb0/virtual_size", "r");
    if (f) {
        if (fscanf(f, "%d,%d", &width, &height) == 2) {
            fclose(f);
            LOGI("Screen size from /sys: %dx%d", width, height);
            return;
        }
        fclose(f);
    }

    FILE* p = popen("/system/bin/wm size 2>/dev/null", "r");
    if (p) {
        char line[256];
        while (fgets(line, sizeof(line), p)) {
            char* x = strstr(line, "Physical size:");
            if (x) {
                int w, h;
                if (sscanf(x, "Physical size: %dx%d", &w, &h) == 2) {
                    width = w;
                    height = h;
                    pclose(p);
                    LOGI("Screen size from wm: %dx%d", width, height);
                    return;
                }
            }
        }
        pclose(p);
    }

    width = 1080;
    height = 2400;
    LOGW("Could not detect screen size, using default %dx%d", width, height);
    (void)buf;
}

SurfaceFlingerOverlay& SurfaceFlingerOverlay::instance() {
    static SurfaceFlingerOverlay inst;
    return inst;
}

bool SurfaceFlingerOverlay::initialize(int width, int height) {
    if (m_ready) {
        LOGW("Already initialized");
        return true;
    }

    // ─── Используем ANativeWindowCreator (работает на Android 7-14+) ───────────
    // Это современная обёртка над SurfaceComposerClient, поддерживающая новые
    // символы libgui.so для Android 10+ (SetTrustedOverlay, LayerMetadata и т.д.)
    LOGI("Initializing overlay via ANativeWindowCreator...");
    fflush(stdout);

    // Получаем размеры экрана
    auto displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
    if (displayInfo.width > 0 && displayInfo.height > 0) {
        // ИСПОЛЬЗУЕМ РЕАЛЬНЫЕ РАЗМЕРЫ ЭКРАНА (не квадрат!)
        // Touch device отдаёт координаты в реальных пикселях (например 1080x2414).
        // Если overlay будет 2414x2414 (квадрат), координаты тача не совпадут с ImGui.
        m_width = displayInfo.width;
        m_height = displayInfo.height;
        LOGI("Display info: %dx%d, orientation=%d -> using REAL screen size %dx%d",
             displayInfo.width, displayInfo.height, displayInfo.orientation,
             m_width, m_height);
    } else if (width <= 0 || height <= 0) {
        detectScreenSize(m_width, m_height);
    } else {
        m_width = width;
        m_height = height;
    }
    g_screenWidth = m_width;
    g_screenHeight = m_height;

    // Создаём ANativeWindow overlay через ANativeWindowCreator
    LOGI("Creating overlay surface %dx%d (hide=false, secure=false)...", m_width, m_height);
    fflush(stdout);

    m_nativeWindow = android::ANativeWindowCreator::Create("EGLIS Overlay", m_width, m_height, false, false);
    if (!m_nativeWindow) {
        LOGE("ANativeWindowCreator::Create failed");
        LOGE("Make sure SELinux is permissive: su -c 'setenforce 0'");
        return false;
    }
    LOGI("ANativeWindow created: %p", m_nativeWindow);
    fflush(stdout);

    ANativeWindow_acquire(m_nativeWindow);

    // v18: таймаут dequeueBuffer — если SurfaceFlinger перестаёт композитить
    // слой (зависание оверлея «спустя минуту»), producer больше не висит в
    // dequeue навечно: eglSwapBuffers вернёт ошибку → render loop выполнит
    // recoverSurface() (аналог ручного «открыть окошко поверх игры»). API 30+.
    applyDequeueTimeout();

    // ─── EGL init на этом окне ─────────────────────────────────────────────────
    m_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (m_display == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay failed");
        return false;
    }

    EGLint major, minor;
    if (!eglInitialize(m_display, &major, &minor)) {
        LOGE("eglInitialize failed: 0x%x", eglGetError());
        return false;
    }
    LOGI("EGL %d.%d", major, minor);

    EGLint cfgAttrs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_RED_SIZE,   8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE,  8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 16,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    EGLint numConfigs = 0;
    if (!eglChooseConfig(m_display, cfgAttrs, &m_config, 1, &numConfigs) || numConfigs < 1) {
        // Fallback на ES2
        cfgAttrs[3] = EGL_OPENGL_ES2_BIT;
        if (!eglChooseConfig(m_display, cfgAttrs, &m_config, 1, &numConfigs) || numConfigs < 1) {
            LOGE("eglChooseConfig failed: 0x%x", eglGetError());
            return false;
        }
    }

    // Установить формат буфера окна
    EGLint egl_format;
    eglGetConfigAttrib(m_display, m_config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(m_nativeWindow, 0, 0, egl_format);

    // ES3 context
    EGLint ctxAttrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    m_context = eglCreateContext(m_display, m_config, EGL_NO_CONTEXT, ctxAttrs);
    if (m_context == EGL_NO_CONTEXT) {
        // ES2 fallback
        EGLint ctxAttrs2[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
        m_context = eglCreateContext(m_display, m_config, EGL_NO_CONTEXT, ctxAttrs2);
        if (m_context == EGL_NO_CONTEXT) {
            LOGE("eglCreateContext failed: 0x%x", eglGetError());
            return false;
        }
    }

    // Window surface из native window
    m_surface = eglCreateWindowSurface(m_display, m_config, (EGLNativeWindowType)m_nativeWindow, nullptr);
    if (m_surface == EGL_NO_SURFACE) {
        LOGE("eglCreateWindowSurface failed: 0x%x", eglGetError());
        return false;
    }

    if (!eglMakeCurrent(m_display, m_surface, m_surface, m_context)) {
        LOGE("eglMakeCurrent failed: 0x%x", eglGetError());
        return false;
    }

    // Прозрачный clear color
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_usePBuffer = false;
    m_ready.store(true);
    const char* glver = (const char*)glGetString(GL_VERSION);
    LOGI("*** OVERLAY READY (mode: SurfaceFlinger) *** GL %s", glver ? glver : "unknown");
    LOGI("*** This is a REAL on-screen overlay! Menu should be visible. ***");
    fflush(stdout);

    // EGL context is thread-local — release from this (main) thread so the
    // render thread can pick it up with activateContext().
    eglMakeCurrent(m_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

    return true;
}

bool SurfaceFlingerOverlay::initPBuffer() {
    return initEGLPBuffer();
}

// Принудительная PBuffer инициализация после неудачной стандартной инициализации
bool SurfaceFlingerOverlay::forcePBufferInit() {
    if (m_ready.load()) return true;  // уже готово

    LOGI(">>> forcePBufferInit() — инициализация EGL PBuffer напрямую");
    fflush(stdout);

    // Очищаем возможный мусор от неудавшегося SF init
    m_libGui = nullptr;
    m_libBinder = nullptr;
    m_sfClient = nullptr;
    m_sfControl = nullptr;
    m_sfSurface = nullptr;
    m_display = EGL_NO_DISPLAY;
    m_surface = EGL_NO_SURFACE;
    m_context = EGL_NO_CONTEXT;
    m_config  = nullptr;

    if (m_width <= 0 || m_height <= 0) {
        detectScreenSize(m_width, m_height);
    }
    g_screenWidth  = m_width;
    g_screenHeight = m_height;

    if (!initEGLPBuffer()) {
        LOGE("forcePBufferInit: initEGLPBuffer failed");
        return false;
    }

    m_usePBuffer = true;
    m_ready.store(true);
    LOGI("forcePBufferInit: OK (%dx%d, PBuffer mode)", m_width, m_height);
    fflush(stdout);
    return true;
}

bool SurfaceFlingerOverlay::initEGLPBuffer() {
    LOGI("Initializing EGL PBuffer %dx%d", m_width, m_height);
    fflush(stdout);

    m_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (m_display == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay failed");
        return false;
    }

    EGLint major, minor;
    if (!eglInitialize(m_display, &major, &minor)) {
        LOGE("eglInitialize failed");
        return false;
    }
    LOGI("EGL %d.%d", major, minor);

    EGLint cfgAttrs[] = {
        EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
        EGL_RED_SIZE,   8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE,  8,
        EGL_ALPHA_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_NONE
    };
    EGLint numConfigs = 0;
    if (!eglChooseConfig(m_display, cfgAttrs, &m_config, 1, &numConfigs) || numConfigs < 1) {
        // Попробуем ES2 если ES3 нет
        cfgAttrs[9] = EGL_OPENGL_ES2_BIT;
        if (!eglChooseConfig(m_display, cfgAttrs, &m_config, 1, &numConfigs) || numConfigs < 1) {
            LOGE("eglChooseConfig failed: 0x%x", eglGetError());
            return false;
        }
        LOGW("Using GLES2 (GLES3 not available)");
    }

    // ES3 context
    EGLint ctxAttrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    m_context = eglCreateContext(m_display, m_config, EGL_NO_CONTEXT, ctxAttrs);
    if (m_context == EGL_NO_CONTEXT) {
        // Fallback на ES2
        EGLint ctxAttrs2[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
        m_context = eglCreateContext(m_display, m_config, EGL_NO_CONTEXT, ctxAttrs2);
        if (m_context == EGL_NO_CONTEXT) {
            LOGE("eglCreateContext failed: 0x%x", eglGetError());
            return false;
        }
    }

    // PBuffer surface
    EGLint pbAttrs[] = {
        EGL_WIDTH,  m_width,
        EGL_HEIGHT, m_height,
        EGL_NONE
    };
    m_surface = eglCreatePbufferSurface(m_display, m_config, pbAttrs);
    if (m_surface == EGL_NO_SURFACE) {
        LOGE("eglCreatePbufferSurface failed: 0x%x", eglGetError());
        eglDestroyContext(m_display, m_context);
        m_context = EGL_NO_CONTEXT;
        return false;
    }

    if (!eglMakeCurrent(m_display, m_surface, m_surface, m_context)) {
        LOGE("eglMakeCurrent failed: 0x%x", eglGetError());
        return false;
    }

    LOGI("PBuffer EGL ready");
    fflush(stdout);

    // Release from calling (main) thread — render thread will bind via activateContext()
    eglMakeCurrent(m_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

    return true;
}

bool SurfaceFlingerOverlay::loadLibGui() {
    const char* libPaths[] = {
        "/system/lib64/libgui.so",
        "/system/lib/libgui.so",
        "libgui.so",
        nullptr
    };

    for (int i = 0; libPaths[i] != nullptr; ++i) {
        m_libGui = dlopen(libPaths[i], RTLD_NOW | RTLD_LOCAL);
        if (m_libGui) {
            LOGI("Loaded libgui from: %s", libPaths[i]);
            break;
        }
        LOGD("Failed dlopen(%s): %s", libPaths[i], dlerror());
    }

    if (!m_libGui) {
        LOGE("libgui.so not found in any path");
        return false;
    }

    const char* binderPaths[] = {
        "/system/lib64/libbinder.so",
        "/system/lib/libbinder.so",
        nullptr
    };
    for (int i = 0; binderPaths[i] != nullptr; ++i) {
        m_libBinder = dlopen(binderPaths[i], RTLD_NOW | RTLD_GLOBAL);
        if (m_libBinder) break;
    }

    return true;
}

bool SurfaceFlingerOverlay::createSurfaceFlingerLayer() {

    using FnCtor       = void* (*)(void*);
    using FnDtor       = void  (*)(void*);
    using FnInitCheck  = int   (*)(void*);
    using FnGetSurface = void* (*)(void*);
    using FnTxCtor     = void* (*)(void*);
    using FnTxSetLayer = void  (*)(void*, void*, int32_t);
    using FnTxShow     = void  (*)(void*, void*);
    using FnTxSetPos   = void  (*)(void*, void*, float, float);
    using FnTxSetSize  = void  (*)(void*, void*, uint32_t, uint32_t);
    using FnTxSetCrop  = void  (*)(void*, void*, const int32_t*);
    using FnTxClear    = void  (*)(void*);
    using FnTxApply    = int   (*)(void*, bool, bool);

    auto sfcCtor    = (FnCtor)         loadFirst(m_libGui, SFSym::SFC_CTOR);
    auto sfcCheck   = (FnInitCheck)    loadFirst(m_libGui, SFSym::SFC_INIT_CHECK);
    auto scGetSurf  = (FnGetSurface)   loadFirst(m_libGui, SFSym::SC_GET_SURFACE);
    auto txCtor     = (FnTxCtor)       loadFirst(m_libGui, SFSym::TX_CTOR);
    auto txDtor     = (FnDtor)         loadFirst(m_libGui, SFSym::TX_DTOR);
    auto txClear    = (FnTxClear)      loadFirst(m_libGui, SFSym::TX_CLEAR);
    auto txSetLayer = (FnTxSetLayer)   loadFirst(m_libGui, SFSym::TX_SET_LAYER);
    auto txShow     = (FnTxShow)       loadFirst(m_libGui, SFSym::TX_SHOW);
    auto txSetPos   = (FnTxSetPos)     loadFirst(m_libGui, SFSym::TX_SET_POSITION);
    auto txSetSize  = (FnTxSetSize)    loadFirst(m_libGui, SFSym::TX_SET_SIZE);
    auto txSetCrop  = (FnTxSetCrop)    loadFirst(m_libGui, SFSym::TX_SET_CROP);
    auto txApply    = (FnTxApply)      loadFirst(m_libGui, SFSym::TX_APPLY);

    if (!sfcCtor || !txCtor || !txSetLayer || !txShow || !txApply) {
        LOGE("Missing required SurfaceFlinger symbols");
        // Покажем какие именно не найдены
        if (!sfcCtor)    LOGE("  - sfcCtor (SurfaceComposerClient ctor) NOT FOUND");
        if (!txCtor)     LOGE("  - txCtor (Transaction ctor) NOT FOUND");
        if (!txSetLayer) LOGE("  - txSetLayer NOT FOUND");
        if (!txShow)     LOGE("  - txShow NOT FOUND");
        if (!txApply)    LOGE("  - txApply NOT FOUND");
        return false;
    }
    LOGI("All required SF symbols resolved:");
    LOGI("  sfcCtor=%p txCtor=%p txSetLayer=%p txShow=%p txApply=%p",
         (void*)sfcCtor, (void*)txCtor, (void*)txSetLayer, (void*)txShow, (void*)txApply);

    // ─── Load libutils for RefBase::incStrong ─────────────────────────
    void* libUtils = dlopen("/system/lib64/libutils.so", RTLD_NOW | RTLD_LOCAL);
    if (!libUtils) libUtils = dlopen("libutils.so", RTLD_NOW | RTLD_LOCAL);

    using FnIncStrong = void (*)(const void*, const void*);
    FnIncStrong incStrong = nullptr;
    if (libUtils) {
        incStrong = (FnIncStrong)dlsym(libUtils,
            "_ZNK7android7RefBase9incStrongEPKv");
        LOGI("incStrong resolved: %p", (void*)incStrong);
    } else {
        LOGW("libutils.so not loaded");
    }

    // ─── Construct SurfaceComposerClient ─────────────────────────────
    // На Android 10+ конструктор выполняет Binder-вызов; корректность ABI важна.
    constexpr size_t SFC_SIZE = 256;
    m_sfClient = std::malloc(SFC_SIZE);
    if (!m_sfClient) return false;
    std::memset(m_sfClient, 0, SFC_SIZE);

    LOGI("Calling SurfaceComposerClient ctor...");
    fflush(stdout);
    sfcCtor(m_sfClient);
    LOGI("SurfaceComposerClient ctor OK");

    if (incStrong) {
        LOGI("Calling incStrong to trigger onFirstRef...");
        fflush(stdout);
        incStrong(m_sfClient, nullptr);

        if (sfcCheck) {
            int rc = -1;
            rc = sfcCheck(m_sfClient);
            LOGI("After incStrong, initCheck: %d", rc);
            if (rc != 0) {
                LOGE("SurfaceComposerClient::initCheck() failed: %d", rc);
                destroySfLayer();
                return false;
            }
        }
    } else {
        LOGW("incStrong not found - trying initCheck anyway");
        if (sfcCheck) {
            int rc = -1;
            rc = sfcCheck(m_sfClient);
            if (rc != 0) {
                LOGE("SurfaceComposerClient::initCheck() failed: %d", rc);
                destroySfLayer();
                return false;
            }
        }
    }

    constexpr int PIXEL_FORMAT_TRANSLUCENT = 1;
    constexpr int LAYER_FLAGS = 0;

    // ─── FIXED: Use createSurfaceChecked instead of createSurface ──────
    // createSurface returns sp<SurfaceControl> which is non-trivially-
    // copyable → Itanium ABI returns it via hidden x8 register.
    // We can't set x8 from C code without inline asm.
    //
    // createSurfaceChecked returns void and takes sp<SurfaceControl>*
    // as output parameter → no x8 issue!
    //
    // New SDK 36 signature (demangled):
    //   void createSurfaceChecked(
    //       const String8& name,
    //       uint32_t w, uint32_t h,
    //       int32_t format,
    //       sp<SurfaceControl>* outSurface,
    //       int32_t flags,
    //       const sp<IBinder>& parent,
    //       LayerMetadata metadata,
    //       uint32_t* transformHint
    //   )
    //
    // ARM64 parameter layout:
    //   x0: this
    //   x1: &name
    //   x2: w
    //   x3: h
    //   x4: format
    //   x5: outSurface (sp<SurfaceControl>*)
    //   x6: flags
    //   x7: &parent
    //   sp+0: &metadata (LayerMetadata by value → hidden pointer)
    //   sp+8: &transformHint

    const char* createCheckedSym =
        "_ZN7android21SurfaceComposerClient20createSurfaceCheckedERKNS_7String8EjjiPNS_2spINS_14SurfaceControlEEEiRKNS4_INS_7IBinderEEENS_3gui13LayerMetadataEPj";

    typedef void (*FnCreateChecked)(
        void*,         // this
        const void*,   // &name
        uint32_t,      // w
        uint32_t,      // h
        int32_t,       // format
        void*,         // outSurface (sp<SurfaceControl>*)
        int32_t,       // flags
        const void*,   // &parent
        void*,         // &metadata
        uint32_t*      // &transformHint
    );

    auto sfcCreateChecked = (FnCreateChecked)dlsym(m_libGui, createCheckedSym);

    if (sfcCreateChecked) {
        LOGI("Using SDK 36+ createSurfaceChecked API");

        // Prepare parent: null sp<IBinder>
        void* nullBinderPtr = nullptr;

        // Prepare empty LayerMetadata
        alignas(8) uint8_t metadataBuf[64];
        constructEmptyLayerMetadata(metadataBuf);

        // Prepare transform hint
        uint32_t transformHint = 0;

        // Prepare output sp<SurfaceControl> — zeroed, 8 bytes (just a pointer)
        // The function will write SurfaceControl* into it and call incStrong
        alignas(8) uint8_t spOutBuf[8] = {0};

        sfcCreateChecked(
            m_sfClient,
            (void*)"ESP_Overlay",
            static_cast<uint32_t>(m_width),
            static_cast<uint32_t>(m_height),
            static_cast<int32_t>(PIXEL_FORMAT_TRANSLUCENT),
            spOutBuf,              // sp<SurfaceControl>* output
            static_cast<int32_t>(LAYER_FLAGS),
            &nullBinderPtr,        // const sp<IBinder>& parent
            metadataBuf,           // LayerMetadata
            &transformHint         // uint32_t* transformHint
        );

        // Read SurfaceControl* from sp<SurfaceControl>
        // sp<T> layout: { T* m_ptr } — first 8 bytes
        m_sfControl = *(void**)spOutBuf;

        LOGI("createSurfaceChecked returned: %p, transformHint=%u",
             m_sfControl, transformHint);

    } else {
        // Fallback: legacy createSurface (SDK ≤34)
        // sp<SurfaceControl> returned in x0 (trivial on old ABI)
        typedef void* (*FnCreateOld)(
            void*, void*, uint32_t, uint32_t, int, uint32_t
        );

        void* sfcCreateOld = loadFirst(m_libGui, SFSym::SFC_CREATE_SURFACE_OLD);
        if (!sfcCreateOld) {
            LOGE("createSurface: no symbol found in any API version");
            return false;
        }

        auto sfcCreate = (FnCreateOld)sfcCreateOld;
        LOGI("Using legacy createSurface API");
        m_sfControl = sfcCreate(
            m_sfClient,
            (void*)"ESP_Overlay",
            static_cast<uint32_t>(m_width),
            static_cast<uint32_t>(m_height),
            PIXEL_FORMAT_TRANSLUCENT,
            LAYER_FLAGS
        );
    }

    if (!m_sfControl) {
        LOGE("createSurface returned null");
        destroySfLayer();
        return false;
    }

    LOGI("SurfaceControl created: %p", m_sfControl);

    // ─── Configure the layer via Transaction ──────────────────────────
    constexpr size_t TX_SIZE = 512;
    void* tx = std::malloc(TX_SIZE);
    if (!tx) {
        destroySfLayer();
        return false;
    }
    std::memset(tx, 0, TX_SIZE);

    txCtor(tx);

    txSetLayer(tx, m_sfControl, m_layerZ);
    txShow(tx, m_sfControl);
    if (txSetPos) txSetPos(tx, m_sfControl, 0.0f, 0.0f);

    if (txSetSize) {
        txSetSize(tx, m_sfControl,
                  static_cast<uint32_t>(m_width),
                  static_cast<uint32_t>(m_height));
        LOGD("Used setSize for layer dimensions");
    } else if (txSetCrop) {
        int32_t cropRect[4] = {
            0, 0,
            static_cast<int32_t>(m_width),
            static_cast<int32_t>(m_height)
        };
        txSetCrop(tx, m_sfControl, cropRect);
        LOGD("Used setCrop({0, 0, %d, %d}) for layer dimensions",
             m_width, m_height);
    } else {
        LOGW("Neither setSize nor setCrop found");
    }

    txApply(tx, false, false);

    if (txDtor) {
        txDtor(tx);
    } else if (txClear) {
        txClear(tx);
        LOGD("Used Transaction::clear() instead of dtor");
    } else {
        LOGW("Transaction dtor and clear() both not found");
    }
    std::free(tx);

    if (scGetSurf) {
        m_sfSurface = scGetSurf(m_sfControl);
        LOGI("Surface (ANativeWindow*): %p", m_sfSurface);
    }

    if (!m_sfSurface) {
        LOGE("Failed to get Surface from SurfaceControl");
        destroySfLayer();
        return false;
    }

    return true;
}

bool SurfaceFlingerOverlay::initEGL() {
    m_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (m_display == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay failed: 0x%x", eglGetError());
        return false;
    }

    EGLint major, minor;
    if (!eglInitialize(m_display, &major, &minor)) {
        LOGE("eglInitialize failed: 0x%x", eglGetError());
        return false;
    }
    LOGI("EGL %d.%d", major, minor);

    const EGLint configAttribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
        EGL_RED_SIZE,        8,
        EGL_GREEN_SIZE,      8,
        EGL_BLUE_SIZE,       8,
        EGL_ALPHA_SIZE,      8,
        EGL_DEPTH_SIZE,      0,
        EGL_STENCIL_SIZE,    0,
        EGL_SAMPLE_BUFFERS,  0,
        EGL_NONE
    };

    EGLint numConfigs = 0;
    if (!eglChooseConfig(m_display, configAttribs, &m_config, 1, &numConfigs) || numConfigs == 0) {
        LOGE("eglChooseConfig failed: 0x%x", eglGetError());
        return false;
    }

    const EGLint contextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };
    m_context = eglCreateContext(m_display, m_config, EGL_NO_CONTEXT, contextAttribs);
    if (m_context == EGL_NO_CONTEXT) {
        LOGE("eglCreateContext failed: 0x%x", eglGetError());
        return false;
    }

    ANativeWindow* window = static_cast<ANativeWindow*>(m_sfSurface);

    EGLint format;
    eglGetConfigAttrib(m_display, m_config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(window, 0, 0, format);

    m_surface = eglCreateWindowSurface(m_display, m_config,
                                        (EGLNativeWindowType)window, nullptr);
    if (m_surface == EGL_NO_SURFACE) {
        LOGE("eglCreateWindowSurface failed: 0x%x", eglGetError());
        return false;
    }

    if (!eglMakeCurrent(m_display, m_surface, m_surface, m_context)) {
        LOGE("eglMakeCurrent failed: 0x%x", eglGetError());
        return false;
    }

    glViewport(0, 0, m_width, m_height);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    eglSwapInterval(m_display, 0);

    // Release from calling thread — render thread will bind via activateContext()
    eglMakeCurrent(m_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

    return true;
}

void SurfaceFlingerOverlay::activateContext() {
    if (!m_ready) {
        LOGE("activateContext: overlay not ready!");
        return;
    }
    if (!eglMakeCurrent(m_display, m_surface, m_surface, m_context)) {
        LOGE("activateContext: eglMakeCurrent failed: 0x%x", eglGetError());
    } else {
        LOGI("activateContext: EGL context bound OK (display=%p ctx=%p surf=%p)",
             (void*)m_display, (void*)m_context, (void*)m_surface);
    }
}

void SurfaceFlingerOverlay::applyDequeueTimeout() {
    if (!m_nativeWindow) return;
    void* libandroid = dlopen("libandroid.so", RTLD_NOW);
    if (!libandroid) return;
    using FnT = int (*)(ANativeWindow*, int64_t);
    auto setT = (FnT)dlsym(libandroid, "ANativeWindow_setDequeueTimeout");
    if (setT) {
        const int rc = setT(m_nativeWindow, 200000000LL);   // 200 мс
        LOGI("ANativeWindow_setDequeueTimeout(200ms) -> %d", rc);
    } else {
        LOGI("ANativeWindow_setDequeueTimeout unavailable (API < 30)");
    }
}

bool SurfaceFlingerOverlay::recoverSurface() {
    if (m_display == EGL_NO_DISPLAY) return false;
    LOGW("[SF] overlay recovery: recreating window + EGL surface...");
    fflush(stdout);

    // 1) контекст от старой поверхности, поверхность долой
    eglMakeCurrent(m_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (m_surface != EGL_NO_SURFACE) {
        eglDestroySurface(m_display, m_surface);
        m_surface = EGL_NO_SURFACE;
    }

    // 2) старое (зависшее) окно удаляем — SF убирает слой
    if (m_nativeWindow) {
        ANativeWindow_release(m_nativeWindow);
        android::ANativeWindowCreator::Destroy(m_nativeWindow);
        m_nativeWindow = nullptr;
    }

    // 3) новое окно + surface (EGLContext ТОТ ЖЕ: текстуры/шрифты/ImGui живы)
    m_nativeWindow = android::ANativeWindowCreator::Create(
        "EGLIS Overlay", m_width, m_height, false, false);
    if (!m_nativeWindow) {
        LOGE("[SF] recovery: ANativeWindowCreator::Create failed");
        return false;
    }
    ANativeWindow_acquire(m_nativeWindow);

    EGLint egl_format = 0;
    eglGetConfigAttrib(m_display, m_config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(m_nativeWindow, 0, 0, egl_format);
    applyDequeueTimeout();

    m_surface = eglCreateWindowSurface(m_display, m_config,
                                        (EGLNativeWindowType)m_nativeWindow, nullptr);
    if (m_surface == EGL_NO_SURFACE) {
        LOGE("[SF] recovery: eglCreateWindowSurface failed: 0x%x", eglGetError());
        return false;
    }
    if (!eglMakeCurrent(m_display, m_surface, m_surface, m_context)) {
        LOGE("[SF] recovery: eglMakeCurrent failed: 0x%x", eglGetError());
        return false;
    }
    glViewport(0, 0, m_width, m_height);
    eglSwapInterval(m_display, 0);
    LOGI("[SF] overlay surface RECOVERED (new window=%p)", m_nativeWindow);
    fflush(stdout);
    return true;
}

void SurfaceFlingerOverlay::beginFrame() {
    if (!m_ready || m_surface == EGL_NO_SURFACE) return;
    glViewport(0, 0, m_width, m_height);
    glClear(GL_COLOR_BUFFER_BIT);
}

void SurfaceFlingerOverlay::endFrame() {
    if (!m_ready || m_surface == EGL_NO_SURFACE) return;
    // v20: замер длительности свапа — долгий свап = SF тормозит наш слой
    // (диагностика зависаний; к пайпу stdout процесс больше не привязан)
    const auto t0 = std::chrono::steady_clock::now();
    const EGLBoolean r = eglSwapBuffers(m_display, m_surface);
    const long swapMs = (long)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - t0).count();
    if (swapMs > 200) LOGW("[SF] eglSwapBuffers took %ld ms (SF layer throttled?)", swapMs);
    if (r == EGL_TRUE) {
        m_swapFails = 0;
        return;
    }
    // v18: свап падает — слой SF заблокирован/убран/перегружен.
    // Три подряд неудачи → реконструкция окна+surface (аналог ручного
    // «открыть маленькое окно поверх игры»).
    if (++m_swapFails < 3) return;
    m_swapFails = 0;
    if (recoverSurface()) {
        m_swapFails = 0;
    } else {
        LOGE("[SF] recovery failed — retry on next swap error");
    }
}

void SurfaceFlingerOverlay::setSize(int w, int h) {
    if (w <= 0 || h <= 0) return;
    m_width = w;
    m_height = h;
    g_screenWidth  = w;
    g_screenHeight = h;
    if (m_ready) glViewport(0, 0, w, h);
}

void SurfaceFlingerOverlay::shutdown() {
    // Убираем проверку m_ready — нужно очищать даже если initialize упал
    // (могли быть частично созданные ресурсы).
    const bool was_ready = m_ready.load();
    m_ready.store(false);

    if (was_ready) {
        destroyEGL();
    }

    // Уничтожаем overlay через ANativeWindowCreator (новый путь)
    if (m_nativeWindow) {
        ANativeWindow_release(m_nativeWindow);
        android::ANativeWindowCreator::Destroy(m_nativeWindow);
        m_nativeWindow = nullptr;
    }

    // Старый путь (libgui.so напрямую) — на случай если использовался
    destroySfLayer();

    if (m_libGui)    { dlclose(m_libGui);    m_libGui    = nullptr; }
    if (m_libBinder) { dlclose(m_libBinder); m_libBinder = nullptr; }

    LOGI("SurfaceFlinger overlay shut down (was_ready=%d)", was_ready ? 1 : 0);
}

void SurfaceFlingerOverlay::destroyEGL() {
    if (m_display != EGL_NO_DISPLAY) {
        eglMakeCurrent(m_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (m_context != EGL_NO_CONTEXT) eglDestroyContext(m_display, m_context);
        if (m_surface != EGL_NO_SURFACE) eglDestroySurface(m_display, m_surface);
        eglTerminate(m_display);
    }
    m_display = EGL_NO_DISPLAY;
    m_surface = EGL_NO_SURFACE;
    m_context = EGL_NO_CONTEXT;
}

void SurfaceFlingerOverlay::destroySfLayer() {
    using FnDtor = void (*)(void*);
    using FnDecStrong = void (*)(const void*, const void*);

    if (m_sfControl) {
        auto dtor = (FnDtor)dlsym(m_libGui, "_ZN7android14SurfaceControlD1Ev");
        if (!dtor) dtor = (FnDtor)dlsym(m_libGui, "_ZN7android14SurfaceControlD2Ev");
        if (dtor) dtor(m_sfControl);
        m_sfControl = nullptr;
    }
    if (m_sfClient) {
        // decStrong before destroying
        void* libUtils = dlopen("/system/lib64/libutils.so", RTLD_NOW);
        if (libUtils) {
            auto decStrong = (FnDecStrong)dlsym(libUtils,
                "_ZNK7android7RefBase9decStrongEPKv");
            if (decStrong) decStrong(m_sfClient, nullptr);
        }

        auto dtor = (FnDtor)loadFirst(m_libGui, SFSym::SFC_DTOR);
        if (dtor) dtor(m_sfClient);
        std::free(m_sfClient);
        m_sfClient = nullptr;
    }
    m_sfSurface = nullptr;
}