// esp.cpp — Enemy-only ESP
// Referans pipeline: OreESP (VMABCDEmerged) — player kısımları alındı,
// ore/crate/aimbot tamamen çıkarıldı. Yapı ve okuma mantığı birebir aynı.
//
// FIX: attach() tamamen yeniden yazıldı.
//   — PID bulma: /proc dizin taraması + /proc/<pid>/cmdline okuma
//     (önceki for 1..65536 brute-force yerine gerçek dizin taraması)
//   — mem fd açma başarısız olursa /proc/<pid>/task/<tid>/mem de denenir
//   — maps refresh boş veya hatalı gelirse 3 kez retry
//   — libil2cpp base: birden fazla rx mapping varsa hepsini dene,
//     NetworkClient validate başarılı olan ilk base'i kullan
//   — g_status her adımda update ediliyor (ImGui penceresinde görünür)

#include "esp.h"

#include <elf.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <fstream>
#include <sstream>
#include <cstring>
#include <algorithm>
#include <limits>
#include <android/log.h>

// ImGui
#include "imgui/imgui.h"
#include "offset.h"

#define ETAG "EnemyESP"
#define ELOGI(fmt,...) __android_log_print(ANDROID_LOG_INFO,  ETAG, fmt, ##__VA_ARGS__)
#define ELOGE(fmt,...) __android_log_print(ANDROID_LOG_ERROR, ETAG, fmt, ##__VA_ARGS__)

// ── İmport: temizsetup'tan gelen ekran boyutu ─────────────────────────────
extern int g_screenWidth;
extern int g_screenHeight;

namespace EnemyESP {

// ── Public globals ────────────────────────────────────────────────────────
Options     g_options;
uint64_t    g_base        = 0;
uint64_t    g_camera      = 0;
uint64_t    g_localPlayer = 0;
pid_t       g_targetPid   = 0;
std::vector<PlayerNode> g_players;
int         g_playerCount = -1;
int         g_botCount    = -1;
std::string g_status      = "Not attached";

// ── Memory reader ─────────────────────────────────────────────────────────
struct Map { uint64_t lo, hi, offset; std::string perm, path; };
struct Reader {
    int fd = -1;
    std::vector<Map> maps;
    ~Reader() { if (fd >= 0) close(fd); }

    bool refreshMaps(pid_t pid) {
        std::ifstream src("/proc/" + std::to_string(pid) + "/maps");
        if (!src) return false;
        std::vector<Map> fresh; std::string line;
        while (std::getline(src, line)) {
            unsigned long long a, b, o; char perm[5]{};
            if (sscanf(line.c_str(), "%llx-%llx %4s %llx", &a, &b, perm, &o) != 4 || a >= b) continue;
            auto sl = line.find('/');
            fresh.push_back({a, b, o, perm, sl == std::string::npos ? "" : line.substr(sl)});
        }
        if (src.bad() || fresh.empty()) return false;
        std::sort(fresh.begin(), fresh.end(), [](const Map& a, const Map& b){ return a.lo < b.lo; });
        maps.swap(fresh); return true;
    }

    bool read(uint64_t addr, void* out, size_t bytes) const {
        if (!addr || bytes > std::numeric_limits<uint64_t>::max() - addr) return false;
        auto it = std::upper_bound(maps.begin(), maps.end(), addr,
            [](uint64_t a, const Map& m){ return a < m.lo; });
        if (it == maps.begin()) return false;
        --it;
        if (it->perm.empty() || it->perm[0] != 'r' || addr < it->lo || addr + bytes > it->hi) return false;
        return pread64(fd, out, bytes, addr) == ssize_t(bytes);
    }
    template<class T> bool get(uint64_t a, T& x) const { return read(a, &x, sizeof(x)); }
};

static Reader   reader;
static double   nextScan   = 0;
static double   nextAttach = 0;
static bool     scanActive = false;

// ── Pose cache (per-frame) ────────────────────────────────────────────────
struct PoseRow { float values[12]; int32_t parent; };
static std::unordered_map<uint64_t, V3>      poseCache;
static std::unordered_map<uint64_t, PoseRow> rowCache;

static void beginPoseFrame() { poseCache.clear(); rowCache.clear(); }

// ── Class name cache ──────────────────────────────────────────────────────
static std::unordered_map<uint64_t, std::string> classNames;
static std::unordered_map<uint64_t, bool>         humanoidTypes;
static std::unordered_map<uint64_t, std::unordered_map<std::string, bool>> ancestryCache;

static double now() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

// ── Temel bellek okumaları ────────────────────────────────────────────────
static uint64_t P(uint64_t a) {
    uint64_t v = 0; reader.get(a, v); return v;
}

static std::string textAt(uint64_t a) {
    char b[96]{}; if (!reader.read(a, b, 95)) return {}; return b;
}

static std::string className(uint64_t o) {
    uint64_t k = P(o); if (!k) return {};
    auto it = classNames.find(k); if (it != classNames.end()) return it->second;
    auto n = textAt(P(k + 0x10)); if (!n.empty()) classNames[k] = n; return n;
}

static bool derives(uint64_t object, const char* wanted) {
    uint64_t type = P(object), initial = type; if (!type) return false;
    auto& answers = ancestryCache[initial];
    auto cached = answers.find(wanted); if (cached != answers.end()) return cached->second;
    for (int depth = 0; type && depth < 32; depth++) {
        if (textAt(P(type + 0x10)) == wanted) return answers[wanted] = true;
        uint64_t parent = P(type + 0x58); if (parent == type) break; type = parent;
    }
    return answers[wanted] = false;
}

static bool humanoid(uint64_t object) {
    uint64_t type = P(object); if (!type) return false;
    auto found = humanoidTypes.find(type); if (found != humanoidTypes.end()) return found->second;
    if (derives(object, "NPCBrainAnimal") || derives(object, "AnimalStateMachine") ||
        derives(object, "AnimalDeathHandler")) { humanoidTypes[type] = false; return false; }
    bool r = derives(object, "NPCBrainHumanoid") || derives(object, "NPCHumanoidDeathHandler") ||
             derives(object, "NPCBrainCombat");
    humanoidTypes[type] = r; return r;
}

// ── Managed string okuma ──────────────────────────────────────────────────
static std::string managedString(uint64_t a) {
    int32_t n = 0;
    if (!a || !reader.get(a + 16, n) || n <= 0 || n > 160) return {};
    std::vector<uint16_t> raw(n);
    if (!reader.read(a + 20, raw.data(), n * 2)) return {};
    std::string out; bool tag = false;
    for (int i = 0; i < n; i++) {
        uint32_t c = raw[i];
        if (c == '<') { tag = true; continue; }
        if (c == '>') { tag = false; continue; }
        if (tag || c < 32) continue;
        if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n && raw[i+1] >= 0xDC00 && raw[i+1] <= 0xDFFF)
            c = 0x10000 + ((c - 0xD800) << 10) + (raw[++i] - 0xDC00);
        else if (c >= 0xD800 && c <= 0xDFFF) c = '?';
        if      (c < 128)   out += char(c);
        else if (c < 2048)  { out += char(0xC0 | (c >> 6));   out += char(0x80 | (c & 63)); }
        else if (c < 65536) { out += char(0xE0 | (c >> 12));  out += char(0x80 | ((c >> 6) & 63)); out += char(0x80 | (c & 63)); }
        else { out += char(0xF0|(c>>18)); out += char(0x80|((c>>12)&63)); out += char(0x80|((c>>6)&63)); out += char(0x80|(c&63)); }
    }
    return out;
}

// ── Nickname okuma ────────────────────────────────────────────────────────
// Yol 1: PlayerEvents (hsL) → hsN.DisplayName @ 0x88  ← en güvenilir
// Yol 2: Nicklabel (Il) → Il.nickname (Text) @ 0x38 → Text.m_Text @ 0xE0
// Yol 3: PlayerManager.uKU @ 0x240                   ← fallback
static std::string readPlayerNickname(uint64_t object) {
    if (!object) return {};

    // Yol 1: hsL.DisplayName (hsN base, offset 0x88)
    uint64_t handler = P(object + Offsets::PlayerEvents);
    if (handler) {
        std::string name = managedString(P(handler + Offsets::EventHandlerDisplayName));
        if (!name.empty() && name != "USERNAME") return name;
    }

    // Yol 2: Il nicklabel → Text.m_Text
    uint64_t nl = P(object + Offsets::Nicklabel);
    if (nl) {
        uint64_t textComp = P(nl + Offsets::NicklabelTextComponent); // Il.nickname (Text) @ 0x38
        if (textComp) {
            std::string name = managedString(P(textComp + Offsets::TextMText)); // Text.m_Text @ 0xE0
            if (!name.empty() && name != "USERNAME") return name;
        }
    }

    // Yol 3: PlayerManager.uKU fallback
    std::string alt = managedString(P(object + 0x240));
    if (!alt.empty() && alt != "USERNAME") return alt;

    return {};
}

// ── Kamera çözümleme ──────────────────────────────────────────────────────
static uint64_t resolveLocalCamera(uint64_t playerObj) {
    if (playerObj) {
        uint64_t rcMgr = P(playerObj + Offsets::RaycastManager);
        if (rcMgr) { uint64_t cam = P(rcMgr + 0x30); if (cam) { uint64_t n = P(cam + 0x10); if (n) return n; } }
        uint64_t fpMgr = P(playerObj + Offsets::FPManager);
        if (fpMgr) { uint64_t cam = P(fpMgr + 0x20); if (cam) { uint64_t n = P(cam + 0x10); if (n) return n; } }
        uint64_t camRoot = P(playerObj + Offsets::WorldCameraRoot);
        if (camRoot) { uint64_t n = P(camRoot + 0x10); if (n) return n; }
    }
    uint64_t gcKlass   = P(g_base + Offsets::GameControllerTypeInfo);
    uint64_t gcStatics = gcKlass ? P(gcKlass + 0xB8) : 0;
    if (gcStatics) {
        uint64_t camMgr = P(gcStatics + 0x38);
        if (camMgr) { uint64_t cam = P(camMgr + 0x20); if (cam) { uint64_t n = P(cam + 0x10); if (n) return n; } }
        uint64_t gcInst = P(gcStatics + 0x60);
        if (gcInst) {
            uint64_t camMgr2 = P(gcInst + 0x80);
            if (camMgr2) { uint64_t cam = P(camMgr2 + 0x20); if (cam) { uint64_t n = P(cam + 0x10); if (n) return n; } }
        }
    }
    return 0;
}

// ── Ölüm durumu ───────────────────────────────────────────────────────────
static int deathState(const PlayerNode& actor) {
    if (!actor.deathHandler) return -1;
    if (!derives(actor.deathHandler, actor.bot ? "NPCHumanoidDeathHandler" : "PlayerDeathHandler")) return -1;
    if (!actor.bot && P(actor.deathHandler + Offsets::DeathOwner) != actor.object) return -1;
    uint8_t dead = 255;
    if (!reader.get(actor.deathHandler + (actor.bot ? Offsets::BotDead : Offsets::PlayerDead), dead) || dead > 1) return -1;
    return int(dead);
}

// ── Pose okuma ────────────────────────────────────────────────────────────
static bool finite3(V3 v) {
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) &&
           fabsf(v.x) < 1e6f && fabsf(v.y) < 1e6f && fabsf(v.z) < 1e6f;
}
static V3 rotate(V3 p, const float* q) {
    V3 t{ 2*(q[1]*p.z-q[2]*p.y), 2*(q[2]*p.x-q[0]*p.z), 2*(q[0]*p.y-q[1]*p.x) };
    return { p.x+q[3]*t.x+q[1]*t.z-q[2]*t.y,
             p.y+q[3]*t.y+q[2]*t.x-q[0]*t.z,
             p.z+q[3]*t.z+q[0]*t.y-q[1]*t.x };
}
static bool position(uint64_t transform, V3& out) {
    struct Access { uint64_t data; int32_t index; uint32_t pad; } access{};
    if (!transform || !reader.read(transform + 0x28, &access, sizeof(access)) ||
        access.index < 0 || access.index > 1000000) return false;
    uint64_t arrays[2]{};
    if (!reader.read(access.data + 0x18, arrays, 16) || !arrays[0] || !arrays[1]) return false;
    uint64_t key = arrays[0] + uint64_t(access.index) * 48;
    auto found = poseCache.find(key); if (found != poseCache.end()) { out = found->second; return true; }
    int32_t index = access.index; bool first = true;
    for (int depth = 0; index >= 0; depth++) {
        if (depth >= 128 || index > 1000000) return false;
        uint64_t address = arrays[0] + uint64_t(index) * 48;
        auto it = rowCache.find(address);
        if (it == rowCache.end()) {
            PoseRow r{}; if (!reader.read(address, r.values, 48) || !reader.get(arrays[1] + uint64_t(index) * 4, r.parent)) return false;
            it = rowCache.emplace(address, r).first;
        }
        auto& r = it->second; auto* v = r.values;
        if (first) { out = {v[0], v[1], v[2]}; first = false; }
        else { out = rotate({out.x*v[8], out.y*v[9], out.z*v[10]}, v+4); out = {out.x+v[0], out.y+v[1], out.z+v[2]}; }
        if (r.parent == index) return false; index = r.parent;
    }
    if (!finite3(out)) return false; poseCache[key] = out; return true;
}
static bool childPosition(uint64_t parentTransform, V3& out) {
    struct Access { uint64_t data; int32_t index; uint32_t pad; } access{};
    if (!parentTransform || !reader.read(parentTransform + 0x28, &access, sizeof(access)) ||
        access.index < 0 || access.index > 1000000) return false;
    uint64_t arrays[2]{};
    if (!reader.read(access.data + 0x18, arrays, 16) || !arrays[0] || !arrays[1]) return false;
    int32_t parentIndex = access.index, childIndex = -1;
    for (int32_t off = 1; off <= 32; off++) {
        int32_t candidate = parentIndex + off; if (candidate > 1000000) break;
        int32_t p = -1; if (reader.get(arrays[1] + uint64_t(candidate)*4, p) && p == parentIndex) { childIndex = candidate; break; }
    }
    if (childIndex < 0) {
        for (int32_t off = -1; off >= -32; off--) {
            int32_t candidate = parentIndex + off; if (candidate < 0) break;
            int32_t p = -1; if (reader.get(arrays[1] + uint64_t(candidate)*4, p) && p == parentIndex) { childIndex = candidate; break; }
        }
    }
    if (childIndex < 0) return false;
    uint64_t key = arrays[0] + uint64_t(childIndex) * 48;
    auto found = poseCache.find(key); if (found != poseCache.end()) { out = found->second; return true; }
    int32_t index = childIndex; bool first = true;
    for (int depth = 0; index >= 0; depth++) {
        if (depth >= 128 || index > 1000000) return false;
        uint64_t address = arrays[0] + uint64_t(index) * 48;
        auto it = rowCache.find(address);
        if (it == rowCache.end()) {
            PoseRow r{}; if (!reader.read(address, r.values, 48) || !reader.get(arrays[1] + uint64_t(index)*4, r.parent)) return false;
            it = rowCache.emplace(address, r).first;
        }
        auto& r = it->second; auto* v = r.values;
        if (first) { out = {v[0], v[1], v[2]}; first = false; }
        else { out = rotate({out.x*v[8], out.y*v[9], out.z*v[10]}, v+4); out = {out.x+v[0], out.y+v[1], out.z+v[2]}; }
        if (r.parent == index) return false; index = r.parent;
    }
    if (!finite3(out)) return false; poseCache[key] = out; return true;
}

// ── Bone matching ─────────────────────────────────────────────────────────
static const char* boneNames[] = {
    "Head_HitBox","Spine2_HitBox","Spine1_HitBox","Spine_HitBox","Hips_HitBox",
    "Arm.L_HitBox","ForeArm.L_HitBox","Hand.L_HitBox",
    "Arm.R_HitBox","ForeArm.R_HitBox","Hand.R_HitBox",
    "UpLeg.L_HitBox","Leg.L_HitBox","Foot.L_HitBox",
    "UpLeg.R_HitBox","Leg.R_HitBox","Foot.R_HitBox"
};
static const int boneLinks[][2] = {
    {0,1},{1,2},{2,3},{3,4},
    {1,5},{5,6},{6,7},{1,8},{8,9},{9,10},
    {4,11},{11,12},{12,13},{4,14},{14,15},{15,16}
};
static bool matchBoneIndex(const std::string& name, int bi) {
    if (name.empty()) return false;
    switch (bi) {
        case 0:  return name=="Head_HitBox"||name=="Head"||name=="head";
        case 1:  return name=="Spine2_HitBox"||name=="Spine2"||name=="Chest_HitBox";
        case 2:  return name=="Spine1_HitBox"||name=="Spine1";
        case 3:  return name=="Spine_HitBox"||name=="Spine";
        case 4:  return name=="Hips_HitBox"||name=="Hips"||name=="Pelvis";
        case 5:  return name=="Arm.L_HitBox"||name=="Arm.L"||name=="ArmL_HitBox"||name=="UpperArm.L_HitBox";
        case 6:  return name=="ForeArm.L_HitBox"||name=="ForeArm.L"||name=="ForeArmL_HitBox";
        case 7:  return name=="Hand.L_HitBox"||name=="Hand.L"||name=="HandL_HitBox"||name=="Wrist.L_HitBox";
        case 8:  return name=="Arm.R_HitBox"||name=="Arm.R"||name=="ArmR_HitBox"||name=="UpperArm.R_HitBox";
        case 9:  return name=="ForeArm.R_HitBox"||name=="ForeArm.R"||name=="ForeArmR_HitBox";
        case 10: return name=="Hand.R_HitBox"||name=="Hand.R"||name=="HandR_HitBox"||name=="Wrist.R_HitBox";
        case 11: return name=="UpLeg.L_HitBox"||name=="UpLeg.L"||name=="UpLegL_HitBox"||name=="Thigh.L_HitBox";
        case 12: return name=="Leg.L_HitBox"||name=="Leg.L"||name=="LegL_HitBox"||name=="Calf.L_HitBox";
        case 13: return name=="Foot.L_HitBox"||name=="Foot.L"||name=="FootL_HitBox"||name=="Toe.L_HitBox";
        case 14: return name=="UpLeg.R_HitBox"||name=="UpLeg.R"||name=="UpLegR_HitBox"||name=="Thigh.R_HitBox";
        case 15: return name=="Leg.R_HitBox"||name=="Leg.R"||name=="LegR_HitBox"||name=="Calf.R_HitBox";
        case 16: return name=="Foot.R_HitBox"||name=="Foot.R"||name=="FootR_HitBox"||name=="Toe.R_HitBox";
        default: return false;
    }
}

// ── Scan state ────────────────────────────────────────────────────────────
struct ScanWork {
    bool     active    = false;
    int      cursor    = 0;
    int      count     = 0;
    int      players   = 0;
    int      bots      = 0;
    uint64_t dict      = 0;
    uint64_t entries   = 0;
    uint64_t camera    = 0;
    uint64_t localPlayer = 0;
    double   started   = 0;
    std::vector<PlayerNode> actors;
};
static ScanWork scanWork;
static double   nextMapRefresh = 0;
static std::unordered_map<uint64_t, std::pair<V3, double>> posHistory;

// ═══════════════════════════════════════════════════════════════════════════
// FIX: PID bulma — /proc dizin taraması, brute-force loop yok
// ═══════════════════════════════════════════════════════════════════════════
static pid_t findProcessByPackage(const char* pkg) {
    DIR* dir = opendir("/proc");
    if (!dir) return 0;

    pid_t found = 0;
    struct dirent* entry;

    while ((entry = readdir(dir)) != nullptr && !found) {
        // sadece sayısal isimli dizinler PID
        const char* name = entry->d_name;
        if (entry->d_type != DT_DIR && entry->d_type != DT_UNKNOWN) continue;
        bool allDigit = true;
        for (const char* c = name; *c; c++) {
            if (*c < '0' || *c > '9') { allDigit = false; break; }
        }
        if (!allDigit || name[0] == '\0') continue;

        pid_t pid = (pid_t)atoi(name);
        if (pid <= 0) continue;

        // cmdline oku — null-terminated, process adı ilk token
        char cmdline[256]{};
        char path[64]{};
        snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
        int f = open(path, O_RDONLY | O_CLOEXEC);
        if (f < 0) continue;
        ssize_t n = read(f, cmdline, sizeof(cmdline) - 1);
        close(f);
        if (n <= 0) continue;
        cmdline[n] = '\0';

        // cmdline[0..] = process name (null terminated), sonrası argv
        // tam eşleşme — "com.catsbit.oxidesurvivalisland"
        if (strcmp(cmdline, pkg) == 0) {
            found = pid;
        }
    }

    closedir(dir);
    return found;
}

// ── FIX: mem fd açma — /proc/<pid>/mem, başarısız olursa task thread'i dene
static int openMemFd(pid_t pid) {
    char path[64]{};
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd >= 0) return fd;

    // Bazı kernel versiyonlarında /proc/<pid>/task/<pid>/mem çalışır
    snprintf(path, sizeof(path), "/proc/%d/task/%d/mem", pid, pid);
    fd = open(path, O_RDONLY | O_CLOEXEC);
    return fd; // -1 dönebilir, caller handle eder
}

// ── FIX: maps refresh retry wrapper
static bool refreshMapsWithRetry(pid_t pid, int retries = 3) {
    for (int i = 0; i < retries; i++) {
        if (reader.refreshMaps(pid)) return true;
        // kısa bekle, /proc geçici olarak tutarsız olabilir
        struct timespec ts { 0, 5000000L }; // 5ms
        nanosleep(&ts, nullptr);
    }
    return false;
}

// ── reset ─────────────────────────────────────────────────────────────────
void reset() {
    scanWork = ScanWork{};
    nextMapRefresh = 0;
    if (reader.fd >= 0) close(reader.fd);
    reader.fd = -1; reader.maps.clear();
    classNames.clear(); humanoidTypes.clear(); ancestryCache.clear();
    beginPoseFrame();
    g_players.clear();
    g_base = g_camera = g_localPlayer = 0;
    g_targetPid = 0;
    g_playerCount = g_botCount = -1;
    nextScan = nextAttach = 0;
    g_status = "Reset";
}

// ═══════════════════════════════════════════════════════════════════════════
// FIX: attach() — tüm adımlar g_status ile raporlanıyor
// ═══════════════════════════════════════════════════════════════════════════
bool attach() {
    reset();
    nextAttach = now() + 2;

    // ── 1. PID bul ────────────────────────────────────────────────────────
    g_status = "Searching process...";
    const char* pkg = "com.catsbit.oxidesurvivalisland";
    pid_t found = findProcessByPackage(pkg);
    if (!found) {
        g_status = "Process not found";
        ELOGE("attach: process not found: %s", pkg);
        return false;
    }
    g_targetPid = found;
    ELOGI("attach: pid=%d", found);

    // ── 2. /proc/<pid>/mem aç ─────────────────────────────────────────────
    g_status = "Opening mem...";
    int fd = openMemFd(found);
    if (fd < 0) {
        g_status = "mem open failed (root required)";
        ELOGE("attach: open mem failed, errno=%d", errno);
        return false;
    }
    reader.fd = fd;

    // ── 3. Maps yükle (retry ile) ─────────────────────────────────────────
    g_status = "Loading maps...";
    if (!refreshMapsWithRetry(found)) {
        g_status = "maps refresh failed";
        ELOGE("attach: maps refresh failed after retries");
        return false;
    }
    ELOGI("attach: maps loaded, count=%zu", reader.maps.size());

    // ── 4. libil2cpp.so base bul — tüm rx mapping'leri dene ──────────────
    g_status = "Finding il2cpp base...";
    uint64_t foundBase = 0;

    for (auto& m : reader.maps) {
        if (foundBase) break;
        if (m.path.find("/libil2cpp.so") == std::string::npos) continue;
        if (m.perm.find('x') == std::string::npos) continue;

        int f = open(m.path.c_str(), O_RDONLY | O_CLOEXEC);
        if (f < 0) continue;

        Elf64_Ehdr eh{};
        bool ok = pread(f, &eh, sizeof(eh), 0) == sizeof(eh) &&
                  memcmp(eh.e_ident, ELFMAG, 4) == 0 &&
                  eh.e_ident[EI_CLASS] == ELFCLASS64 &&
                  eh.e_phentsize == sizeof(Elf64_Phdr) &&
                  eh.e_phnum < 128;

        if (ok) {
            for (unsigned i = 0; i < eh.e_phnum; i++) {
                Elf64_Phdr ph{};
                if (pread(f, &ph, sizeof(ph), eh.e_phoff + i * sizeof(ph)) != sizeof(ph)) break;
                if (ph.p_type != PT_LOAD || !(ph.p_flags & PF_X)) continue;

                uint64_t mask  = ~(uint64_t(sysconf(_SC_PAGESIZE)) - 1);
                if ((ph.p_offset & mask) != m.offset) continue;

                uint64_t base = m.lo - (ph.p_vaddr & mask);

                // Validate: NetworkClient string kontrolü
                uint64_t k = P(base + Offsets::NetworkClientTypeInfo);
                if (!k) continue;

                std::string nc  = textAt(P(k + 16));
                std::string ns  = textAt(P(k + 24));
                ELOGI("attach: base=0x%llx nc='%s' ns='%s'",
                      (unsigned long long)base, nc.c_str(), ns.c_str());

                if (nc == "NetworkClient" && ns == "Mirror") {
                    foundBase = base;
                    break;
                }
            }
        }
        close(f);
    }

    if (!foundBase) {
        g_status = "il2cpp base not found (offset mismatch?)";
        ELOGE("attach: NetworkClient validation failed for all rx mappings");
        return false;
    }

    g_base = foundBase;
    g_status = "Attached";
    ELOGI("attach: base=0x%llx — OK", (unsigned long long)g_base);
    return true;
}

// ── scan ──────────────────────────────────────────────────────────────────
bool scan(bool incremental) {
    const double sliceStart = now();
    beginPoseFrame();

    if (!scanWork.active) {
        scanWork = ScanWork{};
        if (sliceStart >= nextMapRefresh) {
            if (!reader.refreshMaps(g_targetPid)) { g_status = "Map refresh failed"; return false; }
            nextMapRefresh = now() + 2;
        }
        uint64_t klass    = P(g_base + Offsets::NetworkClientTypeInfo);
        uint64_t ncStatics = P(klass + 0xB8);
        scanWork.dict    = P(ncStatics + 0x30);
        if (scanWork.dict) {
            scanWork.entries = P(scanWork.dict + 0x18);
            reader.get(scanWork.dict + 0x20, scanWork.count);
            if (scanWork.count < 0 || scanWork.count > 50000) scanWork.count = 0;
            uint64_t cap = P(scanWork.entries + 24);
            if (scanWork.count && (!scanWork.entries || cap < uint64_t(scanWork.count) || cap > 100000)) scanWork.count = 0;
        } else { scanWork.entries = 0; scanWork.count = 0; }
        scanWork.started = now(); scanWork.active = true;
    }

    auto& actors      = scanWork.actors;
    auto& camera      = scanWork.camera;
    auto& localPlayer = scanWork.localPlayer;
    const uint64_t entries = scanWork.entries;

    if (scanWork.dict && scanWork.entries &&
        (P(scanWork.dict + 0x18) != entries || now() - scanWork.started > 30)) {
        scanWork.active = false; return true;
    }

    int processed = 0;
    while (scanWork.cursor < scanWork.count) {
        if (incremental && processed > 0 && (processed >= 32 || now() - sliceStart >= 0.003)) return true;
        int i = scanWork.cursor++; ++processed;
        uint64_t e = entries + 32 + uint64_t(i) * 24, identity = P(e + 16);
        int32_t next = -2;
        if (!reader.get(e + 4, next) || next < -1 || !identity || className(identity) != "NetworkIdentity") continue;
        uint64_t array = P(identity + 0x80), n = P(array + 24);
        if (!array || n > 64) continue;
        std::array<uint64_t, 64> behaviours{};
        if (n && !reader.read(array + 32, behaviours.data(), n * 8)) continue;

        uint64_t hitRoot = 0, botDeath = 0, playerDeath = 0;
        bool hasBrain = false;
        for (uint64_t j = 0; j < n; j++) {
            if (derives(behaviours[j], "HitBoxRecorderRoot")) hitRoot = behaviours[j];
            if (derives(behaviours[j], "NPCHumanoidDeathHandler")) botDeath = behaviours[j];
            if (derives(behaviours[j], "PlayerDeathHandler"))      playerDeath = behaviours[j];
            hasBrain = hasBrain || humanoid(behaviours[j]);
        }
        uint64_t entityGo = P(P(identity + 16) + 32);
        std::string entityPrefab = textAt(P(entityGo + 0x50));

        for (uint64_t j = 0; j < n; ++j) {
            uint64_t object = behaviours[j]; if (!object) continue;
            std::string name = className(object);
            if (derives(object, "NPCBrainAnimal") || derives(object, "AnimalStateMachine") ||
                derives(object, "AnimalDeathHandler")) continue;
            if (name != "PlayerManager" && !humanoid(object) && !((!hasBrain) && object == botDeath)) continue;

            bool isBot = (name != "PlayerManager");
            if (isBot) ++scanWork.bots; else ++scanWork.players;
            uint8_t local = 0; reader.get(identity + 0x4A, local);

            if (local && !isBot) {
                localPlayer = object;
                camera = resolveLocalCamera(object);
            } else {
                uint64_t native = P(object + 16), go = P(native + 32), tr = P(P(go + 32) + 8);
                V3 pos; if (!position(tr, pos)) continue;
                auto label = isBot ? std::string("Bot") : readPlayerNickname(object);
                if (label.empty() || label == "USERNAME") {
                    uint32_t netId = 0; reader.get(identity + 0x58, netId);
                    label = std::string(isBot ? "Bot #" : "Player #") + std::to_string(netId);
                }
                posHistory[object] = { pos, now() };

                PlayerNode node;
                node.object      = object;
                node.transform   = tr;
                node.name        = label;
                node.klass       = P(object);
                node.identity    = identity;
                node.bot         = isBot;
                node.deathHandler = isBot ? botDeath : playerDeath;

                uint64_t root = hitRoot;
                if (!root && isBot && humanoid(object)) {
                    uint64_t cand = P(object + 0x90);
                    if (derives(cand, "HitBoxRecorderRoot")) root = cand;
                }
                uint64_t hb = P(root + 0x68), bn = P(hb + 24);
                if (root && hb && bn <= 64) for (uint64_t k = 0; k < bn; k++) {
                    uint64_t box = P(hb + 32 + k * 8), bg = P(P(box + 16) + 32), bt = P(P(bg + 32) + 8);
                    auto boneName = textAt(P(bg + 0x50));
                    for (int bi = 0; bi < 17; bi++) if (matchBoneIndex(boneName, bi)) { node.bones[bi] = bt; break; }
                    if (isBot && !node.bones[0]) { int32_t area = -1; if (reader.get(box + 0x68, area) && area == 0) node.bones[0] = bt; }
                }
                node.head = node.bones[0];
                actors.push_back(std::move(node));
            }
        }
    }

    // Augment: PlayerManager.clientPlayerList
    uint64_t pmKlass = P(g_base + Offsets::PlayerManagerTypeInfo);
    if (pmKlass) {
        uint64_t pmStatics = P(pmKlass + 0xB8);
        uint64_t clientList = pmStatics ? P(pmStatics + 0x10) : 0;
        int32_t cCount = 0;
        if (clientList && reader.get(clientList + 0x18, cCount) && cCount > 0 && cCount < 256) {
            uint64_t items = P(clientList + 0x10);
            for (int ci = 0; ci < cCount; ++ci) {
                uint64_t pObj = P(items + 0x20 + uint64_t(ci) * 8);
                if (!pObj || className(pObj) != "PlayerManager") continue;
                uint64_t netIdObj = P(pObj + 0x40);
                uint8_t isLocal = 0; if (netIdObj) reader.get(netIdObj + 0x4A, isLocal);
                if (isLocal) { if (!localPlayer) { localPlayer = pObj; camera = resolveLocalCamera(pObj); } continue; }
                if (pObj == localPlayer) continue;
                bool exists = false;
                for (const auto& ex : actors) if (ex.object == pObj) { exists = true; break; }
                if (exists) continue;
                uint64_t native = P(pObj + 16), go = P(native + 32), tr = P(P(go + 32) + 8);
                V3 pos; if (!position(tr, pos)) continue;
                auto label = readPlayerNickname(pObj);
                if (label.empty() || label == "USERNAME") label = "Player #" + std::to_string(ci + 1);
                PlayerNode node; node.object = pObj; node.transform = tr; node.name = label;
                node.klass = P(pObj); node.identity = netIdObj; node.bot = false;
                node.head = node.bones[0];
                actors.push_back(std::move(node)); ++scanWork.players;
            }
        }
    }

    // Takım işareti
    const auto localTeam = managedString(P(localPlayer + Offsets::TeamName));
    for (auto& actor : actors)
        actor.teammate = !actor.bot && !localTeam.empty() &&
                         managedString(P(actor.object + Offsets::TeamName)) == localTeam;

    if (!camera) camera = resolveLocalCamera(localPlayer);
    if (!camera) { scanWork.active = false; g_status = "Waiting for camera"; return true; }

    g_players.swap(actors);
    g_camera      = camera;
    g_localPlayer = localPlayer;
    g_playerCount = scanWork.players;
    g_botCount    = scanWork.bots;
    scanWork.active = false;
    g_status = "Players: " + std::to_string(g_playerCount) + " | Bots: " + std::to_string(g_botCount);
    return true;
}

// ── Matris okuma + view türetme ───────────────────────────────────────────
static bool transformView(float* view) {
    uint64_t go = P(g_camera + 0x20), transform = P(P(go + 0x20) + 8);
    V3 origin; if (!position(transform, origin)) return false;
    struct Access { uint64_t data; int32_t index; uint32_t pad; } a{};
    if (!reader.read(transform + 0x28, &a, sizeof(a)) || a.index < 0 || a.index > 1000000) return false;
    uint64_t arrays[2]{}; if (!reader.read(a.data + 0x18, arrays, 16)) return false;
    V3 axes[3] = {{1,0,0},{0,1,0},{0,0,1}};
    int index = a.index;
    for (int depth = 0; index >= 0; ++depth) {
        if (depth >= 128 || index > 1000000) return false;
        uint64_t address = arrays[0] + uint64_t(index) * 48;
        auto it = rowCache.find(address); if (it == rowCache.end()) return false;
        const auto& row = it->second;
        for (auto& axis : axes) axis = rotate(axis, row.values + 4);
        if (row.parent == index) return false; index = row.parent;
    }
    memset(view, 0, 64); view[15] = 1;
    for (int row = 0; row < 3; row++) {
        V3 b = axes[row]; float len = sqrtf(b.x*b.x + b.y*b.y + b.z*b.z);
        if (!finite3(b) || len < 0.9f || len > 1.1f) return false;
        float sign = (row == 2 ? -1.f : 1.f) / len;
        view[row]    = b.x * sign; view[4+row]  = b.y * sign; view[8+row]  = b.z * sign;
        view[12+row] = -(origin.x*b.x + origin.y*b.y + origin.z*b.z) * sign;
    }
    return true;
}
static bool matrices(float* view, float* proj) {
    if (!g_camera || !reader.read(g_camera + 0x70, view, 64) || !reader.read(g_camera + 0xB0, proj, 64)) return false;
    float verify[16]{}; if (!reader.read(g_camera + 0xB0, verify, 64)) return false;
    for (int i = 0; i < 16; i++) {
        if (!std::isfinite(view[i]) || !std::isfinite(proj[i]) || !std::isfinite(verify[i])) return false;
        if (fabsf(proj[i] - verify[i]) > 1e-4f) return false;
    }
    return fabsf(view[15]-1) < 0.01f && fabsf(proj[0]) > 0.01f && fabsf(proj[5]) > 0.01f;
}
static bool project(V3 p, const float* v, const float* pr, float w, float h, ImVec2& out, float& distance) {
    float c[4]{}, clip[4]{}; float world[4] = {p.x, p.y, p.z, 1};
    for (int row = 0; row < 4; row++) for (int col = 0; col < 4; col++) c[row] += v[col*4+row] * world[col];
    distance = sqrtf(c[0]*c[0] + c[1]*c[1] + c[2]*c[2]);
    for (int row = 0; row < 4; row++) for (int col = 0; col < 4; col++) clip[row] += pr[col*4+row] * c[col];
    if (!std::isfinite(w) || !std::isfinite(h) || w <= 0 || h <= 0 ||
        !std::isfinite(clip[3]) || clip[3] <= 0.01f) return false;
    float x = clip[0]/clip[3], y = clip[1]/clip[3];
    if (!std::isfinite(x) || !std::isfinite(y) || fabsf(x) > 100 || fabsf(y) > 100) return false;
    out = {(x+1)*0.5f*w, (1-y)*0.5f*h};
    return std::isfinite(distance);
}

// ── draw ──────────────────────────────────────────────────────────────────
void draw(float w, float h) {
    if (!g_options.enabled) return;
    const double t = now();

    if (!g_base || reader.fd < 0) {
        if (t < nextAttach) return;
        if (!attach()) { nextAttach = now() + 3; return; }
    }
    if (scanWork.active || t >= nextScan) {
        if (!scan(true)) { reset(); nextAttach = now() + 2; return; }
        if (!scanWork.active) nextScan = now() + 0.5;
    }

    // Live kamera yenile
    uint64_t activeCamera = resolveLocalCamera(g_localPlayer);
    if (activeCamera) g_camera = activeCamera;
    if (!g_localPlayer || !g_camera) return;

    beginPoseFrame();
    float v[16], p[16];
    if (!matrices(v, p) || !transformView(v)) return;

    auto* dl = ImGui::GetBackgroundDrawList();
    dl->PushClipRect({0, 0}, {w, h}, true);

    for (auto& player : g_players) {
        if (player.bot && !g_options.bots) continue;
        if (P(player.object) != player.klass || !P(player.object + 16)) continue;

        V3 feet, head;
        if (!position(player.transform, feet)) continue;

        const bool dead = deathState(player) == 1;
        if (dead) {
            if (!g_options.names) continue;
            ImVec2 pt; float dist;
            if (!project(feet, v, p, w, h, pt, dist) || dist > g_options.range) continue;
            auto label = player.name + " [DEAD]";
            auto sz = ImGui::CalcTextSize(label.c_str());
            ImVec2 at{pt.x - sz.x*0.5f, pt.y - sz.y};
            dl->AddText({at.x+1, at.y+1}, IM_COL32(0,0,0,230), label.c_str());
            auto* dc = g_options.deadColor;
            dl->AddText(at, ImGui::ColorConvertFloat4ToU32({dc[0],dc[1],dc[2],1}), label.c_str());
            continue;
        }

        if (player.head) { if (!position(player.head, head)) continue; head.y += 0.12f; }
        else             head = {feet.x, feet.y + 1.8f, feet.z};

        ImVec2 footScreen, headScreen; float d, dh;
        if (!project(feet, v, p, w, h, footScreen, d) ||
            !project(head, v, p, w, h, headScreen, dh) || d > g_options.range) continue;

        float bh = fabsf(footScreen.y - headScreen.y);
        if (bh < 2 || bh > h * 2) continue;
        float top    = std::min(footScreen.y, headScreen.y);
        float bottom = std::max(footScreen.y, headScreen.y);
        float cx     = (footScreen.x + headScreen.x) * 0.5f;
        float bw     = bh * 0.45f;

        // Renk seç
        ImU32 color;
        if (player.teammate) {
            auto* tc = g_options.teamColor;
            color = ImGui::ColorConvertFloat4ToU32({tc[0],tc[1],tc[2],1});
        } else if (player.bot) {
            auto* bc = g_options.botColor;
            color = ImGui::ColorConvertFloat4ToU32({bc[0],bc[1],bc[2],1});
        } else {
            auto* pc = g_options.playerColor;
            color = ImGui::ColorConvertFloat4ToU32({pc[0],pc[1],pc[2],1});
        }
        ImU32 boxCol = ImGui::ColorConvertFloat4ToU32({g_options.boxColor[0],g_options.boxColor[1],g_options.boxColor[2],1});

        // Box
        if (g_options.boxes) {
            if (g_options.boxStyle == 0) {
                dl->AddRect({cx-bw*0.5f-1, top-1}, {cx+bw*0.5f+1, bottom+1}, IM_COL32(0,0,0,200), 0, 0, 3);
                dl->AddRect({cx-bw*0.5f,   top},   {cx+bw*0.5f,   bottom},   boxCol, 0, 0, 1.5f);
            } else {
                float left = cx-bw*0.5f, right = cx+bw*0.5f;
                float dx = bw*0.25f, dy = (bottom-top)*0.2f;
                for (int ix = 0; ix < 2; ix++) for (int iy = 0; iy < 2; iy++) {
                    ImVec2 corner{ix?right:left, iy?bottom:top};
                    ImVec2 a{corner.x+(ix?-dx:dx), corner.y};
                    ImVec2 b{corner.x, corner.y+(iy?-dy:dy)};
                    dl->AddLine(corner, a, IM_COL32(0,0,0,200), g_options.lineWidth+2);
                    dl->AddLine(corner, b, IM_COL32(0,0,0,200), g_options.lineWidth+2);
                    dl->AddLine(corner, a, boxCol, g_options.lineWidth);
                    dl->AddLine(corner, b, boxCol, g_options.lineWidth);
                }
            }
        }

        // Skeleton
        if (g_options.skeleton) {
            std::array<ImVec2, 17> screen{}; std::array<bool, 17> valid{};
            std::array<V3, 17> worldPos{};
            for (int bi = 0; bi < 17; bi++) {
                bool ok = false;
                if (player.bones[bi] && position(player.bones[bi], worldPos[bi])) ok = true;
                else if (bi==7  && player.bones[6]  && childPosition(player.bones[6],  worldPos[7]))  ok = true;
                else if (bi==10 && player.bones[9]  && childPosition(player.bones[9],  worldPos[10])) ok = true;
                else if (bi==13 && player.bones[12] && childPosition(player.bones[12], worldPos[13])) ok = true;
                else if (bi==16 && player.bones[15] && childPosition(player.bones[15], worldPos[16])) ok = true;
                float unused; if (ok && project(worldPos[bi], v, p, w, h, screen[bi], unused)) valid[bi] = true;
            }
            ImU32 skelCol = ImGui::ColorConvertFloat4ToU32({g_options.skeletonColor[0],g_options.skeletonColor[1],g_options.skeletonColor[2],0.95f});
            for (auto& edge : boneLinks)
                if (valid[edge[0]] && valid[edge[1]]) dl->AddLine(screen[edge[0]], screen[edge[1]], skelCol, 1.8f);
        }

        // Lines
        if (g_options.lines) {
            float fromY = g_options.lineOrigin==0 ? h : g_options.lineOrigin==1 ? h*0.5f : 0.f;
            ImU32 lineCol = ImGui::ColorConvertFloat4ToU32({g_options.linesColor[0],g_options.linesColor[1],g_options.linesColor[2],1});
            dl->AddLine({w*0.5f, fromY}, {cx, bottom}, lineCol, g_options.lineWidth);
        }

        float labelY = bottom + 3.f;

        // İsim
        if (g_options.names) {
            auto sz = ImGui::CalcTextSize(player.name.c_str());
            ImVec2 at{cx - sz.x*0.5f, top - sz.y - 3};
            dl->AddText({at.x+1, at.y+1}, IM_COL32(0,0,0,230), player.name.c_str());
            dl->AddText(at, color, player.name.c_str());
        }

        // Mesafe
        if (g_options.distance) {
            char label[32]; snprintf(label, sizeof(label), "%.0f m", d);
            auto sz = ImGui::CalcTextSize(label);
            ImVec2 at{cx - sz.x*0.5f, labelY};
            dl->AddText({at.x+1, at.y+1}, IM_COL32(0,0,0,230), label);
            dl->AddText(at, color, label);
            labelY += sz.y + 2.f;
        }
    }

    dl->PopClipRect();
}

} // namespace EnemyESP
