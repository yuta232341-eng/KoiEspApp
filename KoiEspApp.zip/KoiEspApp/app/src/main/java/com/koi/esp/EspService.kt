package com.koi.esp

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.FrameLayout
import kotlinx.coroutines.*

class EspService : Service() {

    companion object {
        const val CHANNEL_ID = "koi_esp_channel"
        const val NOTIF_ID   = 1

        init {
            System.loadLibrary("koiesp")
        }
    }

    // JNI
    external fun nativeInit(): Boolean
    external fun nativeUpdate(out: FloatArray, maxPlayers: Int): Int
    external fun nativeGetLocalPos(out: FloatArray)

    // Views
    private var wm: WindowManager? = null
    private var overlayContainer: FrameLayout? = null
    private var espView: EspOverlayView? = null
    private var menuView: EspMenuView? = null

    private var updateJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    // Player data buffer (max 64 players × 5 floats)
    private val playerBuffer = FloatArray(64 * 5)
    private val localBuffer  = FloatArray(4)

    override fun onCreate() {
        super.onCreate()
        createNotifChannel()
        startForeground(NOTIF_ID, buildNotif())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startOverlay()
        return START_STICKY
    }

    private fun startOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        overlayContainer = FrameLayout(this)

        // ESP View (full screen, behind menu)
        espView = EspOverlayView(this)
        overlayContainer!!.addView(espView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Menu View (on top)
        menuView = EspMenuView(this)
        menuView!!.listener = object : EspMenuView.MenuListener {
            override fun onToggleEsp(v: Boolean)   { espView?.espEnabled   = v }
            override fun onToggleBox(v: Boolean)   { espView?.boxEnabled   = v }
            override fun onToggleLine(v: Boolean)  { espView?.lineEnabled  = v }
            override fun onToggleSkel(v: Boolean)  { espView?.skelEnabled  = v }
            override fun onToggleName(v: Boolean)  { espView?.nameEnabled  = v }
            override fun onToggleRadar(v: Boolean) { espView?.radarEnabled = v }
        }
        overlayContainer!!.addView(menuView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        wm!!.addView(overlayContainer, params)

        // Init native + start update loop
        scope.launch {
            val ok = nativeInit()
            if (!ok) return@launch

            while (isActive) {
                nativeGetLocalPos(localBuffer)
                val count = nativeUpdate(playerBuffer, 64)

                withContext(Dispatchers.Main) {
                    espView?.updateLocalPos(localBuffer)
                    espView?.updatePlayers(playerBuffer, count)
                }

                delay(50) // 20 fps update
            }
        }.also { updateJob = it }
    }

    override fun onDestroy() {
        updateJob?.cancel()
        overlayContainer?.let { wm?.removeView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "KOI ESP Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("KOI ESP aktif")
            .setContentText("Overlay calisiyor — 6767")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }
}
