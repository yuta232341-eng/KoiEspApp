# ═══════════════════════════════════════════════════════════════════════════
#  jni/Application.mk — scanner_imgui
# ═══════════════════════════════════════════════════════════════════════════

APP_ABI          := arm64-v8a
APP_PLATFORM     := latest
APP_STL          := c++_static

APP_CPPFLAGS     := -std=gnu++2a -fexceptions
APP_CPPFLAGS     += -fvisibility=hidden
APP_CPPFLAGS     += -ffunction-sections -fdata-sections
APP_CPPFLAGS     += -fomit-frame-pointer
APP_CPPFLAGS     += -DANDROID -DSTANDALONE_BUILD=1 -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS
APP_CPPFLAGS     += -Wall -Wno-unused-parameter -Wno-missing-field-initializers

APP_LDFLAGS      := -pie
APP_LDFLAGS      += -Wl,--gc-sections
APP_LDFLAGS      += -Wl,--hash-style=gnu
APP_LDFLAGS      += -Wl,-z,relro -Wl,-z,now -Wl,-z,noexecstack

ifeq ($(NDK_DEBUG),1)
  APP_OPTIM := debug
  APP_CPPFLAGS += -O0 -g3 -DDEBUG
else
  APP_OPTIM := release
  APP_CPPFLAGS += -O2 -DNDEBUG
endif
