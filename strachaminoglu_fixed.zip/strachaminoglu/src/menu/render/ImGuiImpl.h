#pragma once

#include "imgui/imgui.h"
#include <android/input.h>
#include <android/native_window.h>
#include <EGL/egl.h>
#include <cstdint>

// GL types — fallback для Termux где нет GLES3/gl3.h
#if __has_include(<GLES3/gl3.h>)
    #include <menu/render/gles_compat/gl3.h>
#elif __has_include(<GLES2/gl2.h>)
    #include <GLES2/gl2.h>
#elif __has_include(<gl3.h>)
    #include <menu/render/gles_compat/gl3.h>  // наш gles_compat
#else
    #ifndef GL_API
    typedef unsigned int GLenum;
    typedef unsigned int GLuint;
    typedef int GLint;
    typedef int GLsizei;
    typedef unsigned char GLboolean;
    typedef float GLfloat;
    #endif
#endif

namespace ImGuiImpl {

    bool init(ANativeWindow* window);
    void shutdown();

    void newFrame(float deltaTime);
    void render();

    bool handleTouchEvent(int action, float x, float y, int pointerId);
    bool handleKeyEvent(int keyCode, int action);

    void setDisplaySize(int width, int height);
    void getDisplaySize(int& width, int& height);

    void setMousePos(float x, float y);
    void setMouseDown(bool down);
    void setMouseScroll(float wheel);

    GLuint getFontTexture();
    GLuint getShaderProgram();
}
