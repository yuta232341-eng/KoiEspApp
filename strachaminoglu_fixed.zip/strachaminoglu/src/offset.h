#pragma once
#include <cstdint>

// Offsetlar dump.cs + script.json (TypeInfoPointers) ile doğrulandı.
// Dump tarihi: 2026-10-16

namespace Offsets {

// ── TypeInfo RVA (libil2cpp.so base'den) ─────────────────────────────────
// Kaynak: script.json → TypeInfoPointers[*].Address
// Address değerleri libil2cpp.so'nun yüklendiği base'den offset'tir;
// bu değerler zaten RVA (relative), base eklenince gerçek adres elde edilir.

inline constexpr uint64_t NetworkClientTypeInfo  = 0xDE9FC60;  // Mirror.NetworkClient_TypeInfo  ✓ script.json
inline constexpr uint64_t PlayerManagerTypeInfo  = 0xDEA09F8;  // Oxide.PlayerManager_TypeInfo   ✓ script.json
inline constexpr uint64_t GameControllerTypeInfo = 0xDE9BCA8;  // Oxide.GameController_TypeInfo  ✓ script.json

// ── Oxide.PlayerManager instance fields (dump.cs: TypeDefIndex 9814) ──────
// Base: NetworkBehaviour → MonoBehaviour → Behaviour → Component → Object (0x10)
// NetworkBehaviour ekliyor 0x18 → toplam MonoBehaviour base = 0x18
// Gerçek field offset'leri dump.cs'den direkt alındı.

inline constexpr uint64_t WorldCameraRoot = 0x68;   // Transform worldCameraRoot        ✓
inline constexpr uint64_t MouseLook       = 0x70;   // MouseLook mouseLook              (referans)
inline constexpr uint64_t PlayerEvents    = 0x78;   // hsL playerEventHandler           ✓
inline constexpr uint64_t DeathHandlerRef = 0x80;   // InterfaceReference<hkE>          ✓
inline constexpr uint64_t RaycastManager  = 0x88;   // RaycastManager raycastManager    ✓
inline constexpr uint64_t FPManager       = 0x90;   // FPManager fpManager              ✓
inline constexpr uint64_t WeaponRef       = 0xF0;   // InterfaceReference<Ot> weapon    ✓
inline constexpr uint64_t Nicklabel       = 0x130;  // Il nicklabel                     ✓
inline constexpr uint64_t TeamName        = 0x2A0;  // string teamName [SyncVar]        ✓

// ── Il (nicklabel component, TypeDefIndex 435) ────────────────────────────
// Il.nickname = 0x38 → Text component (UnityEngine.UI.Text)
// Text.m_Text  = 0xE0 → managed string (System.String)
// Dolayısıyla nickname string: P(P(nicklabelObj + 0x38) + 0xE0)
inline constexpr uint64_t NicklabelTextComponent = 0x38;  // Text nickname   ✓ (eskiden NicklabelName)
inline constexpr uint64_t TextMText              = 0xE0;  // Text.m_Text     ✓ (UnityEngine.UI.Text dump)

// ── hsN (PlayerEventHandler base) field ───────────────────────────────────
// Kaynak: hsN class dump — DisplayName = 0x88
// PlayerEvents(0x78) + 0x88 = DisplayName string
inline constexpr uint64_t EventHandlerDisplayName = 0x88;  // string DisplayName  ✓

// ── Oxide.PlayerDeathHandler (TypeDefIndex 9619) ─────────────────────────
// Dump'dan doğrulandı:
//   private PlayerManager player;      // 0x68
//   public bool death;                 // 0xF0  [SyncVar]
//   private bool m_DestroyOnDeath;     // 0xE8  ← eski BotDead burasıydı (HATALI)
inline constexpr uint64_t DeathOwner = 0x68;  // PlayerManager player  ✓
inline constexpr uint64_t PlayerDead = 0xF0;  // bool death [SyncVar]  ✓

// ── NPCHumanoidDeathHandler (TypeDefIndex 4486) ───────────────────────────
// Dump'dan doğrulandı:
//   private bool m_DestroyOnDeath;  // 0xE0
//   public bool death;              // 0xE8  [SyncVar]  ← DÜZELTME (eski 0xE8 yanlış yorumlanmıştı)
//   private bool RPd;               // 0xE9
// NOT: eski kodda BotDead=0xE8 vardı ama comment "m_DestroyOnDeath" diyordu.
// PlayerDeathHandler'da 0xE8 = m_DestroyOnDeath, NPCHumanoidDeathHandler'da 0xE8 = death (doğru!)
// Yani BotDead=0xE8 NPCHumanoidDeathHandler için DOĞRUYDU, sadece yorum yanlıştı.
inline constexpr uint64_t BotDead = 0xE8;  // bool death (NPCHumanoidDeathHandler) ✓ CONFIRMED

// ── Özet: readPlayerNickname okuma zinciri ────────────────────────────────
// Yol 1 (tercih): P(object + PlayerEvents) + EventHandlerDisplayName → managed string
// Yol 2:          P(object + Nicklabel) + NicklabelTextComponent → Text obj
//                 P(textObj + TextMText) → managed string
// Yol 3:          P(object + 0x240) → uKU string (fallback)

} // namespace Offsets
