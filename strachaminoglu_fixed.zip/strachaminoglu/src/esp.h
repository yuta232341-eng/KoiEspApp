#pragma once

// esp.h — Enemy-only ESP
// Referans: OreESP::playerNodes pipeline (VMABCDEmerged/OreEsp.h)
// Sadece düşman oyuncuları gösterir. Ore/crate yok. Bot toggle var.

#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include <unordered_map>
#include <chrono>
#include <cmath>

#include "offset.h"

// ─── Shared memory reader (PlayerSnapshot.h'dan alınan aynı Reader) ───────
// esp.cpp include eder; burada sadece forward declaration yeterli.
namespace Snapshot { struct Reader; }

namespace EnemyESP {

// ── Basit vektör ──────────────────────────────────────────────────────────
struct V3 { float x, y, z; };

// ── Oyuncu verisi ─────────────────────────────────────────────────────────
struct PlayerNode {
    uint64_t object    = 0;
    uint64_t transform = 0;
    uint64_t head      = 0;
    uint64_t klass     = 0;
    uint64_t identity  = 0;
    uint64_t deathHandler = 0;
    std::string name;
    std::array<uint64_t, 17> bones{};
    bool bot      = false;
    bool teammate = false;
    V3   velocity { 0, 0, 0 };
};

// ── Çizim seçenekleri ─────────────────────────────────────────────────────
struct Options {
    bool enabled    = true;
    bool boxes      = true;
    bool names      = true;
    bool distance   = true;
    bool skeleton   = true;
    bool bots       = true;
    bool lines      = false;
    int  boxStyle   = 0;        // 0 = full rect, 1 = corner brackets
    int  lineOrigin = 0;        // 0 = bottom, 1 = center, 2 = top
    float lineWidth = 1.5f;
    float range     = 350.f;

    float playerColor[3]  = { 1.f, 1.f, 1.f };
    float boxColor[3]     = { 1.f, 1.f, 1.f };
    float botColor[3]     = { 1.f, 0.75f, 0.25f };
    float teamColor[3]    = { 0.25f, 1.f, 0.4f };
    float deadColor[3]    = { 0.6f, 0.6f, 0.6f };
    float skeletonColor[3]= { 0.2f, 1.f, 0.2f };
    float linesColor[3]   = { 1.f, 1.f, 1.f };
};

extern Options g_options;

// ── Genel durum ───────────────────────────────────────────────────────────
extern uint64_t g_base;         // libil2cpp.so base
extern uint64_t g_camera;       // native camera transform
extern uint64_t g_localPlayer;  // local PlayerManager
extern pid_t    g_targetPid;

extern std::vector<PlayerNode> g_players;
extern int g_playerCount;
extern int g_botCount;
extern std::string g_status;

// ── API ───────────────────────────────────────────────────────────────────

// Projeye bağlan (root gerekli). Her frame kontrol edilir, döndü mü diye.
bool attach();

// Oyuncu listesini güncelle (incremental slice, render thread'de çağır).
// true = devam et / false = reset gerekli.
bool scan(bool incremental = true);

// ImGui BackgroundDrawList'e ESP çiz.
// w, h = ekran boyutu (overlay.getWidth/Height).
void draw(float w, float h);

// Temizle ve yeniden bağlanmayı zorla.
void reset();

} // namespace EnemyESP
