package com.koi.esp

import android.content.Context
import android.graphics.*
import android.view.View

class EspOverlayView(context: Context) : View(context) {

    // ESP feature flags
    var espEnabled   = true
    var boxEnabled   = true
    var lineEnabled  = true
    var skelEnabled  = false
    var nameEnabled  = true
    var radarEnabled = true

    // Player data from native layer [x,y,z,hp,maxhp] * N
    private val playerData = FloatArray(512 * 5)
    private var playerCount = 0

    // Local pos/yaw
    private val localPos = FloatArray(4)

    // Screen size
    private var sw = 1080f
    private var sh = 1920f

    // ── Paints ───────────────────────────────────────────────
    private val paintBox = Paint().apply {
        style = Paint.Style.STROKE; color = Color.RED; strokeWidth = 2f; isAntiAlias = true
    }
    private val paintLine = Paint().apply {
        color = Color.CYAN; strokeWidth = 1.5f; isAntiAlias = true
    }
    private val paintText = Paint().apply {
        color = Color.WHITE; textSize = 28f; isAntiAlias = true
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val paintHpBg = Paint().apply {
        color = Color.parseColor("#AA000000"); style = Paint.Style.FILL
    }
    private val paintHp = Paint().apply {
        color = Color.GREEN; style = Paint.Style.FILL
    }
    private val paintRadarBg = Paint().apply {
        color = Color.parseColor("#AA000000"); style = Paint.Style.FILL
    }
    private val paintRadarBorder = Paint().apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 1f
    }
    private val paintRadarDot = Paint().apply {
        color = Color.RED; style = Paint.Style.FILL
    }
    private val paintRadarSelf = Paint().apply {
        color = Color.GREEN; style = Paint.Style.FILL
    }

    // ── Update from service ──────────────────────────────────
    fun updatePlayers(data: FloatArray, count: Int) {
        data.copyInto(playerData, 0, 0, count * 5)
        playerCount = count
        postInvalidate()
    }

    fun updateLocalPos(pos: FloatArray) {
        pos.copyInto(localPos)
    }

    // ── World to Screen (simple perspective) ────────────────
    private fun worldToScreen(wx: Float, wy: Float, wz: Float): PointF? {
        // Camera assumed at localPos, simple perspective projection
        // FOV 60 degrees
        val dx = wx - localPos[0]
        val dy = wy - localPos[1]
        val dz = wz - localPos[2]

        val yaw = localPos[3] * (Math.PI / 180.0).toFloat()
        val cosY = Math.cos(yaw.toDouble()).toFloat()
        val sinY = Math.sin(yaw.toDouble()).toFloat()

        // Rotate around Y axis
        val rx =  dx * cosY - dz * sinY
        val ry = dy
        val rz =  dx * sinY + dz * cosY

        if (rz <= 0.1f) return null  // behind camera

        val fov = 60f * (Math.PI / 180.0).toFloat()
        val f = (sw / 2f) / Math.tan((fov / 2.0).toDouble()).toFloat()

        val sx = sw / 2f + rx * f / rz
        val sy = sh / 2f - ry * f / rz
        return PointF(sx, sy)
    }

    // ── Draw ─────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!espEnabled) return

        sw = width.toFloat()
        sh = height.toFloat()

        for (i in 0 until playerCount) {
            val off = i * 5
            val wx = playerData[off + 0]
            val wy = playerData[off + 1]
            val wz = playerData[off + 2]
            val hp    = playerData[off + 3]
            val maxhp = playerData[off + 4]

            val head = worldToScreen(wx, wy + 1.8f, wz) ?: continue
            val feet = worldToScreen(wx, wy, wz) ?: continue

            val dist = Math.sqrt(
                ((wx - localPos[0]).toDouble().pow(2) +
                 (wy - localPos[1]).toDouble().pow(2) +
                 (wz - localPos[2]).toDouble().pow(2))
            ).toFloat()

            // BOX
            if (boxEnabled) {
                val h = feet.y - head.y
                val w = h * 0.4f
                val left  = head.x - w / 2f
                val right = head.x + w / 2f
                canvas.drawRect(left, head.y, right, feet.y, paintBox)

                // HP bar (left of box)
                val barH = h
                val barW = 5f
                val hpFrac = (hp / maxhp).coerceIn(0f, 1f)
                paintHpBg.color = Color.parseColor("#AA000000")
                canvas.drawRect(left - barW - 2f, head.y, left - 2f, head.y + barH, paintHpBg)
                paintHp.color = when {
                    hpFrac > 0.6f -> Color.GREEN
                    hpFrac > 0.3f -> Color.YELLOW
                    else          -> Color.RED
                }
                canvas.drawRect(left - barW - 2f, head.y + barH * (1f - hpFrac),
                                left - 2f, head.y + barH, paintHp)
            }

            // LINE
            if (lineEnabled) {
                canvas.drawLine(sw / 2f, sh, head.x, head.y, paintLine)
            }

            // NAME + DIST
            if (nameEnabled) {
                val label = "Player  ${dist.toInt()}m  ${hp.toInt()}HP"
                canvas.drawText(label, head.x - paintText.measureText(label) / 2f,
                                head.y - 6f, paintText)
            }
        }

        // RADAR 360
        if (radarEnabled) drawRadar(canvas)
    }

    private fun Double.pow(exp: Double) = Math.pow(this, exp)

    private fun drawRadar(canvas: Canvas) {
        val rX = sw - 170f
        val rY = 170f
        val rR = 150f

        canvas.drawCircle(rX, rY, rR, paintRadarBg)
        canvas.drawCircle(rX, rY, rR, paintRadarBorder)
        // cross hairs
        canvas.drawLine(rX - rR, rY, rX + rR, rY, paintRadarBorder)
        canvas.drawLine(rX, rY - rR, rX, rY + rR, paintRadarBorder)

        // self dot
        canvas.drawCircle(rX, rY, 5f, paintRadarSelf)

        val yaw = localPos[3] * (Math.PI / 180.0).toFloat()
        val maxDist = 200f  // radar range (meters)

        for (i in 0 until playerCount) {
            val off = i * 5
            val dx = playerData[off + 0] - localPos[0]
            val dz = playerData[off + 2] - localPos[2]
            val dist = Math.sqrt((dx * dx + dz * dz).toDouble()).toFloat()
            if (dist > maxDist) continue

            val angle = Math.atan2(dx.toDouble(), dz.toDouble()).toFloat() - yaw
            val scaledDist = (dist / maxDist) * rR
            val dotX = rX + scaledDist * Math.sin(angle.toDouble()).toFloat()
            val dotY = rY - scaledDist * Math.cos(angle.toDouble()).toFloat()
            canvas.drawCircle(dotX, dotY, 5f, paintRadarDot)
        }
    }
}
