// ═══════════════════════════════════════════════════════════════════════════
//  gles_compat/gl3.h — минимальные определения GLES3 для Termux
//
//  В Termux нет GLES3/gl3.h (это часть Android NDK). Этот файл даёт
//  только то что нужно нашему проекту — типы и константы.
//
//  Сами OpenGL ES функции резолвятся в runtime через eglGetProcAddress
//  или линкуются из libGLESv3.so.
// ═══════════════════════════════════════════════════════════════════════════
#pragma once

#include <stdint.h>
#include <cstddef>  // ptrdiff_t

// GL_APICALL/GL_APIENTRY — calling convention макросы (как в настоящем GLES)
#ifndef GL_APICALL
    #define GL_APICALL
#endif
#ifndef GL_APIENTRY
    #define GL_APIENTRY
#endif

#ifdef __cplusplus
extern "C" {
#endif

// ─── Типы ─────────────────────────────────────────────────────────────────────
typedef unsigned int GLenum;
typedef unsigned int GLuint;
typedef int GLint;
typedef int GLsizei;
typedef unsigned char GLboolean;
typedef float GLfloat;
typedef unsigned int GLbitfield;
typedef ptrdiff_t GLsizeiptr;
typedef ptrdiff_t GLintptr;
typedef char GLchar;
typedef unsigned char GLubyte;
typedef void GLvoid;

// ─── Константы ────────────────────────────────────────────────────────────────
#define GL_NO_ERROR                        0
#define GL_FALSE                           0
#define GL_TRUE                            1
#define GL_POINTS                          0x0000
#define GL_LINES                           0x0001
#define GL_LINE_LOOP                       0x0002
#define GL_LINE_STRIP                      0x0003
#define GL_TRIANGLES                       0x0004
#define GL_TRIANGLE_STRIP                  0x0005
#define GL_TRIANGLE_FAN                    0x0006

#define GL_NEVER                           0x0200
#define GL_LESS                            0x0201
#define GL_EQUAL                           0x0202
#define GL_LEQUAL                          0x0203
#define GL_GREATER                         0x0204
#define GL_NOTEQUAL                        0x0205
#define GL_GEQUAL                          0x0206
#define GL_ALWAYS                          0x0207

#define GL_ZERO                            0
#define GL_ONE                             1
#define GL_SRC_COLOR                       0x0300
#define GL_ONE_MINUS_SRC_COLOR             0x0301
#define GL_SRC_ALPHA                       0x0302
#define GL_ONE_MINUS_SRC_ALPHA             0x0303
#define GL_DST_ALPHA                       0x0304
#define GL_ONE_MINUS_DST_ALPHA             0x0305
#define GL_DST_COLOR                       0x0306
#define GL_ONE_MINUS_DST_COLOR             0x0307
#define GL_SRC_ALPHA_SATURATE              0x0308

#define GL_FRONT                           0x0404
#define GL_BACK                            0x0405
#define GL_FRONT_AND_BACK                  0x0408

#define GL_CULL_FACE                       0x0B44
#define GL_BLEND                           0x0BE2
#define GL_DITHER                          0x0BD0
#define GL_STENCIL_TEST                    0x0B90
#define GL_DEPTH_TEST                      0x0B71
#define GL_SCISSOR_TEST                    0x0C11
#define GL_VIEWPORT                         0x0BA2
#ifndef GL_COLOR_BUFFER_BIT
#define GL_COLOR_BUFFER_BIT                0x4000
#endif
#ifndef GL_DEPTH_BUFFER_BIT
#define GL_DEPTH_BUFFER_BIT                0x0100
#endif
#ifndef GL_STENCIL_BUFFER_BIT
#define GL_STENCIL_BUFFER_BIT              0x0400
#endif
#define GL_FRAMEBUFFER_BINDING             0x8CA6
#define GL_SCISSOR_BOX                     0x0C10

#define GL_BYTE                            0x1400
#define GL_UNSIGNED_BYTE                   0x1401
#define GL_SHORT                           0x1402
#define GL_UNSIGNED_SHORT                  0x1403
#define GL_INT                             0x1404
#define GL_UNSIGNED_INT                    0x1405
#define GL_FLOAT                           0x1406

#define GL_TEXTURE_2D                      0x0DE1
#define GL_TEXTURE                         0x1702
#define GL_R                               0x1903
#define GL_RG                              0x8227
#define GL_RED                             0x1903
#define GL_RGB                             0x1907
#define GL_RGBA                            0x1908
#define GL_LUMINANCE                       0x1909
#define GL_LUMINANCE_ALPHA                 0x190A
#define GL_ALPHA                           0x1906
#define GL_RGB8                            0x8051
#define GL_RGBA8                           0x8058
#define GL_RGBA4                           0x8056
#define GL_RGB5_A1                         0x8057

#define GL_NEAREST                         0x2600
#define GL_LINEAR                          0x2601
#define GL_NEAREST_MIPMAP_NEAREST          0x2700
#define GL_LINEAR_MIPMAP_NEAREST            0x2701
#define GL_NEAREST_MIPMAP_LINEAR            0x2702
#define GL_LINEAR_MIPMAP_LINEAR             0x2703

#define GL_TEXTURE_MAG_FILTER              0x2800
#define GL_TEXTURE_MIN_FILTER              0x2801
#define GL_TEXTURE_WRAP_S                  0x2802
#define GL_TEXTURE_WRAP_T                  0x2803
#define GL_TEXTURE_BASE_LEVEL              0x813C
#define GL_TEXTURE_MAX_LEVEL               0x813D
#define GL_CLAMP_TO_EDGE                   0x812F
#define GL_REPEAT                          0x2901
#define GL_MIRRORED_REPEAT                 0x8370

#define GL_FLAT                            0x1D00
#define GL_SMOOTH                          0x1D01
#define GL_VENDOR                          0x1F00
#define GL_RENDERER                        0x1F01
#define GL_VERSION                         0x1F02
#define GL_EXTENSIONS                      0x1F03
#define GL_SHADING_LANGUAGE_VERSION        0x8B8C

#define GL_UNPACK_ALIGNMENT                0x0CF5
#define GL_PACK_ALIGNMENT                  0x0D05
#define GL_UNPACK_ROW_LENGTH                0x0CF2
#ifndef GL_UNPACK_SKIP_ROWS
#define GL_UNPACK_SKIP_ROWS                0x0CF4
#endif
#ifndef GL_UNPACK_SKIP_PIXELS
#define GL_UNPACK_SKIP_PIXELS              0x0CF3
#endif

#define GL_ARRAY_BUFFER                    0x8892
#define GL_ELEMENT_ARRAY_BUFFER            0x8893
#define GL_ARRAY_BUFFER_BINDING            0x8894
#define GL_ELEMENT_ARRAY_BUFFER_BINDING    0x8895
#define GL_STATIC_DRAW                     0x88E4
#define GL_DYNAMIC_DRAW                    0x88E8
#define GL_STREAM_DRAW                     0x88E0

#define GL_VERTEX_SHADER                   0x8B31
#define GL_FRAGMENT_SHADER                 0x8B30
#define GL_COMPILE_STATUS                  0x8B81
#define GL_LINK_STATUS                     0x8B82
#define GL_CURRENT_PROGRAM                  0x8B8D
#define GL_ACTIVE_UNIFORMS                 0x8B86
#define GL_ACTIVE_ATTRIBUTES               0x8B89

#define GL_FRAMEBUFFER                      0x8D40
#define GL_COLOR_ATTACHMENT0               0x8CE0
#define GL_FRAMEBUFFER_COMPLETE            0x8CD5

#define GL_BLEND_EQUATION                  0x8009
#define GL_BLEND_EQUATION_RGB              0x8009
#define GL_BLEND_EQUATION_ALPHA            0x883D
#define GL_FUNC_ADD                        0x8006
#define GL_FUNC_SUBTRACT                   0x800A
#define GL_FUNC_REVERSE_SUBTRACT           0x800B
#define GL_BLEND_DST_RGB                   0x80C8
#define GL_BLEND_SRC_RGB                   0x80C9
#define GL_BLEND_DST_ALPHA                 0x80CA
#define GL_BLEND_SRC_ALPHA                 0x80CB

#define GL_TEXTURE0                        0x84C0
#define GL_TEXTURE1                        0x84C1
#define GL_TEXTURE2                        0x84C2
#define GL_TEXTURE3                        0x84C3
#define GL_ACTIVE_TEXTURE                  0x84E0
#define GL_TEXTURE_BINDING_2D               0x8069
#ifndef GL_VERTEX_ARRAY_BINDING
#define GL_VERTEX_ARRAY_BINDING             0x82B8
#endif
#define GL_ARRAY_BUFFER_BINDING             0x8894
#define GL_ELEMENT_ARRAY_BUFFER_BINDING     0x8895
#define GL_CURRENT_PROGRAM                  0x8B8D
#define GL_INFO_LOG_LENGTH                  0x8B84
#define GL_SHADER_SOURCE_LENGTH             0x8B88
#ifndef GL_NUM_EXTENSIONS
#define GL_NUM_EXTENSIONS                  0x8036
#endif
#define GL_NUM_PROGRAM_BINARY_FORMATS       0x87FE
#define GL_FRAMEBUFFER_BINDING              0x8CA6
#define GL_DRAW_FRAMEBUFFER_BINDING         0x8CA6
#define GL_READ_FRAMEBUFFER_BINDING          0x8CAA
#define GL_GENERATE_MIPMAP_HINT             0x8192
#define GL_DONT_CARE                        0x1100
#define GL_FASTEST                          0x1101
#define GL_NICEST                           0x1102
#define GL_CLAMP_TO_BORDER                  0x812D
#define GL_DEPTH_COMPONENT16                 0x81A5
#define GL_DEPTH_COMPONENT24                 0x81A6
#define GL_DEPTH_COMPONENT32F                0x8CAC
#define GL_DEPTH_STENCIL                     0x84F9
#define GL_UNSIGNED_INT_24_8                0x84FA

// ─── Функции (динамически линкуемые из libGLESv3.so / libGLESv2.so) ─────────
// Termux: libGLESv2.so доступна через /system/lib64/
// Нам достаточно объявить прототипы — компоновщик найдёт символы.

GL_APICALL void           GL_APIENTRY glClear (GLbitfield mask);
GL_APICALL void           GL_APIENTRY glClearColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
GL_APICALL void           GL_APIENTRY glViewport (GLint x, GLint y, GLsizei width, GLsizei height);
GL_APICALL void           GL_APIENTRY glEnable (GLenum cap);
GL_APICALL void           GL_APIENTRY glDisable (GLenum cap);
GL_APICALL void           GL_APIENTRY glBlendFunc (GLenum sfactor, GLenum dfactor);
GL_APICALL void           GL_APIENTRY glBlendFuncSeparate (GLenum srcRGB, GLenum dstRGB, GLenum srcA, GLenum dstA);
GL_APICALL void           GL_APIENTRY glBlendEquation (GLenum mode);
GL_APICALL void           GL_APIENTRY glScissor (GLint x, GLint y, GLsizei width, GLsizei height);
GL_APICALL void           GL_APIENTRY glGenTextures (GLsizei n, GLuint* textures);
GL_APICALL void           GL_APIENTRY glDeleteTextures (GLsizei n, const GLuint* textures);
GL_APICALL void           GL_APIENTRY glBindTexture (GLenum target, GLuint texture);
GL_APICALL void           GL_APIENTRY glTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void* pixels);
GL_APICALL void           GL_APIENTRY glTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void* pixels);
GL_APICALL void           GL_APIENTRY glTexParameteri (GLenum target, GLenum pname, GLint param);
GL_APICALL void           GL_APIENTRY glTexParameterf (GLenum target, GLenum pname, GLfloat param);
GL_APICALL void           GL_APIENTRY glActiveTexture (GLenum texture);
GL_APICALL void           GL_APIENTRY glPixelStorei (GLenum pname, GLint param);
GL_APICALL void           GL_APIENTRY glHint (GLenum target, GLenum mode);
GL_APICALL void           GL_APIENTRY glGenerateMipmap (GLenum target);
GL_APICALL void           GL_APIENTRY glGenVertexArrays (GLsizei n, GLuint* arrays);
GL_APICALL void           GL_APIENTRY glDeleteVertexArrays (GLsizei n, const GLuint* arrays);
GL_APICALL void           GL_APIENTRY glBindVertexArray (GLuint array);
GL_APICALL void           GL_APIENTRY glGenFramebuffers (GLsizei n, GLuint* framebuffers);
GL_APICALL void           GL_APIENTRY glDeleteFramebuffers (GLsizei n, const GLuint* framebuffers);
GL_APICALL void           GL_APIENTRY glBindFramebuffer (GLenum target, GLuint framebuffer);
GL_APICALL void           GL_APIENTRY glFramebufferTexture2D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
GL_APICALL void           GL_APIENTRY glGenBuffers (GLsizei n, GLuint* buffers);
GL_APICALL void           GL_APIENTRY glDeleteBuffers (GLsizei n, const GLuint* buffers);
GL_APICALL void           GL_APIENTRY glBindBuffer (GLenum target, GLuint buffer);
GL_APICALL void           GL_APIENTRY glBufferData (GLenum target, GLsizeiptr size, const void* data, GLenum usage);
GL_APICALL void           GL_APIENTRY glBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, const void* data);
GL_APICALL GLuint         GL_APIENTRY glCreateShader (GLenum type);
GL_APICALL void           GL_APIENTRY glShaderSource (GLuint shader, GLsizei count, const GLchar* const* string, const GLint* length);
GL_APICALL void           GL_APIENTRY glCompileShader (GLuint shader);
GL_APICALL void           GL_APIENTRY glGetShaderiv (GLuint shader, GLenum pname, GLint* params);
GL_APICALL void           GL_APIENTRY glGetShaderInfoLog (GLuint shader, GLsizei bufSize, GLsizei* length, GLchar* infoLog);
GL_APICALL void           GL_APIENTRY glDeleteShader (GLuint shader);
GL_APICALL GLuint         GL_APIENTRY glCreateProgram (void);
GL_APICALL void           GL_APIENTRY glAttachShader (GLuint program, GLuint shader);
GL_APICALL void           GL_APIENTRY glLinkProgram (GLuint program);
GL_APICALL void           GL_APIENTRY glUseProgram (GLuint program);
GL_APICALL void           GL_APIENTRY glDeleteProgram (GLuint program);
GL_APICALL void           GL_APIENTRY glGetProgramiv (GLuint program, GLenum pname, GLint* params);
GL_APICALL void           GL_APIENTRY glGetProgramInfoLog (GLuint program, GLsizei bufSize, GLsizei* length, GLchar* infoLog);
GL_APICALL GLint          GL_APIENTRY glGetUniformLocation (GLuint program, const GLchar* name);
GL_APICALL GLint          GL_APIENTRY glGetAttribLocation (GLuint program, const GLchar* name);
GL_APICALL void           GL_APIENTRY glUniformMatrix4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat* value);
GL_APICALL void           GL_APIENTRY glUniform1i (GLint location, GLint x);
GL_APICALL void           GL_APIENTRY glEnableVertexAttribArray (GLuint index);
GL_APICALL void           GL_APIENTRY glDisableVertexAttribArray (GLuint index);
GL_APICALL void           GL_APIENTRY glVertexAttribPointer (GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void* pointer);
GL_APICALL void           GL_APIENTRY glVertexAttribDivisor (GLuint index, GLuint divisor);
GL_APICALL void           GL_APIENTRY glDrawElements (GLenum mode, GLsizei count, GLenum type, const void* indices);
GL_APICALL void           GL_APIENTRY glDrawArrays (GLenum mode, GLint first, GLsizei count);
GL_APICALL void           GL_APIENTRY glGetIntegerv (GLenum pname, GLint* data);
GL_APICALL const GLubyte* GL_APIENTRY glGetString (GLenum name);
GL_APICALL const GLubyte* GL_APIENTRY glGetStringi (GLenum name, GLuint index);
GL_APICALL void           GL_APIENTRY glReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void* pixels);
GL_APICALL void           GL_APIENTRY glGetFloatv (GLenum pname, GLfloat* data);
GL_APICALL void           GL_APIENTRY glGetBooleanv (GLenum pname, GLboolean* data);
GL_APICALL void           GL_APIENTRY glGetVertexAttribiv (GLuint index, GLenum pname, GLint* params);
GL_APICALL void           GL_APIENTRY glGetVertexAttribPointerv (GLuint index, GLenum pname, void** pointer);
GL_APICALL void           GL_APIENTRY glGetAttachedShaders (GLuint program, GLsizei maxCount, GLsizei* count, GLuint* shaders);

#ifdef __cplusplus
}
#endif
