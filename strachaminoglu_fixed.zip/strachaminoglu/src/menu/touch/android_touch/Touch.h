#pragma once

#include <cstdint>
#include <atomic>

// Forward declaration
struct ImGuiIO;

namespace touch {
    bool init(int32_t _screen_w, int32_t _screen_h, uint8_t _orientation);
    void update(int32_t _screen_w, int32_t _screen_h, uint8_t _orientation);
    void updateOrientation(uint8_t _orientation);
    void shutdown();

    // Вызывать после ImGui::CreateContext() чтобы Touch мог пушить события
    void setImGuiIO(ImGuiIO* io);

    // v14: ВЫЗЫВАТЬ ИЗ RENDER-ПОТОКА перед ImGui::NewFrame().
    // Тач-поток больше НЕ трогает ImGuiIO напрямую (гонки с NewFrame/EndFrame
    // рвали события: меню не открывалось по чипу, драг дёргался). Вместо этого
    // тач-поток кладёт события в очередь под мьютексом, а рендер-поток
    // выкачивает её раз в кадр — ImGui трогает только один поток.
    void pumpImGui();

    // ═══ v65/v66: состояние пальца для TOUCH-аима ═══════════════════════
    // v66: мультитач — отдаёт ЛУЧШИЙ контакт из ВСЕХ активных слотов:
    // приоритет у правой половины экрана (аим-зона), среди равных — самый
    // свежий. Аим-палец может быть вторым/третьим касанием, палец на
    // джойстике ему не мешает. Координаты — экранные (система ImGui).
    // Потокобезопасно (атомики).
    bool isScreenTouchDown(float* outX = nullptr, float* outY = nullptr);

    // v77g: volume-down → menu toggle request (set by touch thread, consumed by render thread)
    extern std::atomic<bool> g_menuToggleRequest;
}
