# ═══════════════════════════════════════════════════════════════════════════
#  jni/Android.mk — imgui
#
#  Dear ImGui overlay (SurfaceFlingerOverlay backend)
#  Output: libs/arm64-v8a/imgui
# ═══════════════════════════════════════════════════════════════════════════

LOCAL_PATH := $(call my-dir)/..

include $(CLEAR_VARS)

LOCAL_MODULE := imgui.sh

LOCAL_SRC_FILES := \
    src/main.cpp \
    src/esp.cpp \
    src/imgui/imgui.cpp \
    src/imgui/imgui_draw.cpp \
    src/imgui/imgui_tables.cpp \
    src/imgui/imgui_widgets.cpp \
    src/menu/render/ImGuiImpl.cpp \
    src/menu/render/ShaderManager.cpp \
    src/menu/render/TextureLoader.cpp \
    src/menu/overlay/SurfaceFlingerOverlay.cpp \
    src/menu/touch/android_touch/Touch.cpp

LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/src

LOCAL_CFLAGS := \
    -DANDROID -DSTANDALONE_BUILD=1 \
    -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS \
    -fvisibility=hidden \
    -ffunction-sections -fdata-sections \
    -fomit-frame-pointer \
    -Wall -Wno-unused-parameter -Wno-missing-field-initializers

LOCAL_CPPFLAGS := \
    -std=gnu++2a \
    -fexceptions

LOCAL_LDLIBS := \
    -lEGL -lGLESv3 -landroid -llog -ldl -lm

LOCAL_LDFLAGS := \
    -pie \
    -Wl,--gc-sections \
    -Wl,--hash-style=gnu \
    -Wl,-z,relro -Wl,-z,now -Wl,-z,noexecstack

include $(BUILD_EXECUTABLE)
