#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════════════════
#  compile.sh — scanner_imgui (ImGui overlay + IL2CPP scanner)
#
#  AIDE crustacean → AIDE clone → PATH ndk-build sırasıyla dener
#  Output: libs/arm64-v8a/scanner_imgui
# ═══════════════════════════════════════════════════════════════════════════
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "===================================================="
echo "  scanner_imgui — Building with AIDE NDK"
echo "  Project: $PROJECT_DIR"
echo "===================================================="

# ─── Varyant 1: AIDE crustacean ──────────────────────────────────────────
AIDE_NDK_CRUSTACEAN="/data/user/0/com.aide.ui.crustacean/no_backup/ndksupport-1710240003/android-ndk-aide"
if [ -x "$AIDE_NDK_CRUSTACEAN/ndk-build" ]; then
    echo "  ndk-build: $AIDE_NDK_CRUSTACEAN/ndk-build (crustacean)"
    echo "===================================================="
    export NDK_PROJECT_PATH="$PROJECT_DIR"
    "$AIDE_NDK_CRUSTACEAN/ndk-build" clean >/dev/null 2>&1 || true
    "$AIDE_NDK_CRUSTACEAN/ndk-build" "$@"
    exit $?
fi

# ─── Varyant 2: AIDE clone ───────────────────────────────────────────────
AIDE_NDK_CLONE="/data/user/0/com.aide.clone/no_backup/ndksupport-1710240003/android-ndk-aide"
if [ -x "$AIDE_NDK_CLONE/ndk-build" ]; then
    echo "  ndk-build: $AIDE_NDK_CLONE/ndk-build (clone)"
    echo "===================================================="
    export NDK_PROJECT_PATH="$PROJECT_DIR"
    "$AIDE_NDK_CLONE/ndk-build" clean >/dev/null 2>&1 || true
    "$AIDE_NDK_CLONE/ndk-build" "$@"
    exit $?
fi

# ─── Varyant 3: PATH'de ndk-build ────────────────────────────────────────
if command -v ndk-build >/dev/null 2>&1; then
    echo "  Using ndk-build from PATH"
    echo "===================================================="
    export NDK_PROJECT_PATH="$PROJECT_DIR"
    ndk-build clean >/dev/null 2>&1 || true
    ndk-build "$@"
    exit $?
fi

# ─── Hata ────────────────────────────────────────────────────────────────
echo ""
echo "[ERROR] AIDE NDK bulunamadi."
echo "AIDE uygulamasinin yuklu ve NDK support'un aktif oldugundan emin ol."
echo ""
exit 1
