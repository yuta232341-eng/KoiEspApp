#pragma once

// ═══════════════════════════════════════════════════════════════════════════
//  ShaderManager.h
//
//  Работает в NDK и Termux (через fallback GL типов).
// ═══════════════════════════════════════════════════════════════════════════

#include <EGL/egl.h>

#if __has_include(<GLES3/gl3.h>)
    #include <menu/render/gles_compat/gl3.h>
#elif __has_include(<GLES2/gl2.h>)
    #include <GLES2/gl2.h>
#elif __has_include(<gl3.h>)
    #include <menu/render/gles_compat/gl3.h>  // наш gles_compat
#else
    #ifndef GL_API
    typedef unsigned int GLenum;
    typedef unsigned int GLuint;
    typedef int GLint;
    typedef int GLsizei;
    typedef unsigned char GLboolean;
    typedef float GLfloat;
    typedef unsigned int GLbitfield;
    #endif
#endif

#ifndef GL_RGBA
    #define GL_RGBA 0x1908
#endif
#ifndef GL_FLOAT
    #define GL_FLOAT 0x1406
#endif
#ifndef GL_UNSIGNED_BYTE
    #define GL_UNSIGNED_BYTE 0x1401
#endif
#ifndef GL_FALSE
    #define GL_FALSE 0
#endif
#ifndef GL_TRUE
    #define GL_TRUE 1
#endif
#ifndef GL_ARRAY_BUFFER
    #define GL_ARRAY_BUFFER 0x8892
#endif
#ifndef GL_ELEMENT_ARRAY_BUFFER
    #define GL_ELEMENT_ARRAY_BUFFER 0x8893
#endif
#ifndef GL_STATIC_DRAW
    #define GL_STATIC_DRAW 0x88E4
#endif
#ifndef GL_VERTEX_SHADER
    #define GL_VERTEX_SHADER 0x8B31
#endif
#ifndef GL_FRAGMENT_SHADER
    #define GL_FRAGMENT_SHADER 0x8B30
#endif
#ifndef GL_COMPILE_STATUS
    #define GL_COMPILE_STATUS 0x8B81
#endif
#ifndef GL_LINK_STATUS
    #define GL_LINK_STATUS 0x8B82
#endif
#ifndef GL_CURRENT_PROGRAM
    #define GL_CURRENT_PROGRAM 0x8B8D
#endif
#ifndef GL_TRIANGLES
    #define GL_TRIANGLES 0x0004
#endif
#ifndef GL_TEXTURE0
    #define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_TEXTURE_2D
    #define GL_TEXTURE_2D 0x0DE1
#endif

#include <string>

class ShaderManager {
public:
    bool initialize();
    void shutdown();
    bool isReady() const { return m_ready; }

    struct ImGuiShaders {
        GLuint program     = 0;
        GLint  projMtxLoc  = -1;
        GLint  textureLoc  = -1;
        GLint  positionLoc = -1;
        GLint  uvLoc       = -1;
        GLint  colorLoc    = -1;
    };

    const ImGuiShaders& getImGuiShaders() const { return m_imgui; }

    static GLuint compileShader(GLenum type, const char* source, std::string* err = nullptr);
    static GLuint linkProgram(GLuint vs, GLuint fs, std::string* err = nullptr);

private:
    ImGuiShaders m_imgui;
    bool m_ready = false;

    static const char* VERT_SRC;
    static const char* FRAG_SRC;
};
