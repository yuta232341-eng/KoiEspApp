#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════════════════
#  deploy.sh — Strachaminoglu ESP  |  UGPhone root deploy
#
#  Kullanım (PC'den):
#    adb push deploy.sh /data/local/tmp/
#    adb shell "su -c 'sh /data/local/tmp/deploy.sh'"
#
#  Ya da doğrudan cihazda root terminal ile:
#    sh /sdcard/strachaminoglu/deploy.sh
#
#  Ne yapar:
#    1. Binary'yi /data/local/tmp/imgui.sh'e kopyalar
#    2. Çalışma iznini verir
#    3. Oxide: Survival Island'ın PID'ini bulur
#    4. Binary'yi arka planda başlatır
#    5. Logcat'i filtreler (EnemyESP tag)
# ═══════════════════════════════════════════════════════════════════════════
set -e

BINARY_NAME="imgui.sh"
TARGET_PKG="com.catsbit.oxidesurvivalisland"
DEPLOY_DIR="/data/local/tmp"
BINARY_SRC="$(cd "$(dirname "$0")" && pwd)/libs/arm64-v8a/$BINARY_NAME"
BINARY_DST="$DEPLOY_DIR/$BINARY_NAME"

echo "============================================"
echo "  Strachaminoglu ESP — Deploy"
echo "============================================"

# ── Root kontrolü ─────────────────────────────────────────────────────────
if [ "$(id -u)" != "0" ]; then
    echo "[!] Root gerekli. 'su -c' ile çalıştır."
    exit 1
fi
echo "[+] Root OK"

# ── Binary var mı? ─────────────────────────────────────────────────────────
if [ ! -f "$BINARY_SRC" ]; then
    echo "[!] Binary bulunamadı: $BINARY_SRC"
    echo "    Önce compile.sh ile derle."
    exit 1
fi

# ── Kopyala ve izin ver ───────────────────────────────────────────────────
cp "$BINARY_SRC" "$BINARY_DST"
chmod 755 "$BINARY_DST"
echo "[+] Binary kopyalandı: $BINARY_DST"

# ── Eski instance'ı öldür ─────────────────────────────────────────────────
OLD_PID=$(pgrep -f "$BINARY_NAME" 2>/dev/null || true)
if [ -n "$OLD_PID" ]; then
    kill -9 $OLD_PID 2>/dev/null || true
    echo "[+] Eski instance durduruldu (PID: $OLD_PID)"
    sleep 1
fi

# ── Oyun çalışıyor mu? ────────────────────────────────────────────────────
GAME_PID=$(pgrep -f "$TARGET_PKG" 2>/dev/null || true)
if [ -z "$GAME_PID" ]; then
    echo "[!] Oyun çalışmıyor: $TARGET_PKG"
    echo "    Oyunu aç, sonra tekrar çalıştır."
    exit 1
fi
echo "[+] Oyun bulundu — PID: $GAME_PID"

# ── SELinux'u geçici olarak permissive yap (bazı cihazlarda gerekli) ──────
SELINUX_STATE=$(getenforce 2>/dev/null || echo "unknown")
if [ "$SELINUX_STATE" = "Enforcing" ]; then
    setenforce 0 2>/dev/null && echo "[+] SELinux → Permissive" || echo "[~] SELinux değiştirilemedi (devam ediliyor)"
fi

# ── Binary'yi başlat ──────────────────────────────────────────────────────
echo "[+] ESP başlatılıyor..."
"$BINARY_DST" &
ESP_PID=$!
sleep 1

# PID hala yaşıyor mu?
if kill -0 $ESP_PID 2>/dev/null; then
    echo "[+] ESP çalışıyor — PID: $ESP_PID"
else
    echo "[!] ESP hemen çöktü. Logcat kontrol et:"
    echo "    adb logcat -s EnemyESP ImGuiHello"
    exit 1
fi

echo ""
echo "============================================"
echo "  ESP aktif. Logcat izlemek için:"
echo "  adb logcat -s EnemyESP ImGuiHello"
echo "  Durdurmak için:"
echo "  adb shell \"su -c 'kill $ESP_PID'\""
echo "============================================"
