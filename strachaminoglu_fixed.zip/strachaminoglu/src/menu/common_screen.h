#pragma once

extern int g_screenWidth;
extern int g_screenHeight;

