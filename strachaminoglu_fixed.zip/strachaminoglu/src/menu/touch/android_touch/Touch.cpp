#include <cstdio>
#include <cstring>
#include <thread>
#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <cmath>
#include <unistd.h>
#include <vector>
#include <atomic>
#include <mutex>
#include <chrono>
#include <cstdint>
#include "imgui/imgui.h"
#include "Touch.h"

#define TOUCH_MODE 2

namespace touch {
    // v77g: volume-down toggle — set here, consumed in render thread
    std::atomic<bool> g_menuToggleRequest{false};
    struct input {
        int fd;
        bool canBeUsed{false};
        input_absinfo absX{}, absY{};
        float absXMultiplier{0}, absYMultiplier{0};
#if TOUCH_MODE == 2
        bool trackingIDPresent{false};
#endif
        // v11: персистентное состояние контакта и последний отправленный
        // статус кнопки (MOVE-батч без tracking_id не должен "отпускать" мышь)
        bool contactDown{false};
        bool sentDown{false};

        // v13: MT-слоты (protocol B). ImGui слушает только primary-контакт,
        // ладонь/второй палец не дёргают мышь ImGui.
        bool slotMode{false};
        int  curSlot{0};
        int  primarySlot{-1};
        bool btnTouchPresent{false};

        // ═══ v66: ВСЕ СЛОТЫ — тач-аим = ОТДЕЛЬНОЕ КАСАНИЕ ═══════════════
        // Юзер: «одним пальцем джойстик, другим кнопки, другим стрельба,
        // а тач-аим просто наводится как другое касание и не мешает».
        // Старый код парсил позиции ТОЛЬКО primary-слота: пока первый палец
        // лежал на джойстике, аим-палец был физически невидим. Теперь сырые
        // координаты/статусы ведутся для КАЖДОГО слота; isScreenTouchDown
        // отдаёт самый свежий контакт ПРАВОЙ половины (или самый свежий
        // вообще — зону уже решает AimbotEngine).
        static constexpr int kMaxSlots = 16;
        float    rawX[16]   = {0};   // сырые координаты слота (единицы устройства)
        float    rawY[16]   = {0};
        bool     rawHas[16] = {false};
        bool     slotDownA[16] = {false};
        float    slotX[16]  = {0};   // экранная координата слота (после ориентации)
        float    slotY[16]  = {0};
        uint64_t slotT[16]  = {0};   // мс последнего апдейта слота
        float    screenHalfW{0.0f};

        input(const char *_path, int32_t _screen_w, int32_t _screen_h) {
            fd = open(_path, O_RDWR);
            if (fd == -1)
                return;

            // ─── v13: фильтр СВОЕГО виртуального устройства ("OxideTouch") ──
            char name[256] = {0};
            ioctl(fd, EVIOCGNAME(sizeof(name) - 1), name);
            struct input_id devId{};
            ioctl(fd, EVIOCGID, &devId);
            if (strncmp(name, "OxideTouch", sizeof(name)) == 0 ||
                strstr(name, "uinput") != nullptr ||
                devId.bustype == BUS_VIRTUAL) {
                close();
                return;
            }

            canBeUsed = ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &absX) != -1 &&
                        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &absY) != -1 &&
                        absX.maximum > 0 && absY.maximum > 0;
            if (!canBeUsed) {
                close();
                return;
            }

#if TOUCH_MODE == 2
            input_absinfo absTrackingID{};
            trackingIDPresent = ioctl(fd, EVIOCGABS(ABS_MT_TRACKING_ID), &absTrackingID) != -1 &&
                               absTrackingID.minimum <= 0 && absTrackingID.maximum > 0;
#endif

            unsigned long keyBits[(KEY_MAX / 8 / sizeof(unsigned long)) + 1] = {0};
            if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(keyBits)), keyBits) != -1) {
                auto testBit = [&](int bit) {
                    return (keyBits[bit / (8 * sizeof(unsigned long))] >>
                            (bit % (8 * sizeof(unsigned long)))) & 1UL;
                };
                btnTouchPresent = testBit(BTN_TOUCH);
            }

            calculateMultipliers(_screen_w, _screen_h);
        }

        void close() {
            if (fd != -1) {
                ::close(fd);
                fd = -1;
            }
        }

        void calculateMultipliers(int32_t _screen_w, int32_t _screen_h) {
            auto max = fmax((float) absX.maximum, (float) absY.maximum);
            auto min = fmin((float) absX.maximum, (float) absY.maximum);
            absXMultiplier = (float) _screen_w / (_screen_w > _screen_h ? max : min);
            absYMultiplier = (float) _screen_h / (_screen_w > _screen_h ? min : max);
            screenHalfW = 0.5f * (float) _screen_w;   // v66: граница аим-зоны
        }
    };

    uint8_t orientation = 0;
    std::atomic<ImGuiIO*> imgui_io{nullptr};

    static inline uint64_t nowMs64() {
        return (uint64_t) std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    }

    // ═══ v65: экспорт состояния пальца (для TOUCH-аима) ═══
    // ═══ v66: это уже НЕ «первый попавшийся контакт», а ЛУЧШИЙ контакт
    // из всех активных слотов: предпочтение — правая половина (аим-зона),
    // среди равных — самый свежий. Палец на джойстике больше не съедает
    // аим-палец, и наоборот — свайп джойстика не сбивает позицию аима.
    std::atomic<bool>  g_screenDown{false};
    std::atomic<float> g_screenX{-1.0f};
    std::atomic<float> g_screenY{-1.0f};

    bool isScreenTouchDown(float* outX, float* outY) {
        const bool down = g_screenDown.load(std::memory_order_relaxed);
        if (outX) *outX = g_screenX.load(std::memory_order_relaxed);
        if (outY) *outY = g_screenY.load(std::memory_order_relaxed);
        return down;
    }

    std::vector<input> inputs;
    std::vector<std::thread> threads;
    std::atomic<bool> shutdown_flag{false};

    // ═══ v14: потокобезопасная очередь событий ═════════════════════════════
    // Тач-поток ПРОИЗВОДИТ (мьютекс), render-поток выкачивает в ImGui раз в
    // кадр (pumpImGui перед NewFrame). Прямые вызовы io->AddMousePosEvent из
    // тач-потока гонялись с NewFrame/EndFrame → потери/порча событий.
    struct TEv {
        float x, y;
        bool  hasPos;
        bool  btnChanged;
        bool  down;
    };
    static std::mutex       g_qMtx;
    static std::vector<TEv> g_q;

    static void pushEv(const TEv& e) {
        std::lock_guard<std::mutex> lk(g_qMtx);
        if (g_q.size() > 256) g_q.clear();      // перегрузка — сбрасываем хвост
        g_q.push_back(e);
    }

    void pumpImGui() {
        ImGuiIO* io = imgui_io.load();
        if (!io) return;
        std::vector<TEv> local;
        {
            std::lock_guard<std::mutex> lk(g_qMtx);
            if (g_q.empty()) return;
            local.swap(g_q);
        }
        for (const TEv& e : local) {
            if (e.hasPos)     io->AddMousePosEvent(e.x, e.y);
            if (e.btnChanged) io->AddMouseButtonEvent(0, e.down);
        }
    }

    void input_thread(input *_input) {
        // Ждём пока ImGuiIO станет доступным (контекст создан)
        for (int i = 0; i < 30 && !imgui_io.load(); ++i) {
            usleep(100 * 1000);  // 100 ms
        }
        if (!imgui_io.load()) return;

        input_event events[64]{};
        while (!shutdown_flag.load() && _input->fd > 0) {
            auto event_readed_count = read(_input->fd, events, sizeof(events));
            if (event_readed_count == -1) {
                if (shutdown_flag.load()) break;
                continue;
            }
            event_readed_count /= (ssize_t) sizeof(input_event);

            for (long j = 0; j < event_readed_count; j++) {
                auto &event = events[j];
                if (event.type == EV_ABS) {
                    if (event.code == ABS_MT_SLOT) {
                        _input->slotMode = true;
                        if (event.value >= 0 && event.value < input::kMaxSlots)
                            _input->curSlot = event.value;
                        continue;
                    }
#if TOUCH_MODE == 2
                    if (_input->trackingIDPresent && event.code == ABS_MT_TRACKING_ID) {
                        // v66: статус ВЕДИТСЯ ДЛЯ КАЖДОГО СЛОТА — аим-палец
                        // может быть вторым/третьим касанием
                        if (event.value != -1) {
                            _input->slotDownA[_input->curSlot] = true;
                            if (_input->primarySlot < 0)
                                _input->primarySlot = _input->curSlot;
                            _input->contactDown = true;
                        } else {
                            _input->slotDownA[_input->curSlot] = false;
                            _input->rawHas[_input->curSlot] = false;
                            if (_input->primarySlot == _input->curSlot) {
                                _input->contactDown = false;
                                _input->primarySlot = -1;
                            }
                        }
                        continue;
                    }
#elif TOUCH_MODE == 0
                    if (event.code == ABS_MT_TRACKING_ID) {
                        if (event.value != -1) {
                            _input->slotDownA[_input->curSlot] = true;
                            if (_input->primarySlot < 0)
                                _input->primarySlot = _input->curSlot;
                            _input->contactDown = true;
                        } else {
                            _input->slotDownA[_input->curSlot] = false;
                            _input->rawHas[_input->curSlot] = false;
                            if (_input->primarySlot == _input->curSlot) {
                                _input->contactDown = false;
                                _input->primarySlot = -1;
                            }
                        }
                        continue;
                    }
#endif
                    // v66: позиции пишем для ВСЕХ слотов (раньше — только
                    // primary: аим-палец был невидим, пока палец на джойстике)
                    if (event.code == ABS_MT_POSITION_X) {
                        _input->rawX[_input->curSlot] = (float) event.value;
                        _input->rawHas[_input->curSlot] = true;
                        continue;
                    }
                    if (event.code == ABS_MT_POSITION_Y) {
                        _input->rawY[_input->curSlot] = (float) event.value;
                        _input->rawHas[_input->curSlot] = true;
                        continue;
                    }
                }
                // v77g: volume-down = menu toggle (press only, not hold)
                if (event.type == EV_KEY && event.code == KEY_VOLUMEDOWN && event.value == 1) {
                    g_menuToggleRequest.store(true, std::memory_order_relaxed);
                    continue;
                }
                if (event.type == EV_KEY && event.code == BTN_TOUCH) {
                    _input->contactDown = (event.value != 0);
                    if (event.value == 0) {
                        _input->primarySlot = -1;
                        // v66: все контакты подняты — чистим ВСЕ слоты
                        for (int s2 = 0; s2 < input::kMaxSlots; ++s2) {
                            _input->slotDownA[s2] = false;
                            _input->rawHas[s2] = false;
                        }
                    } else if (_input->slotMode && _input->primarySlot < 0 &&
                               _input->rawHas[_input->curSlot]) {
                        // v66: первый контакт после полного подъёма — primary
                        _input->primarySlot = _input->curSlot;
                    }
                    continue;
                }
                if (event.code == SYN_REPORT) {
#if TOUCH_MODE == 2
                    bool down = _input->trackingIDPresent
                                ? _input->contactDown
                                : (event_readed_count > 2);
#elif TOUCH_MODE == 0
                    bool down = _input->contactDown;
#else
                    bool down = event_readed_count > 2;
#endif
                    if (_input->btnTouchPresent) down = _input->contactDown;

                    const int cs = (_input->curSlot >= 0 &&
                                    _input->curSlot < input::kMaxSlots)
                                   ? _input->curSlot : 0;
                    if (_input->slotMode && _input->trackingIDPresent)
                        down = _input->slotDownA[cs];        // v66: правда per-slot
                    else if (down)
                        _input->slotDownA[cs] = true;        // без tracking id

                    const bool havePos = _input->rawHas[cs];
                    float sx = 0.0f, sy = 0.0f;
                    if (havePos) {
                        const float rx = _input->rawX[cs], ry = _input->rawY[cs];
                        switch (orientation) {
                            case 1:
                                sx = ry * _input->absXMultiplier;
                                sy = (_input->absX.maximum - rx) * _input->absYMultiplier;
                                break;
                            case 2:
                                sx = (_input->absX.maximum - rx) * _input->absXMultiplier;
                                sy = (_input->absY.maximum - ry) * _input->absYMultiplier;
                                break;
                            case 3:
                                sx = (_input->absY.maximum - ry) * _input->absXMultiplier;
                                sy = rx * _input->absYMultiplier;
                                break;
                            default:
                                sx = rx * _input->absXMultiplier;
                                sy = ry * _input->absYMultiplier;
                                break;
                        }
                    }

                    // v14/v66: ImGui слушает ТОЛЬКО primary-слот (как и было),
                    // но позиции теперь честные per-slot
                    const bool isPrimary = !_input->slotMode ||
                                           _input->primarySlot < 0 ||
                                           cs == _input->primarySlot;
                    if (isPrimary) {
                        TEv ev{};
                        ev.hasPos = havePos;
                        ev.x = sx;
                        ev.y = sy;
                        ev.btnChanged = (down != _input->sentDown);
                        ev.down       = down;
                        if (ev.btnChanged) _input->sentDown = down;
                        if (ev.hasPos || ev.btnChanged) pushEv(ev);
                    }

                    // ═══ v66: экспорт ЛУЧШЕГО контакта для тач-аима ══════
                    // Правая половина — приоритет (аим-зона); среди равных —
                    // самый свежий слот. Джойстик-палец больше не съедает
                    // аим-палец, аим-палец не сбивается движением джойстика.
                    int      best = -1, bestLeft = -1;
                    uint64_t bestT = 0, bestLeftT = 0;
                    for (int s2 = 0; s2 < input::kMaxSlots; ++s2) {
                        if (!_input->slotDownA[s2] || !_input->rawHas[s2]) continue;
                        float ex, ey;
                        const float rx = _input->rawX[s2], ry = _input->rawY[s2];
                        switch (orientation) {
                            case 1:
                                ex = ry * _input->absXMultiplier;
                                ey = (_input->absX.maximum - rx) * _input->absYMultiplier;
                                break;
                            case 2:
                                ex = (_input->absX.maximum - rx) * _input->absXMultiplier;
                                ey = (_input->absY.maximum - ry) * _input->absYMultiplier;
                                break;
                            case 3:
                                ex = (_input->absY.maximum - ry) * _input->absXMultiplier;
                                ey = rx * _input->absYMultiplier;
                                break;
                            default:
                                ex = rx * _input->absXMultiplier;
                                ey = ry * _input->absYMultiplier;
                                break;
                        }
                        _input->slotX[s2] = ex;
                        _input->slotY[s2] = ey;
                        if (_input->slotT[s2] == 0) _input->slotT[s2] = nowMs64();
                        if (ex >= _input->screenHalfW) {
                            if (best < 0 || _input->slotT[s2] >= bestT) {
                                best = s2; bestT = _input->slotT[s2];
                            }
                        } else {
                            if (bestLeft < 0 || _input->slotT[s2] >= bestLeftT) {
                                bestLeft = s2; bestLeftT = _input->slotT[s2];
                            }
                        }
                    }
                    const int pick = best >= 0 ? best : bestLeft;
                    if (pick >= 0) {
                        g_screenDown.store(true, std::memory_order_relaxed);
                        g_screenX.store(_input->slotX[pick], std::memory_order_relaxed);
                        g_screenY.store(_input->slotY[pick], std::memory_order_relaxed);
                    } else {
                        g_screenDown.store(false, std::memory_order_relaxed);
                    }
                }
            }
        }
    }

    bool init(int32_t _screen_w, int32_t _screen_h, uint8_t _orientation) {
        orientation = _orientation;
        shutdown_flag.store(false);

        bool result = false;

        const char *path = "/dev/input/";
        auto dir = opendir(path);
        if (!dir) {
            printf("[E] touch::init: cannot open /dev/input\n"); fflush(stdout);
            return false;
        }
        dirent *ptr;
        int found = 0, skipped = 0;
        while ((ptr = readdir(dir))) {
            if (strstr(ptr->d_name, "event")) {
                char event_path[128];
                sprintf(event_path, "%s%s", path, ptr->d_name);
                input _input(event_path, _screen_w, _screen_h);
                if (_input.canBeUsed) {
                    result = true;
                    found++;
                    char name[256] = {0};
                    ioctl(_input.fd, EVIOCGNAME(sizeof(name) - 1), name);
                    printf("[I] touch::init: using %s (%s)\n", event_path, name);
                    inputs.push_back(std::move(_input));
                } else {
                    skipped++;
                }
            }
        }
        closedir(dir);

        printf("[I] touch::init: found %d usable touch devices (%d skipped incl. virtual), starting threads...\n",
               found, skipped);
        fflush(stdout);

        for (size_t i = 0; i < inputs.size(); ++i) {
            threads.emplace_back(input_thread, &inputs[i]);
        }

        return result;
    }

    void setImGuiIO(ImGuiIO* io) {
        imgui_io.store(io);
        printf("[I] touch::setImGuiIO: io=%p\n", (void*)io); fflush(stdout);
    }

    void update(int32_t _screen_w, int32_t _screen_h, uint8_t _orientation) {
        orientation = _orientation;

        for (auto &_input: inputs) {
            _input.calculateMultipliers(_screen_w, _screen_h);
        }
    }

    void updateOrientation(uint8_t _orientation) {
        orientation = _orientation;
    }

    void shutdown() {
        shutdown_flag.store(true);
        for (auto &_input: inputs)
            _input.close();
        for (auto &t: threads)
            if (t.joinable())
                t.join();
        inputs.clear();
        threads.clear();
        imgui_io.store(nullptr);
        std::lock_guard<std::mutex> lk(g_qMtx);
        g_q.clear();
    }
}
